// Framelift 1.19  ·  Figma → After Effects  ·  Figma exporter
// Made by Robbie Bunting  ·  © 2026 Robbie Bunting. All rights reserved.
// Figma and Adobe After Effects are trademarks of their respective owners. Not affiliated with Figma or Adobe.
// Serialises the selected frames into a .framelift package (zip: scene.json + images/)
// that the After Effects importer panel rebuilds as native AE layers.

const PLUGIN_VERSION = '1.19';
const PLUGIN_BUILD = '21 Oct c';

if (figma.command === 'testframe') {
  // runs after the whole file has loaded
  Promise.resolve().then(createTestFrame)
    .then(() => figma.closePlugin('Framelift test frame created – run Framelift ▸ Send to After Effects on it'))
    .catch((e) => figma.closePlugin('Couldn’t create the test frame: ' + ((e && e.message) || e)));
} else figma.showUI(__html__, { width: 360, height: 420, themeColors: true });

const DEFAULT_SETTINGS = {
  scale: 1,              // multiply all geometry (1 = 1 Figma px → 1 AE px)
  rasterQuality: 2,      // pixel density of any rasterised fallback / exported images
  cleanup: true,         // skip what doesn't show: hidden, transparent, off-frame, covered and empty layers
  includeHidden: true,   // (cleanup off) hidden Figma layers come in as disabled AE layers
  rasterUnsupported: true, // angular/diamond gradients, tiled/filtered images, noise, etc → PNG
  outlineStrokes: false, // convert all strokes to filled outlines (pixel exact, less editable)
  reference: true,       // add a hidden screenshot of the Figma frame as a guide layer
  updateExisting: true,  // live link: re-sending a frame rebuilds its existing comp
  shadows: 'exact',      // 'exact' = drop shadows rendered by Figma (pixel match) · 'editable' = AE layer styles
  target: 'new',         // 'new' = each frame gets its own comp · 'active' = add into the comp open in AE
};

// ------------------------------------------------------------------ messaging
figma.ui.onmessage = async (msg) => {
  if (msg.type === 'init') {
    const saved = (await figma.clientStorage.getAsync('settings')) || {};
    figma.ui.postMessage({ type: 'settings', settings: Object.assign({}, DEFAULT_SETTINGS, saved), version: PLUGIN_VERSION });
    sendSelection();
  } else if (msg.type === 'save-settings') {
    await figma.clientStorage.setAsync('settings', msg.settings);
  } else if (msg.type === 'export') {
    try {
      const out = await exportPackage(Object.assign({}, DEFAULT_SETTINGS, msg.settings));
      figma.ui.postMessage({ type: 'package', dest: msg.dest || 'file', files: out.files, name: out.name, stats: out.stats, warnings: out.warnings });
    } catch (e) {
      console.error(e);
      figma.ui.postMessage({ type: 'error', message: String((e && e.message) || e) });
    }
  } else if (msg.type === 'resize') {
    figma.ui.resize(360, Math.max(300, Math.min(820, msg.h)));
  } else if (msg.type === 'notify') {
    figma.notify(msg.text);
  }
};
figma.on('selectionchange', sendSelection);
figma.on('currentpagechange', sendSelection);

function getRoots() {
  const sel = figma.currentPage.selection.filter((n) => n.type !== 'SLICE');
  if (sel.length) return { roots: sel.slice(), fromSelection: true };
  const frames = figma.currentPage.children.filter((n) => isFrameLike(n) && n.visible);
  return { roots: frames, fromSelection: false };
}
function sendSelection() {
  const { roots, fromSelection } = getRoots();
  figma.ui.postMessage({
    type: 'selection',
    fromSelection,
    items: roots.map((n) => ({ name: n.name, type: n.type, w: Math.round(n.width), h: Math.round(n.height) })),
  });
}
function progress(text, pct) { figma.ui.postMessage({ type: 'progress', text, pct }); }

// ------------------------------------------------------------------ helpers
const FRAME_TYPES = { FRAME: 1, COMPONENT: 1, COMPONENT_SET: 1, INSTANCE: 1, SECTION: 1 };
const SHAPE_TYPES = { RECTANGLE: 1, ELLIPSE: 1, VECTOR: 1, STAR: 1, POLYGON: 1, LINE: 1, BOOLEAN_OPERATION: 1 };
function isFrameLike(n) { return !!FRAME_TYPES[n.type]; }
const MIXED = figma.mixed;
const isMixed = (v) => v === MIXED;
const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d);

// 2D affine as [a,b,c,d,e,f] (SVG order): x' = a*x + c*y + e ; y' = b*x + d*y + f
function fromFigma(t) { return [t[0][0], t[1][0], t[0][1], t[1][1], t[0][2], t[1][2]]; }
function mul(A, B) {
  return [
    A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
    A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
    A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5],
  ];
}
function inv(M) {
  const det = M[0] * M[3] - M[1] * M[2] || 1e-12;
  return [M[3] / det, -M[1] / det, -M[2] / det, M[0] / det,
    (M[2] * M[5] - M[3] * M[4]) / det, (M[1] * M[4] - M[0] * M[5]) / det];
}
function ap(M, x, y) { return [M[0] * x + M[2] * y + M[4], M[1] * x + M[3] * y + M[5]]; }
const T = (x, y) => [1, 0, 0, 1, x, y];
const Sc = (sx, sy) => [sx, 0, 0, sy === undefined ? sx : sy, 0, 0];
const Rot = (deg) => { const r = deg * Math.PI / 180, c = Math.cos(r), s = Math.sin(r); return [c, s, -s, c, 0, 0]; };
const r6 = (v) => Math.round(v * 1e4) / 1e4;
const r9 = (v) => Math.round(v * 1e9) / 1e9;
const rm = (M) => [r9(M[0]), r9(M[1]), r9(M[2]), r9(M[3]), r6(M[4]), r6(M[5])];

function rgb(c) { return [r6(c.r), r6(c.g), r6(c.b)]; }

// ------------------------------------------------------------------ SVG path → AE shape
// Figma emits absolute M/L/C/Q/Z, but we parse the full grammar (minus arcs) to be safe.
function parsePath(d, S) {
  const toks = d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g) || [];
  let i = 0, cmd = null;
  const shapes = [];
  let cur = null, x = 0, y = 0, sx = 0, sy = 0, lc = null, lq = null;
  const n = () => parseFloat(toks[i++]);
  const isCmd = (t) => /[a-zA-Z]/.test(t);
  const startSub = (px, py) => { cur = { pts: [{ p: [px, py], i: [0, 0], o: [0, 0] }], c: false }; shapes.push(cur); sx = px; sy = py; };
  const last = () => cur.pts[cur.pts.length - 1];
  const lineTo = (px, py) => { if (!cur) startSub(x, y); cur.pts.push({ p: [px, py], i: [0, 0], o: [0, 0] }); };
  const cubicTo = (x1, y1, x2, y2, px, py) => {
    if (!cur) startSub(x, y);
    const L = last(); L.o = [x1 - L.p[0], y1 - L.p[1]];
    cur.pts.push({ p: [px, py], i: [x2 - px, y2 - py], o: [0, 0] });
  };
  while (i < toks.length) {
    if (isCmd(toks[i])) cmd = toks[i++];
    else if (cmd === null) { i++; continue; }
    const rel = cmd === cmd.toLowerCase();
    const C = cmd.toUpperCase();
    const ox = rel ? x : 0, oy = rel ? y : 0;
    if (C === 'Z') {
      if (cur) {
        cur.c = true;
        const f = cur.pts[0], l = last();
        if (cur.pts.length > 1 && Math.abs(f.p[0] - l.p[0]) < 1e-4 && Math.abs(f.p[1] - l.p[1]) < 1e-4) { f.i = l.i; cur.pts.pop(); }
        x = sx; y = sy; cur = null;
      }
      lc = lq = null; continue;
    }
    if (i >= toks.length || isCmd(toks[i])) continue;
    if (C === 'M') { x = ox + n(); y = oy + n(); startSub(x, y); cmd = rel ? 'l' : 'L'; lc = lq = null; }
    else if (C === 'L') { x = ox + n(); y = oy + n(); lineTo(x, y); lc = lq = null; }
    else if (C === 'H') { x = ox + n(); lineTo(x, y); lc = lq = null; }
    else if (C === 'V') { y = oy + n(); lineTo(x, y); lc = lq = null; }
    else if (C === 'C') {
      const x1 = ox + n(), y1 = oy + n(), x2 = ox + n(), y2 = oy + n(); x = ox + n(); y = oy + n();
      cubicTo(x1, y1, x2, y2, x, y); lc = [x2, y2]; lq = null;
    } else if (C === 'S') {
      const x1 = lc ? 2 * x - lc[0] : x, y1 = lc ? 2 * y - lc[1] : y;
      const x2 = ox + n(), y2 = oy + n(); const px = ox + n(), py = oy + n();
      cubicTo(x1, y1, x2, y2, px, py); x = px; y = py; lc = [x2, y2]; lq = null;
    } else if (C === 'Q' || C === 'T') {
      let qx, qy;
      if (C === 'Q') { qx = ox + n(); qy = oy + n(); } else { qx = lq ? 2 * x - lq[0] : x; qy = lq ? 2 * y - lq[1] : y; }
      const px = ox + n(), py = oy + n();
      cubicTo(x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), px + 2 / 3 * (qx - px), py + 2 / 3 * (qy - py), px, py);
      x = px; y = py; lq = [qx, qy]; lc = null;
    } else if (C === 'A') {
      // Figma never emits arcs; consume & straight-line them.
      n(); n(); n(); n(); n(); x = ox + n(); y = oy + n(); lineTo(x, y);
    } else { i++; }
  }
  return shapes.filter((s) => s.pts.length > 0).map((s) => ({
    v: s.pts.map((p) => [r6(p.p[0] * S), r6(p.p[1] * S)]),
    i: s.pts.map((p) => [r6(p.i[0] * S), r6(p.i[1] * S)]),
    o: s.pts.map((p) => [r6(p.o[0] * S), r6(p.o[1] * S)]),
    c: s.c,
  }));
}
function geomToPaths(list, S) {
  const out = [];
  let rule = 'NONZERO';
  for (const g of list || []) { if (g.windingRule === 'EVENODD') rule = 'EVENODD'; out.push(...parsePath(g.data, S)); }
  return { paths: out, rule };
}

// ------------------------------------------------------------------ context
function makeCtx(settings) {
  return {
    S: num(settings.scale, 1), Q: num(settings.rasterQuality, 2),
    cleanup: settings.cleanup !== false, includeHidden: settings.cleanup === false && settings.includeHidden !== false,
    cleaned: { hidden: 0, transparent: 0, outside: 0, covered: 0, empty: 0 }, clips: [], rootNode: null,
    rasterUnsupported: !!settings.rasterUnsupported,
    outlineStrokes: !!settings.outlineStrokes, reference: settings.reference !== false,
    exactShadows: settings.shadows !== 'editable', total: 1,
    files: [], images: new Map(), fileNames: new Set(), byHash: new Map(), fileKeys: {}, warnings: [], warnKeys: new Set(),
    measure: new Map(), rootInv: null, count: 0,
    stats: { layers: 0, text: 0, shapes: 0, images: 0, rasters: 0, comps: 0 },
  };
}
function warn(ctx, node, msg) {
  const k = msg + '|' + (node ? node.name : '');
  if (ctx.warnKeys.has(k)) return; ctx.warnKeys.add(k);
  ctx.warnings.push({ node: node ? node.name : '', id: node ? node.id : '', msg });
}
function uniqueFile(ctx, base, ext) {
  let clean = (base || 'image').replace(/[^\w\-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || 'image';
  let name = 'images/' + clean + '.' + ext, k = 2;
  while (ctx.fileNames.has(name)) name = 'images/' + clean + '_' + (k++) + '.' + ext;
  ctx.fileNames.add(name);
  return name;
}
// identical renders (same logo on every frame…) are stored once → enables shared precomps too
function hashBytes(b) {
  let h1 = 0x811c9dc5, h2 = 0x01000193 ^ b.length;
  for (let i = 0; i < b.length; i++) { h1 = Math.imul(h1 ^ b[i], 16777619); h2 = Math.imul(h2 ^ b[b.length - 1 - i], 2246822519); }
  return (h1 >>> 0).toString(16) + (h2 >>> 0).toString(16) + ':' + b.length;
}
function addFile(ctx, hint, bytes, shadowPair) {
  const key = shadowPair ? 'S' + hashBytes(shadowPair.a) + hashBytes(shadowPair.b) : hashBytes(bytes);
  if (ctx.byHash.has(key)) return ctx.byHash.get(key);
  const file = uniqueFile(ctx, hint, 'png');
  ctx.files.push(shadowPair ? { name: file, shadowPair } : { name: file, bytes });
  ctx.byHash.set(key, file);
  ctx.fileKeys[file] = key;
  return file;
}
function sniffExt(b) {
  if (b[0] === 0x89 && b[1] === 0x50) return 'png';
  if (b[0] === 0xff && b[1] === 0xd8) return 'jpg';
  if (b[0] === 0x47 && b[1] === 0x49) return 'gif';
  return 'convert'; // webp/heic/etc → UI converts to PNG
}
function pngSize(b) {
  if (b[0] !== 0x89) return null;
  const rd = (o) => (b[o] << 24 | b[o + 1] << 16 | b[o + 2] << 8 | b[o + 3]) >>> 0;
  return { w: rd(16), h: rd(20) };
}

// Space conversion: everything is exported in "root space" (the comp), scaled by S.
// M_rootspace = Sm · inv(rootAbs) · nodeAbs · Sm^-1  → linear part unchanged, translation × S;
// node-local geometry is multiplied by S, so the whole scene is uniformly scaled.
function rootSpace(ctx, absM) {
  const R = mul(ctx.rootInv, absM);
  R[4] *= ctx.S; R[5] *= ctx.S;
  return rm(R);
}
function localRenderBounds(ctx, node) {
  const rb = node.absoluteRenderBounds;
  if (!rb) return [0, 0, r6(node.width * ctx.S), r6(node.height * ctx.S)];
  const I = inv(fromFigma(node.absoluteTransform));
  const pts = [[rb.x, rb.y], [rb.x + rb.width, rb.y], [rb.x, rb.y + rb.height], [rb.x + rb.width, rb.y + rb.height]].map((p) => ap(I, p[0], p[1]));
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  const x0 = Math.min(...xs), y0 = Math.min(...ys), x1 = Math.max(...xs), y1 = Math.max(...ys);
  return [x0, y0, x1 - x0, y1 - y0].map((v) => r6(v * ctx.S));
}

// ------------------------------------------------------------------ paints
const SUPPORTED_PAINT = { SOLID: 1, GRADIENT_LINEAR: 1, GRADIENT_RADIAL: 1, GRADIENT_ANGULAR: 1, GRADIENT_DIAMOND: 1, IMAGE: 1 };
function visiblePaints(p) { return isMixed(p) || !p ? [] : p.filter((x) => x.visible !== false && num(x.opacity, 1) > 0); }
function imageNeedsRaster(p) {
  if (p.type !== 'IMAGE') return false;
  if (p.scaleMode === 'TILE') return true;
  const f = p.filters || {};
  return ['exposure', 'contrast', 'saturation', 'temperature', 'tint', 'highlights', 'shadows'].some((k) => Math.abs(f[k] || 0) > 1e-3);
}
function paintUnsupported(p) { return !SUPPORTED_PAINT[p.type] || imageNeedsRaster(p); }

async function exportPaint(ctx, node, p, w, h) {
  const opacity = r6(num(p.opacity, 1));
  const blend = p.blendMode || 'NORMAL';
  if (p.type === 'SOLID') return { type: 'solid', color: rgb(p.color), opacity, blend };
  if (p.type === 'GRADIENT_LINEAR' || p.type === 'GRADIENT_RADIAL' || p.type === 'GRADIENT_ANGULAR' || p.type === 'GRADIENT_DIAMOND') {
    // gradientTransform maps node-normalised space → gradient space; invert to get handles.
    const G = inv(fromFigma(p.gradientTransform));
    const toLocal = (u, v) => { const q = ap(G, u, v); return [r6(q[0] * w), r6(q[1] * h)]; };
    const radial = p.type !== 'GRADIENT_LINEAR';
    const start = radial ? toLocal(0.5, 0.5) : toLocal(0, 0.5);
    const end = radial ? toLocal(1, 0.5) : toLocal(1, 0.5);
    const stops = p.gradientStops.map((s) => ({ p: r6(s.position), c: [r6(s.color.r), r6(s.color.g), r6(s.color.b), r6(s.color.a)] }));
    // AE can only do 2-stop native ramps when gradient colours aren't scriptable → also ship an exact
    // Figma render of this fill, used (clipped by the native shape) whenever AE can't build it natively.
    const special = p.type === 'GRADIENT_ANGULAR' || p.type === 'GRADIENT_DIAMOND';
    const needsRender = special || stops.length > 2 || stops.some((s) => s.c[3] < 0.999);
    const render = needsRender && node.type !== 'TEXT' && !ctx.strokeMode ? await renderFill(ctx, node, p, w, h) : null;
    if (special && !render) warn(ctx, node, p.type.replace('GRADIENT_', '').toLowerCase() + ' gradient approximated as radial');
    return { type: radial ? 'radial' : 'linear', start, end, edge2: radial ? toLocal(0.5, 1) : null, stops, opacity, blend, render, exactOnly: special };
  }
  if (p.type === 'IMAGE') {
    if (!p.imageHash) { warn(ctx, node, 'image fill has no data'); return null; }
    const img = await getImage(ctx, p.imageHash, node.name);
    if (!img) return null;
    const iw = img.w, ih = img.h;
    let M;
    const rot = num(p.rotation, 0) % 360;
    if (p.scaleMode === 'CROP' && p.imageTransform) {
      // imageTransform: node-normalised → image-normalised. Invert for image → node.
      const Ti = inv(fromFigma(p.imageTransform));
      M = mul(Sc(w, h), mul(Ti, Sc(1 / iw, 1 / ih)));
    } else {
      const swap = Math.abs(rot % 180) === 90;
      const ew = swap ? ih : iw, eh = swap ? iw : ih;
      const s = p.scaleMode === 'FIT' ? Math.min(w / ew, h / eh) : Math.max(w / ew, h / eh);
      M = mul(T(w / 2, h / 2), mul(Rot(rot), mul(Sc(s), T(-iw / 2, -ih / 2))));
    }
    if (p.scaleMode === 'TILE') warn(ctx, node, 'tiled image fill placed as single image');
    return { type: 'image', file: img.file, iw, ih, m: rm(M), opacity, blend, fit: p.scaleMode };
  }
  warn(ctx, node, 'unsupported paint ' + p.type + ' skipped');
  return null;
}
// Render one paint on its own (no strokes/effects/children), un-rotated → image px maps to node-local space.
async function renderFill(ctx, node, paint, w, h) {
  let c = null;
  try {
    c = node.clone();
    figma.currentPage.appendChild(c);
    c.relativeTransform = [[1, 0, 0], [0, 1, 0]];
    if ('children' in c && c.children) for (const k of [...c.children]) k.remove();
    const solo = Object.assign({}, paint, { opacity: 1, visible: true });
    c.fills = [solo];
    if ('strokes' in c) c.strokes = [];
    c.effects = []; c.opacity = 1;
    if ('isMask' in c && c.isMask) c.isMask = false;
    const bytes = await c.exportAsync({ format: 'PNG', useAbsoluteBounds: true, constraint: { type: 'SCALE', value: ctx.S * Math.min(ctx.Q, 2) } });
    c.remove(); c = null;
    const size = pngSize(bytes);
    const file = addFile(ctx, cleanName(node.name) + '_fill', bytes);
    return { file, iw: size.w, ih: size.h, m: rm(Sc(w / size.w, h / size.h)) };
  } catch (e) {
    if (c) try { c.remove(); } catch (e2) { /* */ }
    warn(ctx, node, 'gradient render failed (' + e.message + ') – using 2-stop ramp');
    return null;
  }
}
async function getImage(ctx, hash, nameHint) {
  if (ctx.images.has(hash)) return ctx.images.get(hash);
  const im = figma.getImageByHash(hash);
  if (!im) return null;
  const bytes = await im.getBytesAsync();
  const size = await im.getSizeAsync();
  const ext = sniffExt(bytes);
  const file = uniqueFile(ctx, nameHint, ext === 'convert' ? 'png' : ext);
  ctx.files.push({ name: file, bytes, convert: ext === 'convert' });
  ctx.fileKeys[file] = 'I' + hash;                 // Figma's own image hash: same photo = same key, every send
  const rec = { file, w: size.width, h: size.height };
  ctx.images.set(hash, rec);
  ctx.stats.images++;
  return rec;
}
async function exportPaints(ctx, node, paints, w, h) {
  const out = [];
  for (const p of visiblePaints(paints)) { const e = await exportPaint(ctx, node, p, w, h); if (e) out.push(e); }
  return out; // bottom → top, as Figma
}

// ------------------------------------------------------------------ effects
function spreadApplies(node) {
  if (node.type === 'RECTANGLE' || node.type === 'ELLIPSE') return true;
  if (isFrameLike(node)) return !!node.clipsContent;
  return false;
}
function exportEffects(ctx, node) {
  const out = [];
  const S = ctx.S;
  for (const e of node.effects || []) {
    if (e.visible === false) continue;
    if (e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW') {
      out.push({
        type: e.type === 'DROP_SHADOW' ? 'dropShadow' : 'innerShadow',
        color: rgb(e.color), a: r6(e.color.a),
        x: r6(e.offset.x * S), y: r6(e.offset.y * S),
        // Figma only renders spread on rectangles, ellipses and clipping frames – it's ignored on text & vectors.
        blur: r6(e.radius * S), spread: spreadApplies(node) ? r6(num(e.spread, 0) * S) : 0,
        behind: !!e.showShadowBehindNode, blend: e.blendMode || 'NORMAL',
      });
    } else if (e.type === 'LAYER_BLUR' || e.type === 'BACKGROUND_BLUR') {
      let r = e.radius;
      if (e.blurType === 'PROGRESSIVE') { r = (num(e.startRadius, 0) + e.radius) / 2; warn(ctx, node, 'progressive blur approximated as uniform blur'); }
      out.push({ type: e.type === 'LAYER_BLUR' ? 'layerBlur' : 'backgroundBlur', r: r6(r * S) });
    } else {
      out.push({ type: 'unsupported', name: e.type });
    }
  }
  return out;
}
const hasUnsupportedEffect = (node) => (node.effects || []).some((e) => e.visible !== false && !['DROP_SHADOW', 'INNER_SHADOW', 'LAYER_BLUR', 'BACKGROUND_BLUR'].includes(e.type));

// ------------------------------------------------------------------ strokes
function strokeInfo(ctx, node) {
  const S = ctx.S;
  let w = node.strokeWeight, individual = false;
  if (isMixed(w) || ('strokeTopWeight' in node && !isMixed(node.strokeTopWeight))) {
    const ws = ['strokeTopWeight', 'strokeRightWeight', 'strokeBottomWeight', 'strokeLeftWeight'].map((k) => num(node[k], 0));
    if (ws.some((v) => Math.abs(v - ws[0]) > 1e-6)) individual = true;
    w = Math.max(...ws);
  }
  let cap = node.strokeCap; if (isMixed(cap)) cap = 'NONE';
  let join = node.strokeJoin; if (isMixed(join)) join = 'MITER';
  return {
    w: r6(num(w, 0) * S), align: node.strokeAlign || 'CENTER', cap, join,
    miter: num(node.strokeMiterLimit, 4), dash: (node.dashPattern || []).map((v) => r6(v * S)),
    individual,
  };
}
function needsOutlineStroke(ctx, node, st) {
  if (ctx.outlineStrokes) return true;
  if (st.individual) return true;
  if (['ARROW_LINES', 'ARROW_EQUILATERAL', 'TRIANGLE_FILLED', 'DIAMOND_FILLED', 'CIRCLE_FILLED', 'TRIANGLE_ARROW', 'DIAMOND_ARROW', 'CIRCLE_ARROW'].some((c) => st.cap === c) || isMixed(node.strokeCap)) return true;
  if (st.dash.length && st.align !== 'CENTER') return true;
  return false;
}

// ------------------------------------------------------------------ geometry
function cornerRadii(ctx, node) {
  const S = ctx.S;
  if ('topLeftRadius' in node) {
    return [node.topLeftRadius, node.topRightRadius, node.bottomRightRadius, node.bottomLeftRadius].map((v) => r6(num(v, 0) * S));
  }
  const r = num(node.cornerRadius, 0) * S;
  return [r, r, r, r];
}
function shapeGeometry(ctx, node) {
  const S = ctx.S, w = r6(node.width * S), h = r6(node.height * S);
  const smooth = num(node.cornerSmoothing, 0);
  if (node.type === 'RECTANGLE' || isFrameLike(node)) {
    const r = cornerRadii(ctx, node);
    if (smooth < 1e-3 || r.every((v) => v === 0)) return { kind: 'rect', w, h, r };
    if (node.fillGeometry && node.fillGeometry.length) return Object.assign({ kind: 'paths' }, geomToPaths(node.fillGeometry, S));
    return { kind: 'rect', w, h, r };
  }
  if (node.type === 'ELLIPSE') {
    const a = node.arcData;
    const full = !a || (Math.abs(a.startingAngle) < 1e-6 && Math.abs(a.endingAngle - 2 * Math.PI) < 1e-6 && a.innerRadius < 1e-6);
    if (full) return { kind: 'ellipse', w, h };
  }
  if (node.type === 'LINE') {
    return { kind: 'paths', rule: 'NONZERO', open: true, paths: [{ v: [[0, 0], [w, 0]], i: [[0, 0], [0, 0]], o: [[0, 0], [0, 0]], c: false }] };
  }
  if (node.type === 'VECTOR') {
    // centre-line paths – correct for open and closed paths, keep strokes editable.
    const vp = node.vectorPaths || [];
    const paths = [], fillPaths = [];
    let rule = 'NONZERO';
    for (const p of vp) {
      const parsed = parsePath(p.data, S);
      paths.push(...parsed);
      if (p.windingRule !== 'NONE') { fillPaths.push(...parsed.filter((q) => q.c)); if (p.windingRule === 'EVENODD') rule = 'EVENODD'; }
    }
    // fills defined per region in vector networks: Figma's fillGeometry is authoritative for fills.
    const fg = node.fillGeometry && node.fillGeometry.length ? geomToPaths(node.fillGeometry, S) : null;
    return { kind: 'paths', paths, fillPaths: fg ? fg.paths : fillPaths, rule: fg ? fg.rule : rule };
  }
  if (node.fillGeometry && node.fillGeometry.length) return Object.assign({ kind: 'paths' }, geomToPaths(node.fillGeometry, S));
  return { kind: 'paths', paths: [], rule: 'NONZERO' };
}

// ------------------------------------------------------------------ text
async function measureText(ctx, fontName, fontSize, lineHeight, leadingTrim) {
  const key = JSON.stringify([fontName, fontSize, lineHeight, leadingTrim || '']);
  if (ctx.measure.has(key)) return ctx.measure.get(key);
  let res = null;
  try {
    await figma.loadFontAsync(fontName);
    const probe = async (chars) => {
      const t = figma.createText();
      t.fontName = fontName; t.fontSize = fontSize; t.lineHeight = lineHeight;
      if (leadingTrim) { try { t.leadingTrim = leadingTrim; } catch (e) { /* older API */ } }
      t.textAutoResize = 'WIDTH_AND_HEIGHT';
      t.characters = chars;
      t.x = -50000; t.y = -50000;
      const top = t.y;
      const v = figma.flatten([t]);
      const r = { top: v.y - top, bottom: v.y + v.height - top, h: v.height };
      v.remove();
      return r;
    };
    const one = await probe('H');
    const two = await probe('H\nH');
    if (one.h > 0) res = { baseline: one.bottom, lineGap: two.bottom - one.bottom };
  } catch (e) { res = null; }
  ctx.measure.set(key, res);
  return res;
}
// One list paragraph: render its marker + "H" with the list on, "H" plain and "• H" plain, all with the
// paragraph's own style. From those: marker x (bx), text x (tx = where wrapped lines start) and the extra
// space AE needs after the marker so the first line's text lands at tx too.
async function measureList(ctx, node, p) {
  const key = JSON.stringify(['list', p.lvl, p.ordered, p.seg.fontName, p.seg.fontSize, num(p.seg.indentation, 0), node.width]);
  if (ctx.measure.has(key)) return ctx.measure.get(key);
  let res = null;
  try {
    for (const f of node.getRangeAllFontNames(0, node.characters.length)) await figma.loadFontAsync(f);
    const chars = node.characters;
    let pe = chars.indexOf('\n', p.fi); if (pe < 0) pe = chars.length;
    const make = () => {
      const c = node.clone(); figma.currentPage.appendChild(c);
      c.relativeTransform = [[1, 0, -60000], [0, 1, -60000]];
      c.effects = []; c.strokes = [];
      const len = c.characters.length;
      if (pe < len) c.deleteCharacters(pe, len);
      if (p.fi > 0) c.deleteCharacters(0, p.fi);
      if (c.characters.length > 1) c.deleteCharacters(1, c.characters.length);
      c.insertCharacters(1, 'H', 'BEFORE'); c.deleteCharacters(0, 1);           // "H" in the paragraph's own style
      return c;
    };
    const box = (n) => { const x0 = n.x, v = figma.flatten([n]); const b = { l: v.x - x0, r: v.x + v.width - x0 }; v.remove(); return b; };
    const a = make();                                                          // list on: marker + H
    const b = make(); b.setRangeListOptions(0, 1, { type: 'NONE' });           // plain H at the paragraph start
    const c = make(); c.setRangeListOptions(0, 1, { type: 'NONE' }); c.insertCharacters(0, p.ordered ? '1. ' : '• ', 'AFTER');   // plain "• H"
    const A = box(a), B = box(b), C = box(c);
    const bx = A.l - C.l, tx = A.r - B.r, adv = C.r - B.r;                    // adv = marker + space advance
    if (isFinite(bx) && isFinite(tx) && tx > bx) res = { bx, tx, gap: (tx - bx) - adv };
  } catch (e) { res = null; }
  ctx.measure.set(key, res);
  return res;
}
const SUP_CHARS = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹', '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾', n: 'ⁿ', i: 'ⁱ' };
const SUB_CHARS = { 0: '₀', 1: '₁', 2: '₂', 3: '₃', 4: '₄', 5: '₅', 6: '₆', 7: '₇', 8: '₈', 9: '₉', '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎' };
// Figma's superscript/subscript for one text range: glyph scale and baseline raise (px, + = up), measured by
// rendering just that range (with its real OpenType setting) next to the same characters on a normal baseline.
async function measureVPos(ctx, node, sg, trim) {
  const chars = String(sg._chars || '').replace(/[\n\u2028\u2029]/g, '');
  if (!chars.trim()) return null;
  const key = JSON.stringify(['vpos', sg._fontName, sg._size, sg._lineHeight, sg.vpos, chars]);
  let res = null, c = null;
  try {
    for (const f of node.getRangeAllFontNames(0, node.characters.length)) await figma.loadFontAsync(f);
    c = node.clone();
    figma.currentPage.appendChild(c);
    c.relativeTransform = [[1, 0, -50000], [0, 1, -50000]];
    c.effects = []; c.strokes = [];
    c.textAutoResize = 'WIDTH_AND_HEIGHT';
    const len = c.characters.length;
    if (sg._fe < len) c.deleteCharacters(sg._fe, len);
    if (sg._fs > 0) c.deleteCharacters(0, sg._fs);
    try { c.paragraphSpacing = 0; c.paragraphIndent = 0; } catch (e) { /* */ }
    const topS = c.y, v = figma.flatten([c]); c = null;
    const sup = { top: v.y - topS, bottom: v.y + v.height - topS, h: v.height, w: v.width };
    ctx.vposDbg = { sup };
    v.remove();
    // the same characters, normal baseline
    const t = figma.createText();
    t.fontName = sg._fontName; t.fontSize = sg._size; t.lineHeight = sg._lineHeight;
    if (trim) { try { t.leadingTrim = trim; } catch (e) { /* */ } }
    t.textAutoResize = 'WIDTH_AND_HEIGHT'; t.characters = chars; t.x = -50000; t.y = -50000;
    const topP = t.y, w = figma.flatten([t]);
    const plain = { top: w.y - topP, bottom: w.y + w.height - topP, h: w.height };
    ctx.vposDbg.plain = plain;
    w.remove();
    const base = await measureText(ctx, sg._fontName, sg._size, sg._lineHeight, trim);
    if (sup.h > 0 && plain.h > 0 && base) {
      const scale = sup.h / plain.h, dP = plain.bottom - base.baseline;   // glyph bottom below baseline (0 for digits)
      res = { scale, shift: plain.bottom - sup.bottom - dP * (1 - scale) };
      if (!(scale > 0.2 && scale <= 1.05) || Math.abs(res.shift) > sg._size * 1.2) res = null;   // implausible → let AE fake it
    }
    // Best: the font's own superscript characters (¹ ² ³ …) – the same designed glyphs Figma draws, so weight,
    // size and spacing match exactly. Only used when they render identically to Figma's superscript.
    const up = res ? res.shift > 0 : sg.vpos === 'super', map = up ? SUP_CHARS : SUB_CHARS;   // direction from Figma's actual render
    if ([...chars].every((ch) => map[ch])) try {
      const uni = [...chars].map((ch) => map[ch]).join('');
      const u = figma.createText();
      u.fontName = sg._fontName; u.fontSize = sg._size; u.lineHeight = sg._lineHeight;
      if (trim) { try { u.leadingTrim = trim; } catch (e) { /* */ } }
      u.textAutoResize = 'WIDTH_AND_HEIGHT'; u.characters = uni; u.x = -50000; u.y = -50000;
      const topU = u.y, z = figma.flatten([u]);
      const U = { top: z.y - topU, bottom: z.y + z.height - topU, h: z.height, w: z.width };
      ctx.vposDbg.U = U;
      z.remove();
      const tol = Math.max(0.75, sg._size * 0.03);
      if (Math.abs(U.h - sup.h) <= tol && Math.abs(U.bottom - sup.bottom) <= tol && Math.abs(U.w - sup.w) <= Math.max(tol, sup.w * 0.08)) {
        res = { subst: uni, up };
      }
    } catch (e) { ctx.vposDbg.uErr = e.message; }   // font has no ¹ glyph etc. – keep the measured size/raise
  } catch (e) { if (c) try { c.remove(); } catch (e2) { /* */ } res = null; ctx.vposDbg = Object.assign(ctx.vposDbg || {}, { err: e.message }); }
  if (ctx.measure.has(key)) return ctx.measure.get(key);
  ctx.measure.set(key, res);
  return res;
}
// Exact render of the text (no effects) – AE shows it instead of the live text if the font is missing.
async function renderText(ctx, node) {
  let c = null;
  try {
    c = node.clone();
    figma.currentPage.appendChild(c);
    c.relativeTransform = [[1, 0, 0], [0, 1, 0]];
    c.effects = []; c.opacity = 1;
    const bytes = await c.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: ctx.S * Math.min(ctx.Q, 2) } });
    const rb = c.absoluteRenderBounds || c.absoluteBoundingBox;
    c.remove(); c = null;
    const size = pngSize(bytes);
    const file = addFile(ctx, cleanName(node.name) + '_text', bytes);
    return { file, iw: size.w, ih: size.h, m: rm(mul(T(rb.x * ctx.S, rb.y * ctx.S), Sc(rb.width * ctx.S / size.w, rb.height * ctx.S / size.h))) };
  } catch (e) {
    if (c) try { c.remove(); } catch (e2) { /* */ }
    return null;
  }
}
// Where Figma wraps each line of a fixed-width text box (indices of the spaces it breaks at). AE's line breaker
// rounds spacing a little differently, so a line that only just fits (or only just doesn't) can wrap one word
// differently. Found by trimming a copy word by word from the end: wherever the height drops, a line began.
// Lines exactly as Figma DRAWS them. Figma keeps a text's layout until someone edits it, so a file laid out
// earlier (another machine, another font version) can show different wraps than a fresh layout would – and
// a fresh layout is what both an edited copy and After Effects produce. So: read the drawn glyphs of an
// UNEDITED copy (flattened to outlines → one ink box per line), then work out which words make up each line
// from their widths, measured on a one-line copy.
async function measureWraps(ctx, node) {
  ctx.wrapInfo = '';
  if (node.textAutoResize === 'WIDTH_AND_HEIGHT') { ctx.wrapInfo = 'auto width'; return null; }
  if (node.textAlignHorizontal === 'JUSTIFIED') { ctx.wrapInfo = 'justified'; return null; }
  if (node.textTruncation === 'ENDING') { ctx.wrapInfo = 'truncated'; return null; }
  const chars = node.characters;
  if (!chars.length || chars.length > 4000 || chars.indexOf(' ') < 0) { ctx.wrapInfo = 'skipped (' + chars.length + ' chars)'; return null; }
  let shown = null, why = '';
  try { shown = await wrapsAsDrawn(ctx, node); } catch (e) { why = e.message; }
  if (shown) { ctx.wrapInfo = 'as drawn: ' + shown.lines + ' lines, wraps at ' + JSON.stringify(shown.wraps.map((i) => chars.slice(Math.max(0, i - 8), i) + '|')); return shown.wraps; }
  const fresh = await measureWrapsFresh(ctx, node);
  ctx.wrapInfo = '(couldn\'t read drawn lines' + (why ? ': ' + why : '') + ') ' + ctx.wrapInfo;
  return fresh;
}
function pathBoxes(data) {
  // Figma path data: absolute M/L/C/Q/Z with x y pairs → bounding box per subpath
  const out = []; let cur = null;
  const tok = String(data).match(/[MLCQZmlcqz]|-?\d*\.?\d+(?:e-?\d+)?/g) || [];
  let nums = [];
  const flush = () => { for (let i = 0; i + 1 < nums.length; i += 2) { const x = +nums[i], y = +nums[i + 1]; if (!cur) continue; cur.l = Math.min(cur.l, x); cur.r = Math.max(cur.r, x); cur.t = Math.min(cur.t, y); cur.b = Math.max(cur.b, y); } nums = []; };
  for (const t of tok) {
    if (/[A-Za-z]/.test(t)) {
      flush();
      if (t === 'M' || t === 'm') { cur = { l: Infinity, r: -Infinity, t: Infinity, b: -Infinity }; out.push(cur); }
    } else nums.push(t);
  }
  flush();
  return out.filter((b) => isFinite(b.l) && isFinite(b.t));
}
async function wrapsAsDrawn(ctx, node) {
  const chars = node.characters;
  for (const f of node.getRangeAllFontNames(0, chars.length)) await figma.loadFontAsync(f);
  let maxSize = 0, minSize = Infinity;
  for (const sg of node.getStyledTextSegments(['fontSize'])) { maxSize = Math.max(maxSize, sg.fontSize); minSize = Math.min(minSize, sg.fontSize); }
  // 1) the drawn lines: flatten an unedited copy (no characters touched → no re-layout)
  let c = node.clone(); figma.currentPage.appendChild(c);
  let v = null, boxes = [];
  try {
    c.relativeTransform = [[1, 0, -80000], [0, 1, -80000]];
    c.effects = []; c.strokes = [];
    try { c.setRangeTextDecoration(0, chars.length, 'NONE'); } catch (e) { /* */ }   // underlines would widen the lines
    const x0 = c.x, y0 = c.y;
    v = figma.flatten([c]); c = null;
    for (const vp of v.vectorPaths || []) for (const b of pathBoxes(vp.data)) boxes.push({ l: b.l + v.x - x0, r: b.r + v.x - x0, t: b.t + v.y - y0, b: b.b + v.y - y0 });
  } finally { if (c) try { c.remove(); } catch (e) { /* */ } if (v) try { v.remove(); } catch (e) { /* */ } }
  if (!boxes.length) throw new Error('no outlines');
  boxes.forEach((b) => { b.cy = (b.t + b.b) / 2; });
  boxes.sort((a, b) => a.cy - b.cy);
  const lines = []; const gapMin = Math.max(1, minSize * 0.3);
  for (const b of boxes) {
    const L = lines[lines.length - 1];
    if (L && b.cy - L.lastCy <= gapMin) { L.l = Math.min(L.l, b.l); L.r = Math.max(L.r, b.r); L.lastCy = b.cy; }
    else lines.push({ l: b.l, r: b.r, lastCy: b.cy });
  }
  // 2) word widths on one line: a copy with every break turned into a space, auto width, trimmed from the end
  const isBreak = (ch) => ch === '\n' || ch === '\r' || ch === ' ' || ch === ' ';
  const opp = new Set();                                       // indices where a line may end (exclusive)
  for (let i = 1; i <= chars.length; i++) {
    const a = chars[i - 1], b = chars[i];
    if (i === chars.length || isBreak(b)) opp.add(i);
    else if (b === ' ' && a !== ' ' && !isBreak(a)) opp.add(i);
    else if (/[\-‐-—\/]/.test(a) && b !== ' ' && !isBreak(b)) opp.add(i);
  }
  const starts = new Set();                                    // first visible character of a possible line
  for (let i = 0; i < chars.length; i++) if (chars[i] !== ' ' && !isBreak(chars[i]) && (i === 0 || chars[i - 1] === ' ' || isBreak(chars[i - 1]) || opp.has(i))) starts.add(i);
  const need = [...new Set([...opp, ...starts])].sort((a, b) => b - a);
  if (need.length > 1500) throw new Error('too long');
  c = node.clone(); figma.currentPage.appendChild(c);
  const P = {};
  try {
    c.relativeTransform = [[1, 0, -80000], [0, 1, -80000]];
    try { c.maxLines = null; } catch (e) { /* */ }
    for (let i = 0; i < chars.length; i++) if (isBreak(chars[i])) { c.insertCharacters(i, ' ', 'BEFORE'); c.deleteCharacters(i + 1, i + 2); }
    try { c.setRangeListOptions(0, chars.length, { type: 'NONE' }); } catch (e) { /* */ }
    try { c.paragraphIndent = 0; } catch (e) { /* */ }
    c.textAutoResize = 'WIDTH_AND_HEIGHT';
    let len = chars.length;
    // each prefix is measured with an "H" on the end, so trailing spaces always count (the H cancels out)
    for (const i of need) {
      if (i < len) { c.deleteCharacters(i, len); len = i; }
      c.insertCharacters(i, 'H', i > 0 ? 'BEFORE' : 'AFTER'); P[i] = c.width; c.deleteCharacters(i, i + 1);
    }
  } finally { if (c) try { c.remove(); } catch (e) { /* */ } }
  // 3) walk the text: each drawn line = the run of words whose width matches that line's ink width
  // bullet / numbered paragraphs: the marker is drawn on the first line but isn't in the word widths →
  // measure the gap from marker to text (the same probe the hanging indent uses) and leave it out
  const hangAt = {};
  const isPara = (i) => i === 0 || chars[i - 1] === '\n' || chars[i - 1] === '\r' || chars[i - 1] === '\u2029';
  const lsegs = node.getStyledTextSegments(['listOptions', 'indentation', 'fontName', 'fontSize']);
  for (const sg of lsegs) {
    if (!sg.listOptions || !sg.listOptions.type || sg.listOptions.type === 'NONE') continue;
    for (let i = sg.start; i < sg.end; i++) {
      if (!isPara(i) || isBreak(chars[i])) continue;
      const m = await measureList(ctx, node, { fi: i, lvl: num(sg.indentation, 0), ordered: sg.listOptions.type === 'ORDERED', seg: sg });
      if (!m) throw new Error('list marker not measured');
      hangAt[i] = m.tx - m.bx;
    }
  }
  const tol = Math.max(1.5, minSize * 0.5), wraps = [];
  let li = 0, s = 0, paraStart = 0, firstLine = true;
  while (s < chars.length) {
    while (s < chars.length && (chars[s] === ' ' || isBreak(chars[s]))) {   // skip spaces / empty paragraphs
      if (isBreak(chars[s]) && chars[s] !== '\u2028') { paraStart = s + 1; firstLine = true; }
      s++;
    }
    if (s >= chars.length) break;
    const line = lines[li];
    if (!line) throw new Error('more text than drawn lines');
    const hang = firstLine && hangAt[paraStart] !== undefined ? hangAt[paraStart] : 0;
    const target = line.r - line.l - hang;
    firstLine = false;
    let best = -1, bestErr = Infinity, second = Infinity;
    for (let m = s + 1; m <= chars.length; m++) {
      if (opp.has(m)) {
        const w = P[m] - P[s], err = Math.abs(w - target);
        if (err < bestErr) { second = bestErr; bestErr = err; best = m; } else if (err < second) second = err;
        if (w > target + tol * 4) break;
      }
      if (m < chars.length && isBreak(chars[m])) break;           // a line never runs past a hard break
    }
    if (best < 0 || bestErr > tol) throw new Error('line ' + (li + 1) + ' off by ' + Math.round(bestErr) + 'px');
    if (second - bestErr < minSize * 0.25) throw new Error('line ' + (li + 1) + ' ambiguous');
    if (best < chars.length && chars[best] === ' ' && chars[best + 1] !== ' ' && !isBreak(chars[best + 1])) wraps.push(best);
    s = best; li++;
  }
  if (li !== lines.length) throw new Error(lines.length + ' drawn lines, ' + li + ' matched');
  return { wraps, lines: lines.length };
}
async function measureWrapsFresh(ctx, node) {
  let c = null;
  ctx.wrapInfo = '';
  try {
    if (node.textAutoResize === 'WIDTH_AND_HEIGHT') { ctx.wrapInfo = 'auto width'; return null; }
    if (node.textAlignHorizontal === 'JUSTIFIED') { ctx.wrapInfo = 'justified'; return null; }
    if (node.textTruncation === 'ENDING') { ctx.wrapInfo = 'truncated'; return null; }
    const chars = node.characters;
    if (!chars.length || chars.length > 4000 || chars.indexOf(' ') < 0) { ctx.wrapInfo = 'skipped (' + chars.length + ' chars)'; return null; }
    for (const f of node.getRangeAllFontNames(0, chars.length)) await figma.loadFontAsync(f);
    const isBreak = (ch) => ch === '\n' || ch === '\r' || ch === '\u2028' || ch === '\u2029';
    const ends = [];                                       // prefix lengths that end right after a word
    for (let i = 1; i < chars.length; i++) if (chars[i] === ' ' && chars[i - 1] !== ' ' && !isBreak(chars[i - 1])) ends.push(i);
    if (!ends.length || ends.length > 600) { ctx.wrapInfo = 'skipped (' + ends.length + ' words)'; return null; }
    c = node.clone(); figma.currentPage.appendChild(c);
    c.relativeTransform = [[1, 0, -70000], [0, 1, -70000]];
    c.effects = []; c.strokes = [];
    try { c.maxLines = null; } catch (e) { /* */ }
    c.textAutoResize = 'HEIGHT';
    if (Math.abs(c.width - node.width) > 0.01) c.resize(node.width, c.height);
    let minSize = Infinity;
    for (const sg of node.getStyledTextSegments(['fontSize'])) minSize = Math.min(minSize, sg.fontSize);
    const tol = (isFinite(minSize) ? minSize : 12) * 0.5;
    const H = {};
    let len = chars.length;
    H[len] = c.height;
    for (let k = ends.length - 1; k >= 0; k--) { c.deleteCharacters(ends[k], len); len = ends[k]; H[ends[k]] = c.height; }
    c.remove(); c = null;
    const stops = ends.concat([chars.length]), wraps = [];
    for (let k = 0; k + 1 < stops.length; k++) {
      const b = stops[k], b2 = stops[k + 1], word = chars.slice(b + 1, b2);
      if (chars[b + 1] === ' ' || /[\n\r\u2028\u2029\-\u2010-\u2014\/]/.test(word)) continue;   // only clean single-space breaks
      if (H[b2] - H[b] > tol) wraps.push(b);                     // adding this word started a new line
    }
    ctx.wrapInfo = 'Figma lines ' + Math.round(H[chars.length] / Math.max(1, H[ends[0]])) + ', wraps at ' + JSON.stringify(wraps.map((i) => chars.slice(Math.max(0, i - 8), i) + '|'));
    return wraps;
  } catch (e) {
    ctx.wrapInfo = 'error: ' + e.message;
    if (c) try { c.remove(); } catch (e2) { /* */ }
    return null;
  }
}
async function measureInk(ctx, node) {
  let c = null;
  try {
    if (!node.characters.length) return null;
    for (const f of node.getRangeAllFontNames(0, node.characters.length)) await figma.loadFontAsync(f);
    c = node.clone();
    figma.currentPage.appendChild(c);
    c.relativeTransform = [[1, 0, 0], [0, 1, 0]];           // un-rotated, at page origin → bounds are node-local
    c.effects = []; c.strokes = [];
    c.setRangeTextDecoration(0, c.characters.length, 'NONE'); // AE draws decorations separately
    const v = figma.flatten([c]); c = null;
    const out = [v.x, v.y, v.width, v.height].map((x) => r6(x * ctx.S));
    v.remove();
    return out[2] > 0 && out[3] > 0 ? out : null;
  } catch (e) {
    if (c) try { c.remove(); } catch (e2) { /* */ }
    return null;
  }
}
// Figma case + OpenType small caps (Type details ▸ SMCP / C2SC) → 'all' | 'small' | 'allsmall' | null
function capsOf(s) {
  if (s.textCase === 'UPPER') return 'all';
  const f = s.openTypeFeatures || {};
  if (s.textCase === 'SMALL_CAPS_FORCED') return 'allsmall';              // "Forced small caps": capitals too
  if (s.textCase === 'SMALL_CAPS') return f.C2SC ? 'allsmall' : 'small';
  if (f.SMCP && f.C2SC) return 'allsmall';
  if (f.SMCP) return 'small';
  if (f.C2SC) return 'allsmall';
  return null;
}
function vertPos(f) {
  if (!f) return null;
  if (f.SUPS) return 'super';
  if (f.SUBS || f.SINF) return 'sub';
  return null;
}
function lineHeightPx(lh, size) {
  if (!lh || isMixed(lh) || lh.unit === 'AUTO') return null;
  return lh.unit === 'PIXELS' ? lh.value : lh.value / 100 * size;
}
function trackingOf(ls, size) {
  if (!ls || isMixed(ls)) return 0;
  return ls.unit === 'PERCENT' ? ls.value * 10 : (ls.value / size) * 1000;
}
function applyCase(str, c) {
  if (c === 'LOWER') return str.toLowerCase();
  if (c === 'TITLE') return str.replace(/(^|[\s\-—(\[{"'])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
  return str;
}

async function exportText(ctx, node, base) {
  const S = ctx.S;
  const fields = ['fontName', 'fontSize', 'fills', 'letterSpacing', 'lineHeight', 'textCase', 'textDecoration', 'fontWeight'];
  let segs;
  // openTypeFeatures carries Figma's "Vertical position" (superscript / subscript)
  segs = null;
  for (const extra of [['listOptions', 'indentation', 'openTypeFeatures'], ['listOptions', 'indentation'], []]) {
    try { segs = node.getStyledTextSegments(fields.concat(extra)); break; } catch (e) { /* older API */ }
  }

  // segments came back without openTypeFeatures (older API) → ask per range, per character if mixed
  if (segs.length && !('openTypeFeatures' in segs[0]) && typeof node.getRangeOpenTypeFeatures === 'function') {
    const split = [];
    for (const sg of segs) {
      let f = null; try { f = node.getRangeOpenTypeFeatures(sg.start, sg.end); } catch (e) { /* */ }
      if (f !== MIXED) { split.push(Object.assign({}, sg, { openTypeFeatures: f })); continue; }
      let cur = null;
      for (let i = sg.start; i < sg.end; i++) {
        let fi = null; try { fi = node.getRangeOpenTypeFeatures(i, i + 1); } catch (e) { /* */ }
        const vp = vertPos(fi);
        if (cur && cur.vp === vp) { cur.seg.end = i + 1; cur.seg.characters += sg.characters[i - sg.start]; }
        else { cur = { vp, seg: Object.assign({}, sg, { start: i, end: i + 1, characters: sg.characters[i - sg.start], openTypeFeatures: fi }) }; split.push(cur.seg); }
      }
    }
    segs = split;
  }

  // Build output string: case transforms, list prefixes, AE line breaks (\r).
  let out = '';
  const outSegs = [], paras = [];
  let lineStart = true, ordinal = {}, prevCR = false;
  const fig2out = {};
  let gradientPaint = null;
  const ROMAN = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x', 'xi', 'xii', 'xiii', 'xiv', 'xv', 'xvi', 'xvii', 'xviii', 'xix', 'xx'];
  const ordLabel = (n, lvl) => lvl % 3 === 1 ? (n <= 26 ? String.fromCharCode(96 + n) : String(n)) : lvl % 3 === 2 ? (ROMAN[n - 1] || String(n)) : String(n);
  for (const s of segs) {
    const startOut = out.length;
    const txt = applyCase(s.characters, s.textCase);
    const sameLen = txt.length === s.characters.length;
    for (let k = 0; k < txt.length; k++) {
      const ch = txt[k];
      // Windows line ending (pasted text): one break, not two – also when \r and \n fall in different style runs
      if (ch === '\n' && prevCR) { prevCR = false; continue; }
      prevCR = ch === '\r';
      const isList = !!(s.listOptions && s.listOptions.type && s.listOptions.type !== 'NONE');
      if (lineStart && ch !== '\u2028' && !isList) ordinal = {};   // a normal paragraph ends the list: numbering restarts
      if (lineStart && isList && ch !== '\u2028') {
        const lvl = num(s.indentation, 0), ordered = s.listOptions.type === 'ORDERED';
        for (const l in ordinal) if (+l > lvl) delete ordinal[l];   // back to a parent item: sub-numbering restarts
        if (!ordered) delete ordinal[lvl];
        // marker only – the indent is a real hanging indent, measured from Figma below (no leading spaces)
        let marker;
        if (ordered) { ordinal[lvl] = (ordinal[lvl] || 0) + 1; marker = ordLabel(ordinal[lvl], lvl) + '. '; } else marker = '• ';
        paras.push({ s: out.length, ml: marker.length, lvl, ordered, fi: s.start + k, seg: s });
        out += marker;
      }
      if (sameLen) fig2out[s.start + k] = out.length;
      if (ch === '\u2028') { out += '\u0003'; lineStart = false; }   // soft line break → AE soft return (same paragraph)
      else if (ch === '\n' || ch === '\r' || ch === '\u2029') { out += '\r'; lineStart = true; }
      else { out += ch; lineStart = false; }
    }
    const fills = visiblePaints(s.fills);
    const top = fills[fills.length - 1];
    let color = [0, 0, 0], fa = 1;
    if (top) {
      if (top.type === 'SOLID') { color = rgb(top.color); fa = num(top.opacity, 1); }
      else if (top.gradientStops) {
        const st = top.gradientStops[0].color; color = rgb(st); fa = num(top.opacity, 1);
        if (!gradientPaint) gradientPaint = top;
      } else warn(ctx, node, 'text ' + top.type.toLowerCase() + ' fill → solid');
    }
    if (s.textDecoration && s.textDecoration !== 'NONE') warn(ctx, node, 'text ' + s.textDecoration.toLowerCase() + ' not native in AE (drawn as shape line)');
    outSegs.push({
      s: startOut, e: out.length,
      font: { family: s.fontName.family, style: s.fontName.style }, weight: s.fontWeight,
      size: r6(s.fontSize * S), color, fa: r6(fa), visibleFill: !!top,
      tracking: r6(trackingOf(s.letterSpacing, s.fontSize)),
      lh: lineHeightPx(s.lineHeight, s.fontSize) === null ? null : r6(lineHeightPx(s.lineHeight, s.fontSize) * S),
      caps: capsOf(s),
      vpos: vertPos(s.openTypeFeatures),
      _fs: s.start, _fe: s.end, _chars: s.characters, _otf: s.openTypeFeatures,
      deco: s.textDecoration && s.textDecoration !== 'NONE' ? s.textDecoration : null,
      _lineHeight: s.lineHeight, _fontName: s.fontName, _size: s.fontSize,
    });
  }

  // first-line metrics: measured from Figma's own renderer (exact baseline).
  const br = out.indexOf('\r') < 0 ? out.length : out.indexOf('\r');
  let first = outSegs[0];
  for (const sg of outSegs) if (sg.s < Math.max(br, 1) && sg.size > first.size) first = sg;
  let trim = null; try { trim = node.leadingTrim; } catch (e) { /* */ }
  const meas = first ? await measureText(ctx, first._fontName, first._size, first._lineHeight, trim) : null;
  let baseline, lineGap;
  if (meas) { baseline = meas.baseline * S; lineGap = meas.lineGap * S; }
  else {
    const sz = first ? first.size : 12 * S;
    const lh = first && first.lh ? first.lh : sz * 1.2;
    baseline = (lh - sz * 1.2) / 2 + sz * 0.95; lineGap = lh;
    warn(ctx, node, 'font "' + (first ? first.font.family + ' ' + first.font.style : '?') + '" unavailable in Figma for measuring – baseline estimated');
  }
  // superscript / subscript: measure exactly how Figma draws them (size + raise), so AE matches 1:1
  for (const sg of outSegs) {
    if (!sg.vpos) continue;
    const m = await measureVPos(ctx, node, sg, trim);
    if (m && m.subst && [...out.slice(sg.s, sg.e)].map((ch) => (m.up ? SUP_CHARS : SUB_CHARS)[ch] || '?').join('') === m.subst) {
      out = out.slice(0, sg.s) + m.subst + out.slice(sg.e); sg.vpos = null; sg.subst = true;   // real ¹ glyphs, normal baseline
    } else if (m && m.scale) { sg.vscale = r6(m.scale); sg.vshift = r6(m.shift * S); sg.vpos = m.shift >= 0 ? 'super' : 'sub'; }
    ctx.vposDbg = null;
  }
  for (const sg of outSegs) { if (sg.lh === null) sg.lh = r6(lineGap * (sg.size / (first ? first.size : sg.size))); delete sg._lineHeight; delete sg._fontName; delete sg._size; delete sg._fs; delete sg._fe; delete sg._chars; delete sg._otf; }

  // bullet / numbered lists: where Figma draws the marker and where the text (and every wrapped line) starts
  const listParas = [];
  if (paras.length && (node.textAlignHorizontal === 'LEFT' || node.textAlignHorizontal === 'JUSTIFIED')) {
    for (const p of paras) {
      const m = await measureList(ctx, node, p);
      if (m) listParas.push({ s: p.s, ml: p.ml, bx: r6(m.bx * S), tx: r6(m.tx * S), gap: r6(m.gap * S) });
    }
  }

  // exact glyph (ink) bounds as Figma renders them, in node-local space – AE aligns its own glyphs to this.
  // Figma's own line wraps, as positions in the output string (spaces AE turns into soft returns)
  const figWraps = await measureWraps(ctx, node);
  const wraps = (figWraps || []).map((i) => fig2out[i]).filter((i) => i >= 0 && out[i] === ' ');
  const ink = await measureInk(ctx, node);
  const img = await renderText(ctx, node);

  // strokes on text
  const strokes = await exportPaints(ctx, node, node.strokes, base.w, base.h);
  const st = strokes.length ? strokeInfo(ctx, node) : null;

  ctx.stats.text++;
  return Object.assign(base, {
    kind: 'text',
    text: {
      chars: out, segs: outSegs, paras: listParas, wraps, wrapInfo: ctx.wrapInfo + (figWraps && wraps.length !== figWraps.length ? ' (' + (figWraps.length - wraps.length) + ' not mapped)' : ''),
      autoResize: node.textAutoResize, alignH: node.textAlignHorizontal, alignV: node.textAlignVertical,
      baseline: r6(baseline), lineGap: r6(lineGap), ink, img,
      paraSpacing: r6(num(node.paragraphSpacing, 0) * S), paraIndent: r6(num(node.paragraphIndent, 0) * S),
      truncate: node.textTruncation === 'ENDING',
      gradient: gradientPaint ? await exportPaint(ctx, node, gradientPaint, base.w, base.h) : null,
      stroke: st && strokes[0] && strokes[0].type === 'solid' ? { color: strokes[0].color, w: st.w, align: st.align } : null,
    },
    effects: exportEffects(ctx, node),
  }, await exactShadow(ctx, node));
}

// ------------------------------------------------------------------ rasterising fallback
async function rasterNode(ctx, node, base, reason, onlySelf) {
  let target = node, temp = null;
  if (onlySelf) {
    // Frame background only: clone without children onto the page.
    temp = node.clone();
    figma.currentPage.appendChild(temp);
    temp.relativeTransform = node.absoluteTransform;
    for (const c of [...temp.children]) c.remove();
    target = temp;
  }
  let bytes;
  try {
    bytes = await target.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: ctx.S * ctx.Q } });
  } finally { /* keep temp for bounds */ }
  const rb = target.absoluteRenderBounds || target.absoluteBoundingBox;
  if (temp) temp.remove();
  const size = pngSize(bytes) || { w: Math.round(rb.width * ctx.S * ctx.Q), h: Math.round(rb.height * ctx.S * ctx.Q) };
  const file = addFile(ctx, cleanName(node.name), bytes);
  ctx.stats.rasters++;
  if (reason) warn(ctx, node, 'rasterised: ' + reason);
  const absM = mul(T(rb.x, rb.y), Sc(rb.width / size.w, rb.height / size.h));
  return Object.assign({}, base, {
    kind: 'raster', file, m: rootSpace(ctx, absM), w: size.w, h: size.h, iw: size.w, ih: size.h, rb: [0, 0, size.w, size.h],
    opacity: onlySelf ? 1 : base.opacity, effects: [],
  });
}

// Pixel-for-pixel screenshot of the whole frame as Figma renders it (1 image px = 1 comp px).
async function referenceShot(ctx, root) {
  const bytes = await root.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: ctx.S } });
  const rb = root.absoluteRenderBounds || root.absoluteBoundingBox;
  const size = pngSize(bytes) || { w: Math.round(rb.width * ctx.S), h: Math.round(rb.height * ctx.S) };
  const file = uniqueFile(ctx, 'reference_' + root.name, 'png');
  ctx.files.push({ name: file, bytes });
  ctx.fileKeys[file] = 'R' + hashBytes(bytes);
  const absM = mul(T(rb.x, rb.y), Sc(rb.width / size.w, rb.height / size.h));
  return { file, m: rootSpace(ctx, absM), w: size.w, h: size.h };
}

// Exact drop shadows: Figma renders the node twice inside a fixed clip frame – with only its drop
// shadows and with no effects – and the UI subtracts the two to get the shadow alone (pixel match).
async function exactShadow(ctx, node) {
  if (!ctx.exactShadows) return {};
  const drops = (node.effects || []).filter((e) => e.visible !== false && e.type === 'DROP_SHADOW');
  if (!drops.length) return {};
  let frame = null;
  try {
    const rb = node.absoluteRenderBounds;
    if (!rb || rb.width < 1 || rb.height < 1) return {};
    frame = figma.createFrame();
    frame.name = 'figae shadow probe'; frame.fills = []; frame.clipsContent = true;
    figma.currentPage.appendChild(frame);
    frame.x = rb.x; frame.y = rb.y; frame.resizeWithoutConstraints(rb.width, rb.height);
    const c = node.clone();
    frame.appendChild(c);
    const A = node.absoluteTransform;
    c.relativeTransform = [[A[0][0], A[0][1], A[0][2] - rb.x], [A[1][0], A[1][1], A[1][2] - rb.y]];
    c.opacity = 1;
    if ('isMask' in c && c.isMask) c.isMask = false;
    c.effects = drops;
    const scale = { format: 'PNG', constraint: { type: 'SCALE', value: ctx.S * Math.min(ctx.Q, 2) } };
    const withShadow = await frame.exportAsync(scale);
    c.effects = [];
    const without = await frame.exportAsync(scale);
    frame.remove(); frame = null;
    const size = pngSize(withShadow);
    const file = addFile(ctx, cleanName(node.name) + '_shadow', null, { a: withShadow, b: without });
    const absM = mul(T(rb.x, rb.y), Sc(rb.width / size.w, rb.height / size.h));
    return {
      shadowImg: { file, m: rootSpace(ctx, absM), w: size.w, h: size.h },
      // the rendered shadow replaces the layer-style versions (kept as fallback if the render comes back empty)
      effects: exportEffects(ctx, node).filter((e) => e.type !== 'dropShadow'),
      shadowFallback: exportEffects(ctx, node).filter((e) => e.type === 'dropShadow'),
    };
  } catch (e) {
    if (frame) try { frame.remove(); } catch (e2) { /* */ }
    warn(ctx, node, 'exact shadow failed (' + e.message + ') – using layer style');
    return {};
  }
}
// Content fingerprint for every frame/group, independent of where it sits: identical logos and
// component instances get the same sig, so AE can build them once and reuse the precomp.
function fnv(str) { let h = 0x811c9dc5, g = 0x01000193; for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h = Math.imul(h ^ c, 16777619); g = Math.imul(g ^ c, 2246822519); } return (h >>> 0).toString(36) + (g >>> 0).toString(36); }
function relTo(P, M) { return rm(mul(inv(P), M)).map((v) => Math.round(v * 100) / 100); }
function assignSigs(n) {
  const parts = [];
  for (const k of Object.keys(n).sort()) {
    if (k === 'id' || k === 'm' || k === 'children' || k === 'sig' || k === 'name' || k === 'tags') continue;
    let v = n[k];
    if (v && typeof v === 'object' && !Array.isArray(v) && Array.isArray(v.m) && v.file) v = Object.assign({}, v, { m: relTo(n.m, v.m) }); // root-space sub-images
    parts.push(k + ':' + JSON.stringify(v));
  }
  for (const c of n.children || []) parts.push('[' + c.name + '|' + fnv(assignSigs(c)) + '@' + relTo(n.m, c.m).join(',') + ']');
  const str = parts.join(';');
  if (n.kind === 'container') n.sig = fnv(str);
  return str;
}
function countTree(n) { let c = 1; if (n.children) for (const k of n.children) c += countTree(k); return c; }

// ------------------------------------------------------------------ node serialisation
function nameTags(name) {
  const n = name || '';
  return {
    raster: /(#raster|\[raster\])/i.test(n),
    precomp: /(#precomp|\[precomp\])/i.test(n),
    skip: /(#skip|\[skip\])/i.test(n),
    flat: /(#flat|\[flat\])/i.test(n),
  };
}
// Figma's default names ("Frame 427", "Rectangle 12", "Group 8") say nothing in an AE timeline:
// photos become "Image", frames/groups take the words of their first text. Names designers chose stay.
const DEFAULT_NAME = /^(Frame|Group|Rectangle|Ellipse|Vector|Line|Polygon|Star|Union|Subtract|Intersect|Exclude|Boolean|Image|Component|Instance|Section|Arrow|Auto layout)( \d+)?( copy( \d+)?)?$/i;
function hasImageFill(n) { try { return visiblePaints(n.fills).some((p) => p.type === 'IMAGE'); } catch (e) { return false; } }
function firstText(n, depth) {
  if (depth > 6 || n.visible === false) return null;
  if (n.type === 'TEXT') { const t = String(n.characters || '').replace(/\s+/g, ' ').trim(); return t || null; }
  for (const c of n.children || []) { const t = firstText(c, depth + 1); if (t) return t; }
  return null;
}
function anyImage(n, depth) { if (depth > 6) return false; if (hasImageFill(n)) return true; return (n.children || []).some((c) => anyImage(c, depth + 1)); }
function readableName(node) {
  const raw = cleanName(node.name);
  if (!DEFAULT_NAME.test(raw) || node.type === 'TEXT') return raw;
  if (!node.children && hasImageFill(node)) return 'Image';
  if (node.children) {
    const t = firstText(node, 0);
    if (t) return t.length > 32 ? t.slice(0, 31).trim() + '…' : t;
    if (anyImage(node, 0)) return 'Image';
  }
  return raw;
}
function cleanName(name) { return (name || '').replace(/\s*(#raster|#precomp|#skip|#flat|\[raster\]|\[precomp\]|\[skip\]|\[flat\])\s*/gi, ' ').trim() || 'Layer'; }

// Does this frame's clipping actually hide anything? Frames nested in frames usually clip nothing –
// then AE needs no precomp for them (fewer, flatter precomps).
function clipMatters(node) {
  const t = node.absoluteTransform, bb = node.absoluteBoundingBox;
  if (!t || !bb || Math.abs(t[0][1]) > 1e-6 || Math.abs(t[1][0]) > 1e-6) return true;   // rotated: keep it simple
  let r = 0; try { r = Math.max(...cornerRadii({ S: 1 }, node)); } catch (e) { r = 0; }
  const F = rectOf(bb);
  for (const c of node.children || []) {
    if (c.visible === false) continue;
    let rb = null; try { rb = c.absoluteRenderBounds; } catch (e) { return true; }
    if (!rb) continue;
    const q = rectOf(rb);
    if (q.x < F.x - 0.5 || q.y < F.y - 0.5 || q.r > F.r + 0.5 || q.b > F.b + 0.5) return true;   // sticks out
    // rounded corners: anything reaching into a corner gets its corner cut off
    if (r > 0.01 && !(q.x >= F.x + r - 0.5 && q.r <= F.r - r + 0.5) && !(q.y >= F.y + r - 0.5 && q.b <= F.b - r + 0.5)) return true;
  }
  return false;
}

// ------------------------------------------------------------------ cleanup: skip what never shows
const rectOf = (b) => (b ? { x: b.x, y: b.y, r: b.x + b.width, b: b.y + b.height } : null);
const overlaps = (a, c) => a.x < c.r - 0.01 && c.x < a.r - 0.01 && a.y < c.b - 0.01 && c.y < a.b - 0.01;
const contains = (a, c) => c.x >= a.x - 0.01 && c.y >= a.y - 0.01 && c.r <= a.r + 0.01 && c.b <= a.b + 0.01;
// why a layer can't be seen (or null if it can)
function unseen(ctx, node) {
  if (!ctx.cleanup || node === ctx.rootNode) return null;
  if (node.visible === false) return 'hidden';
  if (num(node.opacity, 1) <= 0.001) return 'transparent';
  if (node.isMask) return null;                                // masks shape what's visible – always kept
  let rb = null; try { rb = node.absoluteRenderBounds; } catch (e) { return null; }
  if (rb === null) return 'empty';                             // Figma renders nothing (no paint, empty text…)
  const r = rectOf(rb);
  for (const c of ctx.clips) if (!overlaps(c, r)) return 'outside';
  return null;
}
// a solid, unrotated, opaque rectangle/frame hides everything fully underneath it
function opaqueCover(n) {
  if (n.visible === false || n.isMask || num(n.opacity, 1) < 0.999) return null;
  if (!['RECTANGLE', 'FRAME', 'COMPONENT', 'INSTANCE'].includes(n.type)) return null;
  if (!['NORMAL', 'PASS_THROUGH'].includes(n.blendMode || 'NORMAL')) return null;
  const t = n.absoluteTransform; if (!t || Math.abs(t[0][1]) > 1e-6 || Math.abs(t[1][0]) > 1e-6) return null;
  if ((n.effects || []).some((e) => e.visible !== false && e.type === 'LAYER_BLUR')) return null;
  const fills = visiblePaints(n.fills); const top = fills[fills.length - 1];
  if (!top || top.type !== 'SOLID' || num(top.opacity, 1) < 0.999 || (top.blendMode && top.blendMode !== 'NORMAL')) return null;
  const bb = n.absoluteBoundingBox; if (!bb) return null;
  let rad = 0; try { rad = Math.max(...cornerRadii({ S: 1 }, n)); } catch (e) { rad = 0; }
  const k = rad * 0.5;                                         // stay clear of rounded / smoothed corners
  return { x: bb.x + k, y: bb.y + k, r: bb.x + bb.width - k, b: bb.y + bb.height - k };
}
function coveredChildren(ctx, kids) {
  const out = new Set();
  if (!ctx.cleanup || kids.some((k) => k.isMask)) return out;  // masks change what's on top – leave alone
  const covers = kids.map(opaqueCover);
  for (let i = 0; i < kids.length; i++) {
    let rb = null; try { rb = kids[i].absoluteRenderBounds; } catch (e) { continue; }
    if (!rb) continue;
    const r = rectOf(rb);
    for (let j = i + 1; j < kids.length; j++) if (covers[j] && contains(covers[j], r)) { out.add(i); break; }
  }
  return out;
}

async function serialize(ctx, node) {
  if (node.type === 'SLICE') return null;
  const why = unseen(ctx, node);
  if (why) { ctx.cleaned[why]++; return null; }
  if (node.visible === false && !ctx.includeHidden) return null;
  const tags = nameTags(node.name);
  if (tags.skip) return null;
  ctx.count++;
  if (ctx.count % 10 === 0) progress('Reading layers… ' + ctx.count + ' of ' + ctx.total, 5 + 70 * ctx.count / ctx.total);
  ctx.stats.layers++;

  const S = ctx.S;
  const base = {
    id: node.id, name: readableName(node), rawName: cleanName(node.name), type: node.type,
    visible: node.visible !== false, locked: !!node.locked,
    opacity: r6(num(node.opacity, 1)), blend: node.blendMode || 'NORMAL',
    m: rootSpace(ctx, fromFigma(node.absoluteTransform)),
    w: r6(node.width * S), h: r6(node.height * S),
    mask: node.isMask ? (node.maskType || 'ALPHA') : null,
    rb: localRenderBounds(ctx, node),
    tags,
  };
  if (node.type === 'TEXT' && node.autoRename !== false) base.autoName = true;

  if (tags.raster) return rasterNode(ctx, node, base, null);

  const isContainer = isFrameLike(node) || node.type === 'GROUP';
  if (isContainer) {
    if (hasUnsupportedEffect(node) && ctx.rasterUnsupported) return rasterNode(ctx, node, base, 'noise/texture/glass effect');
    const children = [];
    const kids = node.children || [], covered = coveredChildren(ctx, kids);
    const clip = ctx.cleanup && node.clipsContent && node.absoluteBoundingBox ? rectOf(node.absoluteBoundingBox) : null;
    if (clip) ctx.clips.push(clip);
    try {
      for (let i = 0; i < kids.length; i++) {
        if (covered.has(i)) { ctx.cleaned.covered++; continue; }
        const s = await serialize(ctx, kids[i]); if (s) children.push(s);
      }
    } finally { if (clip) ctx.clips.pop(); }
    const out = Object.assign(base, {
      kind: 'container', isFrame: node.type !== 'GROUP',
      clip: !!node.clipsContent, rb: localRenderBounds(ctx, node),
      effects: exportEffects(ctx, node), children,
    }, await exactShadow(ctx, node));
    if (node.type !== 'GROUP') {
      const fillsRaw = visiblePaints(node.fills), strokesRaw = visiblePaints(node.strokes);
      out.radius = cornerRadii(ctx, node);
      if ((fillsRaw.concat(strokesRaw)).some(paintUnsupported) && ctx.rasterUnsupported) {
        out.bgRaster = await rasterNode(ctx, node, Object.assign({}, base, { name: base.name + ' bg', mask: null }), null, true);
        warn(ctx, node, 'frame background rasterised (unsupported paint)');
      } else if (fillsRaw.length || strokesRaw.length) {
        out.bg = await shapeData(ctx, node, { w: base.w, h: base.h });
      }
    }
    if (node.clipsContent) out.clipNeeded = clipMatters(node);
    // nothing left inside and nothing of its own to show → no empty null / precomp in AE
    if (ctx.cleanup && node !== ctx.rootNode && !children.length && !out.bg && !out.bgRaster && !out.shadowImg &&
        !(out.effects || []).some((e) => e.type !== 'unsupported')) { ctx.cleaned.empty++; return null; }
    return out;
  }

  if (node.type === 'TEXT') return exportText(ctx, node, base);

  if (SHAPE_TYPES[node.type]) {
    const paints = visiblePaints(node.fills).concat(visiblePaints(node.strokes));
    if (ctx.rasterUnsupported && (paints.some(paintUnsupported) || hasUnsupportedEffect(node))) {
      return rasterNode(ctx, node, base, paints.some(paintUnsupported) ? 'unsupported paint' : 'unsupported effect');
    }
    const sd = await shapeData(ctx, node, base);
    ctx.stats.shapes++;
    return Object.assign(base, { kind: 'shape' }, sd, { effects: exportEffects(ctx, node) }, await exactShadow(ctx, node));
  }

  // Anything else (FigJam stickies, connectors, tables, embeds, media, widgets…)
  if ('exportAsync' in node) return rasterNode(ctx, node, base, node.type.toLowerCase() + ' has no AE equivalent');
  return null;
}

async function shapeData(ctx, node, dims) {
  const out = {};
  out.geom = shapeGeometry(ctx, node);
  out.fills = await exportPaints(ctx, node, node.fills, dims.w, dims.h);
  ctx.strokeMode = true;
  const strokes = await exportPaints(ctx, node, node.strokes, dims.w, dims.h);
  ctx.strokeMode = false;
  out.strokes = strokes;
  if (strokes.length) {
    const st = strokeInfo(ctx, node);
    if (st.w > 0) {
      out.stroke = st;
      const noGeom = out.geom.kind === 'paths' && !out.geom.paths.length;
      if ((needsOutlineStroke(ctx, node, st) || noGeom) && node.strokeGeometry && node.strokeGeometry.length) {
        out.outline = geomToPaths(node.strokeGeometry, ctx.S);
      }
    } else out.strokes = [];
  }
  return out;
}

// Structural key for every layer: its path of names from the frame, where auto-named text layers (named after
// what they say) count as "¶" – so a duplicated + translated frame lines up with the original, layer for layer.
function assignPaths(n, pk) {
  n.pk = pk;
  if (n.bgRaster) n.bgRaster.pk = pk;
  const seen = {};
  for (const c of n.children || []) {
    const seg = (c.autoName ? '¶' : String(c.rawName || c.name).replace(/[\/~]/g, '_').replace(/ @in:/g, ' in:'));
    seen[seg] = (seen[seg] || 0) + 1;
    assignPaths(c, (pk ? pk + '/' : '') + seg + (seen[seg] > 1 ? '#' + seen[seg] : ''));
  }
}

// ------------------------------------------------------------------ package
async function serializeRoot(ctx, root) {
  const frameRoot = isFrameLike(root);
  let rootAbs, w, h;
  if (frameRoot) {
    rootAbs = fromFigma(root.absoluteTransform);
    w = root.width; h = root.height;
  } else {
    const rb = root.absoluteRenderBounds || root.absoluteBoundingBox;
    rootAbs = T(rb.x, rb.y); w = rb.width; h = rb.height;
  }
  ctx.rootInv = inv(rootAbs);
  ctx.rootNode = root; ctx.clips = [];
  const node = await serialize(ctx, root);
  if (node) { assignSigs(node); assignPaths(node, ''); }
  ctx.stats.comps++;
  let reference = null;
  if (ctx.reference) {
    progress('Capturing reference screenshot…', 78);
    try { reference = await referenceShot(ctx, root); } catch (e) { warn(ctx, root, 'reference screenshot failed: ' + e.message); }
  }
  // where this sits – lets "Add to active comp" drop it at its Figma position when the active comp
  // was imported from one of its parent frames (else AE centres it)
  const at = { x: r6(rootAbs[4] * ctx.S), y: r6(rootAbs[5] * ctx.S), frames: [] };
  for (let p = root.parent; p && p.type !== 'PAGE' && p.type !== 'DOCUMENT'; p = p.parent) {
    if (!isFrameLike(p) || !p.absoluteTransform) continue;
    const rel = mul(inv(fromFigma(p.absoluteTransform)), rootAbs);
    at.frames.push({ id: p.id, x: r6(rel[4] * ctx.S), y: r6(rel[5] * ctx.S), w: r6(p.width * ctx.S), h: r6(p.height * ctx.S) });
  }
  return {
    name: cleanName(root.name), id: root.id, at,
    w: r6(w * ctx.S), h: r6(h * ctx.S),
    rootIsFrame: frameRoot && node && node.kind === 'container',
    node, reference,
  };
}

async function exportPackage(settings) {
  const { roots } = getRoots();
  if (!roots.length) throw new Error('Select one or more frames/layers (or have top-level frames on this page).');
  const ctx = makeCtx(settings);
  ctx.total = roots.reduce((a, r) => a + countTree(r), 0);
  const comps = [];
  for (const r of roots) {
    progress('Exporting “' + r.name + '”…', 3);
    comps.push(await serializeRoot(ctx, r));
  }
  const scene = {
    format: 'figae', version: 1, generator: 'figma-to-ae ' + PLUGIN_VERSION + ' (build ' + PLUGIN_BUILD + ')',
    file: figma.root.name, page: figma.currentPage.name, exported: new Date().toISOString(),
    settings, comps, warnings: ctx.warnings, imageKeys: ctx.fileKeys,
  };
  const cl = ctx.cleaned, nClean = cl.hidden + cl.transparent + cl.outside + cl.covered + cl.empty;
  if (nClean) {
    const parts = [[cl.hidden, 'hidden'], [cl.transparent, 'at 0% opacity'], [cl.outside, 'outside their frame'], [cl.covered, 'covered by a shape above'], [cl.empty, 'empty']]
      .filter((p) => p[0]).map((p) => p[0] + ' ' + p[1]);
    ctx.warnings.unshift({ node: '', id: '', msg: 'Cleaned up ' + nClean + (nClean > 1 ? ' layers that don’t show (' : ' layer that doesn’t show (') + parts.join(', ') + '). Untick Advanced settings ▸ Clean up to bring everything.' });
  }
  ctx.stats.cleaned = nClean;
  progress('Packaging…', 82);
  const files = [{ name: 'scene.json', text: JSON.stringify(scene) }].concat(ctx.files);
  const name = (roots.length === 1 ? cleanName(roots[0].name) : figma.root.name).replace(/[\\/:*?"<>|]+/g, '_');
  return { files, name, stats: ctx.stats, warnings: ctx.warnings };
}

// ------------------------------------------------------------------ test frame (Plugins ▸ Framelift ▸ Create test frame)
// One frame with every feature worth checking on a real file. Send it, then compare against the
// hidden "Figma reference" layer in AE (turn it on, set it to Difference).
const TEST_JPG = '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCACgAPADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDiwtOC08LTgtfocmfMxkMC04LTwtKFrCTOiMhoWlC08LTgtYyZvGQwLTgtPC04LWEmdEZDAtOC04LTgtYSZvGQwLTgtPC04LWEmdEZDAtOC08LShawkzojIYFpwWnhacFrCTN4yGBacFp4WnBawkzojIYFpQtPC04LWEmdEZDAtOC08LTgtYSZvGQwLShaeFpwWsJM6IyGBacFp4WnBaxkzeMhgWnBaeFpQtYSZ0RkMC04LTwtOC1hJnRGRyAWnBaeFpQtfrkmfh0ZDAtOC08LTgtYSZ0RkMC04LTwtKFrCTOiMhoWlC08LTgtYSZvGQwLTgtPC04LWEmdEZDAtKFp4WnBawkzeMhgWnBaeFpwWsJM6IyGBacFp4WlC1hJnRGQwLTgtPC04LWMmbxkMC04LTwtKFrCTOiMhoWlC08LUkcbSOqRqzOxAVVGST6CsJSN4yIgtOC1r2vh3Vbnd5djMNuM+YPL/LdjNTv4X1hEZ2s2IUZO11J/AA5NcM8XRTs5q/qjojIwwtKFq1cWVza7ftNvNDuzt8xCufpmogtJzTV0bxkMC04LTwtOC1jJnRGQwLTgtPC0oWsJM6IyOQC04LTwtOC1+uSZ+HxkMC04LTwtKFrCTN4yGBacFp4WnBawkzojIYFpwWnhaULWMmbxkNC0oWnhacFrCTOiMhgWnBaeFpwWsJM6IyGBaULTwtOC1hJm8ZDAtOC08LTgtYSZ0RkMC04LTgtOC1hJm8ZDAtOC08LXQ+EtCGq3DS3G4WkJG4DI3n+6D/PvyPXI48TiIUIOpN6I6ad5OyG+GvDMurL58zNBaA4DYyZOeQv68+vrzj0Gw0yy08AWdtHEcEbgMsQTnBY8mrSIsaKkahUUYVVGAB6CnV8RjMwq4qWrtHt/W53RjYKKKK4BjJoo54zHNGkkbdVdQQfwNcvrvhOKYNNpgEUoBJh/hc5zx/d7+3TpXV0VtRxFSi7wZSk1sePNG0bsjqVdTgqRgg+lAWvQfFGhpfRPdW423aLkgDPmAdvr6fl9ODC19DQxUcRDmW/U66c7jAtOC08LTgtVJnTGRyAWlC08LTgtfrkmfh8ZDAtOC08LTgtYSZvGQwLTgtOC04LWEmdEZDAtOC08LTgtYSZ0RkMC04LTwtKFrCTN4yGBacFp4WnBawkzojIYFpwWnhacFrCTN4yGBaULTwtOC1hJnRGQwLTgtPC04LWEmdEZDY42kdURWZ2OAoGST6V63pNmLDTba2AAMaANgkgt1YjPvmvOvDVv5+u2SbtuJN+cZ+782P0r1Cvlc/rNyhS+f6f5npYRXTkFFFFfOHWFFFFABRRRQAVwHiqyNtq0jhcRT/vFIz1/i/HPP4iu/rhte1W11eW7jt3/AHmm3P2Zxg/NuXO7kDGGR1xz93PcV3YByVS626/16jjUjCai3qzDC0oWnhacFr1pM74yOQC04LTwtOC1+uSZ+HxkMC0oWnhacFrCTOiMhgWnBaeFpwWsJM3jIYFpwWnBacFrCTOiMhgWnBaeFqG1uY7ia4jTrC20/wCfrkfhWE5JaG8ZEoWnBaeFpQtYyZ0RkMC04LTwtY3ia8NtDDFE+JmcP2OADkfrj8jXPUnZXNnUUVdmwFpwWm2sqXNvHNEco4yPb2+tTBaxlI6YSuNC0oWnhajvJltbSadsYjUtgnGT2H49KwkzdTSV2X/BN9DN4mVAwBgkaMk8ZJQgdffI/D3r1KvnbwXqLWfiKCWQlw7gtufG5gdwz6k4x+NfQ0MizRJLGco6hlOOoPSvlM+ptVY1OjVvu/4c78pxHt6TvvcfRRRXgnqnBfFzW5tK0uwhs3aO4muBKG2qwxEQ3Oe+4oenY/Q9rp12l/p9teQhliuIllUMMEBgCM+/NeG/Fa/+3eMrlFaJo7VEt1ZDnoNzA89QzMPwxXoHwdv/ALV4UNqzRb7SZkCqfm2N8wLDPclgD7exr2sTgvZ4GnU67v5/0jxcLjXUx1Sn02Xy/pndUUUV4p7RX1G7Sw0+5vJgzRW8TSsFGSQoJOPfivBvCerXEutXSXEhc37GWTCgbpBubcfThn4Hr+XpPxf1BLXwk1qdrS3kqRqu/BAUhywHcfKB/wACFeKWc32a8gn27vKkV9ucZwc4r6XJ8MpYec2vi/T/AIP5Hz2Z410sXTs9I6v57/h+Z6uFpwWljKyIrowZGGQwOQR6inhaykz6uErnIBacFp4WnBa/XJM/D4yGBacFp4Wg4VSzEBQMkk8AVhKR0RkYviC8aBYoYjiQkOTjoAeP1H6Vq2cy3NtHMnAcZx6HuPzrj7+4+1Xks2MBjwPYcD9K2PCtyAZLVsAsd6+/qP5frXi0sW513fZ7He4WgjfC04LTwtOC12SYRkU9Qn+yWUs+MlRwPc8D9TXLaBcfZ9TjyMrL+7P4nj9cVf8AFlzmWO1Ujao3tg9+w9uP51z9eTiKv7xW6G6Z6MFpwWqujXJvdOimYgyY2vg9x/LPX8avha3crq6OiMhgWuF166F3qcrI26NPkQ8dB9Oozk12Wr3QstOmm3bXxtTpncenX8/wrz2uStLoFWd1Y67whdCS0e2ZvniO5Rx90+n45/MV0IWuC8PXYs9Vid22xP8Au3PHQ+uegzg/hXoQWs1LQ6sNUvG3YYFrnfGV2YrWK1QjMp3PyM7R049z39q6cLXnvia5NzrM/J2xHylBAGMdf1zUN3ZeJqctOy6mbFI0MqSRnDowZT6EV774E1tdQ02CKRlD7A0fzbiR3XPqvT+nFeAV3PgS7Z7KSEMwe3cMpHGAeRg+uQTXFj8LHE0uVhlOJdGrboz3Cq+o3aWGn3N5MGaK3iaVgoySFBJx78Vm6HrSXcYiumVLkYGTwJPp7+35e3OfGPUxaeGUsVK+beygFSDnYhDEg9Ad2wc9ifw+Sp4ObxEaElu/w/4Y+pr4mNOhKsui/E8Yu7iW7uprm4bfNM7SO2AMsTknA46mu4+Dmpm08TPYsW8q9iICgDG9AWBJ6gbd447kfhwVWNOu3sNQtryEK0tvKsqhhkEqQRn24r7LE0FWoypd1/wx8Thq7o1o1ez/AOHPqGiorS4iu7WG5t23wzIsiNgjKkZBweehpt5dw2kRedwOOF7t9BXwai2+W2p+gXTVzxz4zah9p8RwWSS7o7SEbk242SOcnnHOV2e361wFXdb1B9V1e8v5dwa4laQKz7ioJ4XPoBgD2FUq+8wtH2FGNPsv+HPgMXW9vWlU7v8ADoem+D7n7VoNvl9zxZibjGMdB/3ztrbC1w/w5uWF1dWh3FGQSj5uFIODx75HPtXeha8TGR9nVkj7XKsR7bDQb3Wn3HIBacFp4WlC1+qSZ+PRkMC1leJrgwWIiRsPMcd/ujr/AEH41tBa4fW7r7XqMrAgoh2Jg5GB3z78n8a83H1uSnZbs78JHnnfsUaktpnt545ozh0OR/hUdFeAnbVHqHo0LLLGkkZyjgMp9QadIyxRPJIcIgLMfQCsTwfdeZbSWrkZiO5OecHrx7Hv71N4sujb6cIkbDztt752jr/QfjXruunT5zmSalynI3k5ubqWZs5di2Cc4HYfhUVFFeQ3fU6TofB12EupLVycSjcnPGR149x39q7ALXmdpO9rcxzxHDxtuHv7H2r02OWN7dZw48krv3ngbcZzz0ropT92xcWcn40uwZIbRGzt/eOOOvb3zjP5iuZqzqdyby/nuMnDsSuQAQvQDj2xVasJO7uJu7uFel6Jdi/0yCbdufbtk6Z3DrwOnr9CK80rrPAl4Fkns3bG/wDeRjjqPve+cY/I0jWhPllbudJqdyLLTri4JAMaErkEgt0A498V5fXZ+O70JBDZITvc+Y+CR8oyAD65P/oNcZSRWJnzSt2CtnwjdC11uEMQEmBiJIJ69MfiAKxqVHaN1dGKupyGBwQfUUNXVjGnPkkpLoewha4Hx5qs2o6wIZZ3ljtV8tcvuGTyx+uTg/7o9OO1stQhudJS/J2QmMyP1O3H3h05xg15VdTNc3M07gB5XLkDpknPFctGCc+ZrY9THVv3ajF7kdFFFdZ5B634C8S3EnheGzQgTWhMZkZ97Fc5Xg9AAdo6/d4qHxrqMkWiXMk0m+WYeSu/JzuzkD043H0rlfh5eCLVJrViALhMrwcllycfkW/KrXxIvD5lpZKWAAMzjAweoXnr2b868j6rCOJtFb6n0UcY/qN29Urfp+RxVFFFeufOl/QLwafrNpcsQER8OSCcKeGPHsTXsYWvDa9m8O3h1HRbO6YsXdMOSAMsOGPHuDXjZrD4any/r8T6Xh+vbnpP1/R/oYAWnBa8Por7N5lf7P4/8A+OWTW+3+H/AAT1/wAQXn2LT22NiaT5E55Hqfw/niuHrmkkePOx2XPXBxT/ALRN/wA9pP8Avo15+IquvLmeh20MF7GNk7nRUVzv2ib/AJ7Sf99Gj7RN/wA9pP8Avo1z8pt7B9zrdJvGsL+KcZ2g4cDup6/59cVP4huxearK6NuiT92h46D0x1Gcn8a4v7RN/wA9pP8Avo0faJv+e0n/AH0avXl5egvq2t7nRUVzv2ib/ntJ/wB9Gj7RN/z2k/76NRyj9g+50Vbtpqwi8MXNoXIm37EGB9xuT/Juf9oVwH2ib/ntJ/30aPtE3/PaT/vo01FoPYPudFRXO/aJv+e0n/fRo+0Tf89pP++jS5Q9g+50VWtKuzY6lb3IJxG4LYAJK9CBn2zXJ/aJv+e0n/fRo+0Tf89pP++jRyDVFrW52niO8+26zcyq2Y1bYmG3DaOMj2PX8aza537RN/z2k/76NH2ib/ntJ/30aOQHRbd7nRUVzv2ib/ntJ/30aPtE3/PaT/vo0covYPud9aau0Pha7sdx3tKoQ+ZghWyWAHp8uD/v/nh1zv2ib/ntJ/30aPtE3/PaT/vo0lTtexcqcpWu9joqK537RN/z2k/76NH2ib/ntJ/30afKR7B9zq9Nu2sb+3uk3ExOGwG27h3GfcZH41a8T3a3uv3s8e3YX2qVbcGCgLkH3xn8a4r7RN/z2k/76NH2ib/ntJ/30an2S5ubqackuTkvpe50VFc79om/57Sf99Gj7RN/z2k/76NVymfsH3Oir0P4X3aNaXlmdodHEw+blgQAePbaOf8AaFeNfaJv+e0n/fRpryyOMPI7DrgnNYYnC+3pum3Y6sHKWFqqqtRlFFFdYgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP//Z';
async function createTestFrame() {
  const fonts = [['Inter', 'Regular'], ['Inter', 'Medium'], ['Inter', 'Semi Bold'], ['Inter', 'Bold']];
  for (const [family, style] of fonts) await figma.loadFontAsync({ family, style });
  const sol = (r, g, b, a = 1) => ({ type: 'SOLID', color: { r, g, b }, opacity: a });
  const shadow = (type, x, y, blur, a, spread = 0) => ({ type, color: { r: 0, g: 0, b: 0, a }, offset: { x, y }, radius: blur, spread, visible: true, blendMode: 'NORMAL' });
  const ID = [[1, 0, 0], [0, 1, 0]];
  const frame = figma.createFrame();
  frame.name = 'Framelift test frame'; frame.resize(1920, 1080); frame.fills = [sol(0.95, 0.95, 0.97)]; frame.clipsContent = true;
  const v = figma.viewport.center; frame.x = Math.round(v.x - 960); frame.y = Math.round(v.y - 540);
  const add = (n, x, y, parent = frame) => { parent.appendChild(n); n.x = x; n.y = y; return n; };
  const text = (chars, x, y, size = 16, style = 'Regular', parent = frame, color = sol(0.1, 0.1, 0.15)) => {
    const t = figma.createText(); t.fontName = { family: 'Inter', style }; t.characters = chars; t.fontSize = size; t.fills = [color];
    return add(t, x, y, parent);
  };
  const rect = (name, w, h, fills, x, y, parent = frame) => { const r = figma.createRectangle(); r.name = name; r.resize(w, h); r.fills = fills; return add(r, x, y, parent); };
  const cell = (col, row) => [80 + col * 450, 150 + row * 300];
  const caption = (s, col, row) => { const [x, y] = cell(col, row); text(s, x, y + 230, 13, 'Medium', frame, sol(0.45, 0.45, 0.52)); };
  const img = figma.createImage(figma.base64Decode(TEST_JPG));

  text('Framelift test frame', 80, 50, 40, 'Bold');
  text('Send this frame, then in After Effects turn on “Figma reference” and set it to Difference – anything that doesn’t match lights up.', 80, 104, 16);

  // 1 exact shadows
  let [x, y] = cell(0, 0);
  const card = rect('Card with shadows', 260, 160, [sol(1, 1, 1)], x + 20, y + 30); card.cornerRadius = 20;
  card.effects = [shadow('DROP_SHADOW', 0, 12, 32, 0.18), shadow('DROP_SHADOW', 0, 2, 6, 0.12, 2), shadow('INNER_SHADOW', 0, -3, 0, 0.08)];
  caption('Exact drop + inner shadows', 0, 0);

  // 2 gradients
  [x, y] = cell(1, 0);
  const g1 = rect('4-stop linear gradient', 180, 160, [{ type: 'GRADIENT_LINEAR', gradientTransform: ID, gradientStops: [
    { position: 0, color: { r: 1, g: 0.3, b: 0.3, a: 1 } }, { position: 0.35, color: { r: 1, g: 0.8, b: 0.2, a: 1 } },
    { position: 0.7, color: { r: 0.2, g: 0.7, b: 1, a: 1 } }, { position: 1, color: { r: 0.5, g: 0.2, b: 0.9, a: 1 } }] }], x, y + 30);
  g1.cornerRadius = 12;
  const g2 = figma.createEllipse(); g2.name = 'Radial gradient fading out'; g2.resize(160, 160);
  g2.fills = [{ type: 'GRADIENT_RADIAL', gradientTransform: ID, gradientStops: [{ position: 0, color: { r: 0.1, g: 0.6, b: 0.4, a: 1 } }, { position: 1, color: { r: 0.1, g: 0.6, b: 0.4, a: 0 } }] }];
  add(g2, x + 200, y + 30);
  caption('Multi-stop + transparent gradients', 1, 0);

  // 3 components
  [x, y] = cell(2, 0);
  const comp = figma.createComponent(); comp.name = 'Logo'; comp.resize(90, 90); comp.fills = [];
  const disc = figma.createEllipse(); disc.resize(90, 90); disc.fills = [sol(0.36, 0.31, 0.91)]; comp.appendChild(disc);
  const star = figma.createStar(); star.resize(50, 50); star.x = 20; star.y = 20; star.fills = [sol(1, 1, 1)]; comp.appendChild(star);
  add(comp, x, y + 60);
  for (let i = 0; i < 2; i++) { const inst = comp.createInstance(); add(inst, x + 110 + i * 110, y + 60); if (i === 1) inst.rotation = 15; }
  caption('Component + 2 instances (one precomp, reused)', 2, 0);

  // 4 image crop + mask
  [x, y] = cell(3, 0);
  const crop = rect('Cropped photo', 170, 150, [{ type: 'IMAGE', imageHash: img.hash, scaleMode: 'CROP', imageTransform: [[0.55, 0, 0.3], [0, 0.6, 0.2]] }], x, y + 35);
  crop.cornerRadius = 16;
  const maskE = figma.createEllipse(); maskE.name = 'Circle mask'; maskE.resize(150, 150); maskE.fills = [sol(0, 0, 0)]; add(maskE, x + 200, y + 35);
  const photo = rect('Photo', 170, 150, [{ type: 'IMAGE', imageHash: img.hash, scaleMode: 'FILL' }], x + 190, y + 35);   // above the mask
  const masked = figma.group([maskE, photo], frame); masked.name = 'Masked photo'; maskE.isMask = true;
  caption('Image crop (track matte) + circle mask', 3, 0);

  // 5 text
  [x, y] = cell(0, 1);
  const t = text('Mixed styles: bold, colour and underline\nLetter-spaced line\nFootnote marker¹ and H₂O', x, y + 30, 20);
  t.resize(380, t.height); t.textAutoResize = 'HEIGHT';
  t.setRangeFontName(14, 18, { family: 'Inter', style: 'Bold' });
  t.setRangeFills(20, 26, [sol(0.36, 0.31, 0.91)]);
  t.setRangeTextDecoration(31, 40, 'UNDERLINE');
  t.setRangeLetterSpacing(41, 59, { unit: 'PERCENT', value: 12 });
  const lst = text('First bullet\nSecond bullet\nThird bullet', x, y + 150, 16);
  try { lst.setRangeListOptions(0, lst.characters.length, { type: 'UNORDERED' }); } catch (e) { /* older Figma */ }
  caption('Text: mixed styles, list, ¹ ₂ characters', 0, 1);

  // 6 superscript (manual) + missing font
  [x, y] = cell(1, 1);
  const sup = text('Cash back offer1', x, y + 30, 36, 'Semi Bold');
  sup.name = 'Superscript – set the 1 manually';
  text('↑ select the last “1”, then Type details ▸ Position ▸ Superscript', x, y + 80, 13, 'Regular', frame, sol(0.8, 0.3, 0.2));
  try {
    await figma.loadFontAsync({ family: 'Playfair Display', style: 'Italic' });
    const pf = text('Playfair Display Italic', x, y + 130, 30); pf.fontName = { family: 'Playfair Display', style: 'Italic' };
  } catch (e) { text('(Playfair Display not available here)', x, y + 130, 14); }
  caption('Superscript + a font AE may not have', 1, 1);

  // 7 strokes + smoothed corners
  [x, y] = cell(2, 1);
  const dashed = rect('Dashed outside stroke', 120, 120, [sol(1, 1, 1)], x, y + 40);
  dashed.strokes = [sol(0.9, 0.2, 0.4)]; dashed.strokeWeight = 4; dashed.strokeAlign = 'OUTSIDE'; dashed.dashPattern = [12, 6]; dashed.cornerRadius = 8;
  const bottom = rect('Bottom border only', 120, 60, [sol(1, 1, 1)], x + 140, y + 40);
  bottom.strokes = [sol(0.1, 0.1, 0.15)]; bottom.strokeTopWeight = 0; bottom.strokeLeftWeight = 0; bottom.strokeRightWeight = 0; bottom.strokeBottomWeight = 4;
  const sq = rect('Smoothed corners (iOS)', 120, 120, [sol(0.2, 0.75, 0.55)], x + 280, y + 40); sq.cornerRadius = 36; sq.cornerSmoothing = 0.6;
  caption('Dashed / one-side strokes, smoothed corners', 2, 1);

  // 8 effects
  [x, y] = cell(3, 1);
  rect('Photo behind glass', 360, 180, [{ type: 'IMAGE', imageHash: img.hash, scaleMode: 'FILL' }], x, y + 25);
  const glass = rect('Background blur card', 200, 110, [sol(1, 1, 1, 0.35)], x + 20, y + 60); glass.cornerRadius = 18;
  glass.effects = [{ type: 'BACKGROUND_BLUR', radius: 16, visible: true }];
  const blurred = figma.createEllipse(); blurred.name = 'Layer blur'; blurred.resize(70, 70); blurred.fills = [sol(1, 0.85, 0.2)];
  blurred.effects = [{ type: 'LAYER_BLUR', radius: 8, visible: true }]; add(blurred, x + 260, y + 60);
  const mul = figma.createEllipse(); mul.name = 'Multiply blend'; mul.resize(70, 70); mul.fills = [sol(0.9, 0.3, 0.6)]; mul.blendMode = 'MULTIPLY'; add(mul, x + 280, y + 110);
  caption('Background blur, layer blur, multiply', 3, 1);

  // 9 clipping + rotation
  [x, y] = cell(0, 2);
  const clipF = figma.createFrame(); clipF.name = 'Clipping frame'; clipF.resize(240, 140); clipF.fills = [sol(0.15, 0.15, 0.22)]; clipF.cornerRadius = 14; clipF.clipsContent = true;
  add(clipF, x, y + 40);
  const big = figma.createEllipse(); big.resize(200, 200); big.fills = [sol(0.36, 0.31, 0.91)]; add(big, 120, 30, clipF);
  const rr = rect('Rotated', 90, 90, [sol(1, 0.6, 0.2)], x + 280, y + 60); rr.rotation = 30; rr.cornerRadius = 10;
  caption('Clipped overflow + rotation', 0, 2);

  // 10 clean up: none of these four should come across (notes: "Cleaned up 4 layers")
  [x, y] = cell(1, 2);
  const hid = rect('Hidden – should not come across', 80, 80, [sol(1, 0, 0)], x, y + 50); hid.visible = false;
  const zero = rect('0% – should not come across', 80, 80, [sol(1, 0, 0)], x + 100, y + 50); zero.opacity = 0;
  rect('Covered – should not come across', 60, 60, [sol(1, 0, 0)], x + 230, y + 60);
  rect('Solid card on top', 100, 100, [sol(1, 1, 1)], x + 210, y + 40);
  rect('Off-frame – should not come across', 120, 80, [sol(1, 0, 0)], -400, 300);
  text('Hidden, 0%, covered and off-frame red boxes are skipped by Clean up:\nyou should see only the white card here.', x, y + 160, 13);
  caption('Clean up (4 layers skipped)', 1, 2);

  figma.currentPage.selection = [frame];
  figma.viewport.scrollAndZoomIntoView([frame]);
  return frame;
}
