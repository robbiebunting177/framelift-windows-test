/*  Framelift 1.18  ·  Figma → After Effects  ·  importer panel
    Made by Robbie Bunting  ·  © 2026 Robbie Bunting. All rights reserved.
    Figma and Adobe After Effects are trademarks of their respective owners. Not affiliated with Figma or Adobe.

    Rebuilds a .framelift package (sent by the companion Figma plugin) as native AE layers:
    shape layers, text layers, nulls, precomps, track mattes, layer styles and effects.

    Install: copy this file to  .../Adobe After Effects <version>/Scripts/ScriptUI Panels/
             restart AE, open via  Window ▸ Framelift.jsx
    Requires: Preferences ▸ Scripting & Expressions ▸ "Allow Scripts to Write Files and Access Network".
    Best in AE 2023 (23.0) or newer; text styling per character needs AE 24.3+.
*/
(function FigmaToAE(thisObj) {
    var VERSION = "1.18";
    var BUILD = "21 Oct f";   // which build of a version is installed (shown in Copy diagnostics)
    var CREDIT = "Made by Robbie Bunting";
    var COPYRIGHT = "© 2026 Robbie Bunting. All rights reserved.";
    var SETTINGS_SECTION = "FigmaToAE";
    var KAPPA = 0.5522847498;

    // =====================================================================  ES3 helpers
    function each(a, fn) { if (!a) return; for (var i = 0; i < a.length; i++) fn(a[i], i); }
    function has(a, v) { if (!a) return false; for (var i = 0; i < a.length; i++) if (a[i] === v) return true; return false; }
    function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
    function num(v, d) { return (typeof v === "number" && !isNaN(v)) ? v : d; }
    function trim(s) { return String(s).replace(/^\s+|\s+$/g, ""); }
    function deg(r) { return r * 180 / Math.PI; }
    function isArr(a) { return a instanceof Array; }

    function parseJSON(s) {
        if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(s);
        var safe = true;
        try {
            safe = /^[\],:{}\s]*$/.test(s.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@")
                .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]")
                .replace(/(?:^|:|,)(?:\s*\[)+/g, ""));
        } catch (e) { safe = true; /* regex too big for engine – our own file, trust it */ }
        if (!safe) throw new Error("scene.json is not valid JSON");
        return eval("(" + s + ")");
    }

    // =====================================================================  2D affine [a,b,c,d,e,f]
    function mul(A, B) {
        return [A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
            A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
            A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]];
    }
    function inv(M) {
        var det = M[0] * M[3] - M[1] * M[2]; if (Math.abs(det) < 1e-12) det = 1e-12;
        return [M[3] / det, -M[1] / det, -M[2] / det, M[0] / det,
            (M[2] * M[5] - M[3] * M[4]) / det, (M[1] * M[4] - M[0] * M[5]) / det];
    }
    function ap(M, x, y) { return [M[0] * x + M[2] * y + M[4], M[1] * x + M[3] * y + M[5]]; }
    function apLin(M, x, y) { return [M[0] * x + M[2] * y, M[1] * x + M[3] * y]; }
    var IDENT = [1, 0, 0, 1, 0, 0];
    function T(x, y) { return [1, 0, 0, 1, x, y]; }
    function decompose(M) {
        var sx = Math.sqrt(M[0] * M[0] + M[1] * M[1]);
        var det = M[0] * M[3] - M[1] * M[2];
        var rot = sx > 1e-9 ? deg(Math.atan2(M[1], M[0])) : 0;
        var sy = sx > 1e-9 ? det / sx : Math.sqrt(M[2] * M[2] + M[3] * M[3]);
        if (Math.abs(sx - 1) < 1e-5) sx = 1; if (Math.abs(sy - 1) < 1e-5) sy = 1; if (Math.abs(sy + 1) < 1e-5) sy = -1;
        return { rot: rot, sx: sx, sy: sy };
    }

    // =====================================================================  zip (STORE) reader
    function u16(s, p) { return (s.charCodeAt(p) & 255) | ((s.charCodeAt(p + 1) & 255) << 8); }
    function u32(s, p) { return (u16(s, p) + u16(s, p + 2) * 65536); }
    function ensureFolder(path) {
        var f = new Folder(path); if (!f.exists) { ensureFolder(f.parent.fsName); f.create(); } return f;
    }
    function writeBinary(path, data) {
        var f = new File(path); ensureFolder(f.parent.fsName);
        f.encoding = "BINARY"; if (!f.open("w")) throw new Error("Can't write " + path + " – enable 'Allow Scripts to Write Files'");
        f.write(data); f.close(); return f;
    }
    function extractZip(zipFile, dest) {
        zipFile.encoding = "BINARY";
        if (!zipFile.open("r")) throw new Error("Can't open " + zipFile.fsName);
        var s = zipFile.read(); zipFile.close();
        var pos = 0, count = 0;
        while (pos + 30 <= s.length && u32(s, pos) === 0x04034b50) {
            var method = u16(s, pos + 8), flags = u16(s, pos + 6), size = u32(s, pos + 18);
            var nlen = u16(s, pos + 26), elen = u16(s, pos + 28);
            var name = s.substr(pos + 30, nlen);
            var start = pos + 30 + nlen + elen;
            if (method !== 0 || (flags & 8)) return extractZipSystem(zipFile, dest); // re-zipped with compression
            if (name.charAt(name.length - 1) !== "/") writeBinary(dest.fsName + "/" + name, s.substr(start, size));
            pos = start + size; count++;
        }
        if (!count) throw new Error("Not a Framelift file");
    }
    function extractZipSystem(zipFile, dest) {
        ensureFolder(dest.fsName);
        var q = function (p) { return '"' + p + '"'; };
        if ($.os.indexOf("Windows") >= 0) system.callSystem("tar -xf " + q(zipFile.fsName) + " -C " + q(dest.fsName));
        else system.callSystem("/usr/bin/ditto -x -k " + q(zipFile.fsName) + " " + q(dest.fsName));
        if (!new File(dest.fsName + "/scene.json").exists) throw new Error("Couldn't unpack " + zipFile.name);
    }
    function readText(file) { file.encoding = "UTF-8"; file.open("r"); var t = file.read(); file.close(); return t; }

    // =====================================================================  settings / UI
    var DEFAULTS = { fps: 30, duration: 10, shadowSize: 100, graphics: true, anchorCenter: true, precompClipped: true, nulls: true, openComp: true, styles: true, live: true };
    var LIVE_PORTS = [7239, 7240, 7241, 7242, 7243];
    var LIVE_PORT = LIVE_PORTS[0];
    function loadOpt() {
        var o = {}; for (var k in DEFAULTS) {
            o[k] = DEFAULTS[k];
            try { if (app.settings.haveSetting(SETTINGS_SECTION, k)) { var v = app.settings.getSetting(SETTINGS_SECTION, k); o[k] = typeof DEFAULTS[k] === "boolean" ? v === "true" : parseFloat(v); } } catch (e) { }
        }
        return o;
    }
    function saveOpt(o) { for (var k in o) try { app.settings.saveSetting(SETTINGS_SECTION, k, String(o[k])); } catch (e) { } }

    var ui = null;
    function buildUI(thisObj) {
        var opt = loadOpt();
        var w = (thisObj instanceof Panel) ? thisObj : new Window("palette", "Framelift", undefined, { resizeable: true });
        w.orientation = "column"; w.alignChildren = ["fill", "top"]; w.spacing = 8; w.margins = 12;
        var head = w.add("statictext", undefined, "Framelift  " + VERSION.replace(/\.0$/, "") + (IS_MAC ? "" : " Beta") + "   ·   Figma → After Effects"); head.graphics.font = ScriptUI.newFont(head.graphics.font.name, "BOLD", 13);
        var by = w.add("statictext", undefined, CREDIT); try { by.graphics.foregroundColor = by.graphics.newPen(by.graphics.PenType.SOLID_COLOR, [0.6, 0.6, 0.6], 1); } catch (e) { }
        var topRow = w.add("group"); topRow.alignChildren = ["fill", "center"];
        var btn = topRow.add("button", undefined, "Import .framelift file…");
        var tidyBtn = topRow.add("button", undefined, "Tidy project");
        tidyBtn.helpTip = "Removes Framelift precomps and images that no comp uses any more, and empty Framelift folders. Unused image files on disk move to “Figma assets/Unused (safe to delete)”. Undoable.";
        tidyBtn.onClick = function () { try { tidyProject(); } catch (e) { alert("Tidy project failed: " + e.message); } };
        var p = w.add("panel", undefined, "Options"); p.alignChildren = ["fill", "top"]; p.margins = 10;
        var r1 = p.add("group"); r1.add("statictext", undefined, "Frame rate"); var fps = r1.add("edittext", undefined, String(opt.fps)); fps.characters = 5;
        r1.add("statictext", undefined, "Duration (s)"); var dur = r1.add("edittext", undefined, String(opt.duration)); dur.characters = 5;
        var r2 = p.add("group"); r2.add("statictext", undefined, "Shadow softness %"); var shs = r2.add("edittext", undefined, String(opt.shadowSize)); shs.characters = 5;
        shs.helpTip = "Calibrates Figma blur → AE layer-style Size. 100 = 1:1 (CSS/Photoshop convention). Lower = tighter shadows.";
        var cbA = p.add("checkbox", undefined, "Anchor points at layer centre"); cbA.value = opt.anchorCenter;
        var cbP = p.add("checkbox", undefined, "Clipping frames → precomps (exact clipping)"); cbP.value = opt.precompClipped;
        var cbN = p.add("checkbox", undefined, "Frames & groups → parent nulls"); cbN.value = opt.nulls;
        var cbG = p.add("checkbox", undefined, "Logos & vector groups → one precomp each"); cbG.value = opt.graphics;
        var cbS = p.add("checkbox", undefined, "Shadows as layer styles (else effects)"); cbS.value = opt.styles;
        var cbO = p.add("checkbox", undefined, "Open comp when done"); cbO.value = opt.openComp;
        var lp = w.add("panel", undefined, "Live link"); lp.alignChildren = ["fill", "top"]; lp.margins = 10;
        var lrow = lp.add("group"); lrow.alignChildren = ["left", "center"];
        var cbL = lrow.add("checkbox", undefined, "Receive from Figma");
        var stBtn = lrow.add("button", undefined, "Status"); cbL.value = opt.live;
        var dgBtn = lrow.add("button", undefined, "Copy diagnostics");
        dgBtn.helpTip = "Copies versions, settings, link status and the last send's notes – paste it into a message if something isn't working.";
        var liveTxt = lp.add("statictext", undefined, "", { multiline: true }); liveTxt.preferredSize.height = 92;
        var up = w.add("group"); up.alignChildren = ["left", "center"];
        var upTxt = up.add("statictext", undefined, "", { truncate: "middle" }); upTxt.preferredSize.width = 220;
        var upBtn = up.add("button", undefined, "Check for updates");
        upBtn.helpTip = "Checks your team's Framelift folder (e.g. on Box Drive) for a newer version. Alt-click to choose a different folder.";
        function upLabel() {
            var u = sget("updateUrl", "") || UPDATE_URL, f = sget("updateFolder", "");
            upTxt.text = u ? "Updates: automatic (online)" : f ? "Updates: " + decodeURI(new Folder(f).name) : "Updates: not set up";
        }
        upLabel();
        upBtn.onClick = function () {
            var alt = false; try { alt = ScriptUI.environment.keyboardState.altKey; } catch (e) { }
            if (alt || !(sget("updateUrl", "") || UPDATE_URL || sget("updateFolder", ""))) {
                var f = Folder.selectDialog("Choose your team's Framelift folder (e.g. Box ▸ Framelift) – new versions are put there");
                if (!f) return;
                sset("updateFolder", f.fsName); sset("updateUrl", ""); sset("updSkip", ""); upLabel();
            }
            checkUpdates(true);
        };
        var lg = w.add("statictext", undefined, "Labels: Yellow text · Blue shapes · Sea Foam images · Purple frames & groups · Pink masks · Orange rasterised · Red reference. Helper layers (shadows, blurs) are shy – toggle the Shy switch to see them.", { multiline: true });
        lg.preferredSize.height = 44;
        var bar = w.add("progressbar", undefined, 0, 100); bar.preferredSize.height = 6;
        var foot = w.add("statictext", undefined, COPYRIGHT); foot.graphics.font = ScriptUI.newFont(foot.graphics.font.name, "REGULAR", 10);
        try { foot.graphics.foregroundColor = foot.graphics.newPen(foot.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1); } catch (e) { }
        var status = w.add("statictext", undefined, "Send from the Framelift plugin in Figma, or import a .framelift file.", { multiline: true });
        status.preferredSize.height = 44;
        function read() {
            return { fps: clamp(num(parseFloat(fps.text), 30), 1, 120), duration: clamp(num(parseFloat(dur.text), 10), 0.1, 10800), shadowSize: clamp(num(parseFloat(shs.text), 100), 10, 400),
                anchorCenter: cbA.value, precompClipped: cbP.value, nulls: cbN.value, graphics: cbG.value, styles: cbS.value, openComp: cbO.value, live: cbL.value };
        }
        function setLive(on) {
            sset("live", on ? "true" : "false");
            try { if (on) relayStart(); else relayStop(); } catch (e) { sset("liveErr", "link: " + e.message + " (line " + e.line + ")"); }
            liveTxt.text = liveStatusText();
        }
        dgBtn.onClick = function () {
            try { copyText(diagnostics(read())); alert("Diagnostics copied.\n\nPaste them into a message (⌘V) to whoever looks after Framelift."); }
            catch (e) { alert("Couldn't copy: " + e.message); }
        };
        stBtn.onClick = function () { liveTxt.text = liveStatusText(); offerAppNapFix(true); liveTxt.text = liveStatusText(); };
        cbL.onClick = function () { var o = read(); saveOpt(o); setLive(cbL.value); };
        each([fps, dur, shs], function (c) { c.onChange = function () { saveOpt(read()); }; });
        each([cbA, cbP, cbN, cbG, cbS, cbO], function (c) { c.onClick = function () { saveOpt(read()); }; });
        btn.onClick = function () {
            var o = read(); saveOpt(o);
            var f = File.openDialog("Choose a .framelift file", $.os.indexOf("Windows") >= 0 ? "Framelift:*.framelift;*.figae;*.zip" : function (f) { return f instanceof Folder || /\.(framelift|figae|zip|json)$/i.test(f.name); });
            if (!f) return;
            run(f, o);
        };
        w.onResizing = w.onResize = function () { this.layout.resize(); };
        if (w instanceof Window) { w.center(); w.show(); } else w.layout.layout(true);
        try { scheduleTick(); } catch (e) { sset("liveErr", "app.scheduleTask failed: " + e.message); }
        try { offerAppNapFix(false); } catch (e) { }
        setLive(cbL.value);
        // once per After Effects session: is there a newer Framelift in the shared folder?
        if (!$.global.__figaeUpdChecked) { $.global.__figaeUpdChecked = true; try { checkUpdates(false); } catch (e) { } }
        return {
            read: read,
            live: function (t) { liveTxt.text = t; },
            status: function (t, pct) { status.text = t; if (pct !== undefined) bar.value = pct; try { if (w.update) w.update(); else if (w.window && w.window.update) w.window.update(); } catch (e) { } }
        };
    }

    function run(file, opt, silent) {
        if (!app.project) app.newProject();
        var ctx = null, err = null;
        app.beginUndoGroup(opt.update ? "Update from Figma" : "Import Figma");
        try {
            ctx = importPackage(file, opt);
        } catch (e) {
            err = e.message + (e.line ? " (line " + e.line + ")" : "");
            ui.status("⚠ " + e.message, 0);
            if (!silent) alert("Framelift – import failed:\n" + err);
        }
        app.endUndoGroup();
        if (ctx) report(ctx, silent);
        return { ctx: ctx, error: err };
    }

    function report(ctx, silent) {
        var lines = [];
        if (ctx.stats.into) lines.push((ctx.stats.updated ? "Updated in " : "Added to ") + "“" + ctx.stats.into + "” – " + ctx.stats.layers + " layers in " + Math.round(ctx.time / 100) / 10 + "s.");
        else lines.push((ctx.stats.updated ? "Updated " : "Imported ") + ctx.stats.comps + " comp(s), " + ctx.stats.layers + " layers in " + Math.round(ctx.time / 100) / 10 + "s.");
        var missing = []; for (var k in ctx.missingFonts) missing.push(k);
        if (missing.length) lines.push("\nMissing fonts (install, then re-import or use File ▸ Dependencies):\n  • " + missing.join("\n  • "));
        var warns = ctx.figmaWarnings.concat(ctx.warnings);
        if (warns.length) {
            lines.push("\nNotes:");
            for (var i = 0; i < warns.length && i < 40; i++) lines.push("  • " + (warns[i].node ? warns[i].node + ": " : "") + warns[i].msg);
            if (warns.length > 40) lines.push("  … and " + (warns.length - 40) + " more");
        }
        ui.status(lines[0], 100);
        if (!silent && (missing.length || warns.length)) alert(lines.join("\n"));
    }

    // =====================================================================  import
    function importPackage(file, opt) {
        var t0 = new Date().getTime();
        var sceneFile, srcFolder, tmp = null;
        if (/\.json$/i.test(file.name)) { sceneFile = file; srcFolder = file.parent; }
        else {
            ui.status("Unpacking…", 2);
            tmp = new Folder(Folder.temp.fsName + "/Framelift/unpack " + stamp() + "-" + Math.floor(Math.random() * 1e6));
            extractZip(file, tmp);
            srcFolder = tmp;
            sceneFile = new File(tmp.fsName + "/scene.json");
        }
        var scene = parseJSON(readText(sceneFile));
        if (scene.format !== "figae") throw new Error("Not a Figma → AE scene file");
        if (opt.update === "auto") { opt.update = !(scene.settings && scene.settings.updateExisting === false); opt.openComp = opt.openComp && !opt.update; }
        // "Add to active comp": everything lands in the comp that's open, no new comps
        if (!opt.target && scene.settings) opt.target = scene.settings.target;   // saved files remember the Figma toggle
        var prevActive = activeComp(), into = opt.target === "active" ? prevActive : null;
        if (into) opt.openComp = false;

        // disk: <project folder>/Figma assets/<frame name>/ – images only, one folder per frame (an image used
        // by several frames lives with the first one), reused on every update
        var assetsRoot = (app.project && app.project.file) ? app.project.file.parent.fsName + "/Figma assets"
            : (opt.transient ? Folder.myDocuments.fsName + "/Framelift" : file.parent.fsName + "/Figma assets");
        var fileDir = {}, frameDirs = [], newFiles = {};
        each(scene.comps, function (c) {
            var dir = new Folder(assetsRoot + "/" + safeFile(c.name));
            if (!opt.update) { var n = 2; while (dir.exists && dir.getFiles().length && !has(frameDirs, dir.fsName)) dir = new Folder(assetsRoot + "/" + safeFile(c.name) + " " + (n++)); }
            ensureFolder(dir.fsName);
            frameDirs.push(dir.fsName); newFiles[dir.fsName] = {};
            (function walk(v) {
                if (!v || typeof v !== "object") return;
                if (isArr(v)) { for (var i = 0; i < v.length; i++) walk(v[i]); return; }
                for (var k in v) {
                    if (k === "file" && typeof v[k] === "string") { var b = v[k].replace(/^images\//, ""); if (!fileDir[b]) fileDir[b] = dir.fsName; }
                    else walk(v[k]);
                }
            })(c);
        });
        var srcImgs = new Folder(srcFolder.fsName + "/images");
        if (srcImgs.exists) each(srcImgs.getFiles(), function (img) {
            if (!(img instanceof File)) return;
            var d = fileDir[img.displayName] || frameDirs[0];
            var target = new File(d + "/" + img.displayName);
            if (target.exists) target.remove();
            img.copy(target.fsName);
            newFiles[d][img.displayName] = true;
        });
        var assetsFolder = new Folder(frameDirs[0]);

        // project panel: every frame gets its own folder → its comp + an "Assets" folder (precomps & images)
        var proj = app.project;
        var root = null;
        try { tidyLegacyFolders(); } catch (e) { }
        var ctx = {
            opt: opt, scene: scene, assets: assetsFolder, fileDir: fileDir,
            folders: { root: root, bin: null },
            footage: {}, fontCache: {}, missingFonts: {}, warnings: [], lines: [], figmaWarnings: scene.warnings || [],
            styleJobs: [], lockLater: [], stats: { comps: 0, layers: 0, updated: 0, reused: 0 }, sigComps: {},
            gradOK: probeGradientSupport(), total: 0, done: 0
        };
        each(scene.comps, function (c) { ctx.total += countNodes(c.node); });
        if (opt.target === "active" && !into) warn(ctx, null, "no comp was open in After Effects, so a new comp was made instead – open a comp in the timeline, then send again");
        var offs = into ? intoOffsets(into, scene.comps) : null;
        if (offs) ctx.stats.placed = offs.placed.centred ? (offs.placed.exact ? "mixed" : "centred") : "exact";

        var firstComp = null;
        for (var i = 0; i < scene.comps.length; i++) {
            var sc = scene.comps[i];
            ui.status("Building “" + sc.name + "”…", 5);
            if (into && into.comment !== "figma-comp:" + sc.id) { buildInto(ctx, into, sc, offs[i]); continue; }
            var comp = into || (opt.update ? findComp("figma-comp:" + sc.id) : null), keep = null;
            if (comp) {
                keep = clearImported(ctx, comp);
                comp.width = compDim(sc.w); comp.height = compDim(sc.h);
                ctx.stats.updated++;
            } else {
                comp = proj.items.addComp(uniqueCompName(sc.name), compDim(sc.w), compDim(sc.h), 1, opt.duration, opt.fps);
            }
            comp.comment = "figma-comp:" + sc.id;
            // renamed in Figma → follow it (but keep a " (2)" we added to tell same-named frames apart)
            if (comp.name !== safeName(sc.name) && comp.name.replace(/ \(\d+\)$/, "") !== safeName(sc.name)) comp.name = uniqueCompName(sc.name, comp);
            // project panel: Framelift ▸ <frame> ▸ comp + Assets
            // each comp has its own folder (a re-send with "Update existing" off gets a new one)
            var frameFolder = (comp.parentFolder instanceof FolderItem && /^figma-folder:/.test(comp.parentFolder.comment || "")) ? comp.parentFolder : null;
            if (!frameFolder) { frameFolder = proj.items.addFolder(comp.name); frameFolder.comment = "figma-folder:" + sc.id; }
            if (frameFolder.name !== comp.name) frameFolder.name = comp.name;
            frameFolder.parentFolder = rootFolder();
            comp.parentFolder = frameFolder;
            ctx.folders.bin = assetsOf(comp, true);
            ctx.frameName = comp.name;
            try { comp.hideShyLayers = true; } catch (e) { }
            ctx.stats.comps++;
            if (!firstComp) firstComp = comp;
            var cont = { M: IDENT, o: [0, 0], parent: null };
            if (sc.rootIsFrame) {
                var bg = firstSolid(sc.node.bg ? sc.node.bg.fills : null);
                if (bg) comp.bgColor = bg;
                buildContainerContents(ctx, comp, sc.node, cont, !sc.node.visible);
            } else if (sc.node) {
                buildNode(ctx, comp, sc.node, cont, false, false);
            }
            if (keep) restoreAfterUpdate(ctx, comp, keep);
            if (sc.reference) addReference(ctx, comp, sc, cont);
        }
        ui.status("Applying layer styles…", 92);
        applyStyleJobs(ctx);
        each(ctx.lockLater, function (l) { try { l.locked = true; } catch (e) { } });
        if (opt.openComp && firstComp) firstComp.openInViewer();
        else if (prevActive && !into && ctx.styleJobs.length) try { prevActive.openInViewer(); } catch (e) { }   // layer styles open precomps – go back
        if (into) {
            // back to the comp you were in (layer styles open precomps), with what was just added selected
            try { into.openInViewer(); } catch (e) { }
            try { var sl = into.selectedLayers; for (var si = 0; si < sl.length; si++) sl[si].selected = false; } catch (e) { }
            each(ctx.addedLayers || [], function (l) { try { if (!l.shy) l.selected = true; } catch (e) { } });
        }
        // tidy up: temp unpack + incoming package go away, stale images from older sends are pruned
        if (tmp) removeFolder(tmp);
        if (opt.transient) try { file.remove(); } catch (e) { }
        each(frameDirs, function (d) { pruneAssets(new Folder(d), newFiles[d]); });
        ctx.time = new Date().getTime() - t0;
        return ctx;
    }

    // =====================================================================  add to active comp
    function activeComp() {
        var a = null;
        try { a = app.project.activeItem; } catch (e) { }
        return a instanceof CompItem ? a : null;
    }
    var ADDED = " @in:";   // layer comment suffix: which Figma selection a layer was added from
    function addedFrom(l) { var c = ""; try { c = l.comment; } catch (e) { } var k = c.indexOf(ADDED); return k < 0 ? null : c.substr(k + ADDED.length); }
    // Where each selection goes. Active comp imported from one of its parent frames → its exact Figma
    // position. Otherwise centred: layers from the same frame as one block (keeping their layout),
    // whole frames each on their own.
    function intoOffsets(into, comps) {
        var offs = [], blocks = {}, order = [], placed = { exact: 0, centred: 0 };
        offs.placed = placed;
        for (var i = 0; i < comps.length; i++) {
            var sc = comps[i], at = sc.at || { x: 0, y: 0, frames: [] }, fr = at.frames || [], hit = null;
            // 1) the comp was imported from one of its parent frames  2) the comp is the same size as one of them
            //    (your own / duplicated comp at the frame size) → exact Figma position.  Otherwise centred.
            each(fr, function (f) { if (!hit && into.comment === "figma-comp:" + f.id) hit = f; });
            if (!hit) each(fr, function (f) { if (f.w && Math.abs(compDim(f.w) - into.width) < 1 && Math.abs(compDim(f.h) - into.height) < 1) hit = f; });   // outermost wins
            if (hit) { offs[i] = [hit.x, hit.y]; placed.exact++; continue; }
            placed.centred++;
            var key = fr.length ? "in:" + fr[fr.length - 1].id : "own:" + i;
            if (!blocks[key]) { blocks[key] = { u: [1e12, 1e12, -1e12, -1e12], members: [] }; order.push(key); }
            var b = blocks[key], u = b.u;
            b.u = [Math.min(u[0], at.x), Math.min(u[1], at.y), Math.max(u[2], at.x + sc.w), Math.max(u[3], at.y + sc.h)];
            b.members.push(i);
        }
        each(order, function (key) {
            var b = blocks[key], u = b.u;
            var dx = Math.round((into.width - (u[2] - u[0])) / 2 - u[0]), dy = Math.round((into.height - (u[3] - u[1])) / 2 - u[1]);
            each(b.members, function (i) { var at = comps[i].at || { x: 0, y: 0 }; offs[i] = [at.x + dx, at.y + dy]; });
        });
        return offs;
    }
    function buildInto(ctx, comp, sc, off) {
        var proj = app.project, i, old = [], anim = {}, sources = [], below = null;
        // re-sending the same selection (with "Update existing" on) replaces it in place, keeping its animation
        if (ctx.opt.update) {
            for (i = 1; i <= comp.numLayers; i++) {
                var l = comp.layer(i);
                if (addedFrom(l) === sc.id) {
                    old.push(l);
                    if (l.source && (l.source instanceof CompItem || l.source instanceof FootageItem) && !l.nullLayer) sources.push(l.source);
                } else if (old.length && !below) below = l;
            }
            anim = snapAll(old, comp);
            each(old, function (l) { try { l.locked = false; } catch (e) { } });
            each(old, function (l) { try { l.remove(); } catch (e) { warn(ctx, null, "couldn't remove old layer " + l.name); } });
            each(sources, function (src) { removeIfUnused(src); });
        }
        // images / precomps go with the comp they're added to: its own Assets folder if Framelift made it,
        // otherwise Framelift ▸ Added to comps. No extra folder per send.
        ctx.folders.bin = assetsOf(comp, false) || addedFolder();
        ctx.frameName = comp.name;

        var n0 = comp.numLayers, cont = { M: IDENT, o: off, parent: null };
        if (sc.rootIsFrame) buildNode(ctx, comp, sc.node, cont, !sc.node.visible, true);   // a whole frame → one precomp layer
        else if (sc.node) buildNode(ctx, comp, sc.node, cont, false, false);
        var added = [];
        for (i = 1; i <= comp.numLayers - n0; i++) added.push(comp.layer(i));
        each(added, function (l) { try { l.comment = (l.comment || "figma:" + sc.id) + ADDED + sc.id; } catch (e) { } });
        // new sends start at the playhead (re-sends keep their timing)
        var t0 = 0; try { t0 = comp.time; } catch (e) { }
        if (t0 > 0) { var ak = layerKeys(added);
            for (i = 0; i < added.length; i++) if (!findByKeys(anim, ak[i])) try { added[i].startTime = t0; } catch (e) { } }
        var kept = restoreAll(added, anim);
        // back where the old version sat in the layer stack (new sends go on top)
        if (old.length && added.length) {
            try {
                if (below) { for (i = added.length - 1; i >= 0; i--) { added[i].moveBefore(below); below = added[i]; } }
                else { added[added.length - 1].moveToEnd(); for (i = added.length - 2; i >= 0; i--) added[i].moveBefore(added[i + 1]); }
            } catch (e) { }
        }
        ctx.folders.bin = null;
        if (old.length) ctx.stats.updated++;
        if (kept) warn(ctx, null, "kept animation on " + kept + " layer(s)");
        ctx.stats.into = comp.name;
        ctx.addedLayers = (ctx.addedLayers || []).concat(added);
    }


    function pruneAssets(folder, keep) {
        var used = {};
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            try { if (it instanceof FootageItem && it.file) used[it.file.fsName] = true; } catch (e) { }
        }
        var shared = otherProjectsHere();   // another .aep in this folder may use these files → only touch this send's copies
        each(folder.getFiles(), function (f) {
            if (f instanceof File && !used[f.fsName] && (!shared || keep[f.displayName])) try { f.remove(); } catch (e) { }   // stale, or a copy of a picture we reused
        });
        try { if (!folder.getFiles().length) folder.remove(); } catch (e) { }
    }
    function otherProjectsHere() {
        try { var pf = app.project.file; if (!pf) return false; return pf.parent.getFiles("*.aep").length > 1; } catch (e) { return true; }
    }
    // ---- "Tidy project": remove what Framelift made that nothing uses any more
    function underFramelift(item) {
        var root = findTagged(FolderItem, "framelift-root");
        for (var f = item.parentFolder, n = 0; f && n < 12; f = f.parentFolder, n++) { if (f === root) return true; if (f === app.project.rootFolder) break; }
        return false;
    }
    function tidyProject() {
        var proj = app.project, res = { comps: 0, images: 0, folders: 0, files: 0 }, i, gone = 1;
        app.beginUndoGroup("Tidy Framelift project");
        try {
            try { tidyLegacyFolders(); } catch (e) { }
            for (var pass = 0; pass < 10 && gone; pass++) {
                gone = 0;
                for (i = proj.numItems; i >= 1; i--) {
                    var it = proj.item(i);
                    try {
                        if (it instanceof CompItem && /^figma-pre:/.test(it.comment || "") && !(it.usedIn && it.usedIn.length)) { it.remove(); res.comps++; gone++; }
                        else if (it instanceof FootageItem && (/^figma-img:/.test(it.comment || "") || underFramelift(it)) && !(it.usedIn && it.usedIn.length)) { it.remove(); res.images++; gone++; }
                        else if (it instanceof FolderItem && !it.numItems && (/^figma-|^framelift-/.test(it.comment || "") || underFramelift(it))) { it.remove(); res.folders++; gone++; }
                    } catch (e) { }
                }
            }
        } finally { app.endUndoGroup(); }
        // image files on disk nothing in this project uses → "Figma assets/Unused (safe to delete)"
        var note = "";
        if (proj.file) {
            var assets = new Folder(proj.file.parent.fsName + "/Figma assets");
            if (otherProjectsHere()) note = "\n\nImage files on disk were left alone: another project in this folder may use them.";
            else if (assets.exists) {
                var used = {};
                for (i = 1; i <= proj.numItems; i++) { var x = proj.item(i); try { if (x instanceof FootageItem && x.file) used[x.file.fsName] = true; } catch (e) { } }
                var bin = new Folder(assets.fsName + "/Unused (safe to delete)");
                each(assets.getFiles(function (f) { return f instanceof Folder && f.displayName !== bin.displayName; }), function (d) {
                    each(d.getFiles(), function (f) {
                        if (!(f instanceof File) || used[f.fsName]) return;
                        var dest = new Folder(bin.fsName + "/" + d.displayName); ensureFolder(dest.fsName);
                        try { if (f.copy(dest.fsName + "/" + f.displayName)) { f.remove(); res.files++; } } catch (e) { }
                    });
                    try { if (!d.getFiles().length) d.remove(); } catch (e) { }
                });
                if (res.files) note = "\n\nMoved " + res.files + " unused image file(s) to “Figma assets/Unused (safe to delete)”.";
            }
        }
        var n = res.comps + res.images + res.folders;
        alert("Framelift – Tidy project\n\n" + (n ? "Removed " + res.comps + " unused precomp(s), " + res.images + " unused image(s) and " + res.folders + " empty folder(s)." : "Nothing unused in the project.") +
            note + (n ? "\n\n(Edit ▸ Undo brings them back.)" : ""));
    }
    function countNodes(n) { if (!n) return 0; var c = 1; each(n.children, function (k) { c += countNodes(k); }); return c; }
    function tick(ctx, n) {
        ctx.done++; ctx.stats.layers++;
        if (ctx.done % 10 === 0) ui.status("Building layers… " + ctx.done + "/" + ctx.total, 5 + 85 * ctx.done / Math.max(1, ctx.total));
    }
    function compDim(v) { return clamp(Math.ceil(v - 1e-3), 4, 30000); }
    function safeName(s) { s = String(s || "Layer"); return s.length > 250 ? s.substr(0, 250) : s; }
    function warn(ctx, node, msg) { ctx.warnings.push({ node: node ? node.name : "", msg: msg }); }
    function firstSolid(paints) { if (!paints) return null; for (var i = paints.length - 1; i >= 0; i--) if (paints[i].type === "solid") return paints[i].color; return null; }

    function probeGradientSupport() {
        var ok = false, c = null;
        try {
            c = app.project.items.addComp("figae probe", 100, 100, 1, 1, 30);
            var g = c.layers.addShape().property("ADBE Root Vectors Group").addProperty("ADBE Vector Graphic - G-Fill");
            var p = g.property("ADBE Vector Grad Colors");
            p.setValue([0, 1, 0, 0, 0.5, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1]);
            ok = true;
        } catch (e) { ok = false; }
        try { if (c) c.remove(); } catch (e2) { }
        return ok;
    }

    // =====================================================================  reference screenshot
    function addReference(ctx, comp, sc, cont) {
        var rf = sc.reference;
        var l = comp.layers.add(footage(ctx, rf.file), comp.duration);
        place(ctx, l, rf.m, cont, [rf.w / 2, rf.h / 2], [0, 0]);
        l.name = "Figma reference";
        try { l.comment = "figma-ref:" + sc.id; } catch (e) { }
        l.guideLayer = true;          // never renders, even if switched on
        l.enabled = false;            // hidden until you toggle the eye
        tag(l, "reference");
        l.moveToBeginning();
        ctx.lockLater.push(l);
    }

    // =====================================================================  update in place (live link)
    function findFolder(name, parent) {
        var want = parent || app.project.rootFolder;
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem && it.name === name && it.parentFolder === want) return it;
        }
        return null;
    }
    // Everything Framelift makes lives in one "Framelift" folder (adopts one you made yourself)
    function rootFolder() {
        var f = findTagged(FolderItem, "framelift-root");
        if (!f) {
            for (var i = 1; i <= app.project.numItems && !f; i++) {
                var it = app.project.item(i);
                if (it instanceof FolderItem && it.parentFolder === app.project.rootFolder && /^framelift$/i.test(it.name)) f = it;
            }
            if (!f) f = app.project.items.addFolder("Framelift");
            f.comment = "framelift-root";
        }
        return f;
    }
    function sharedFolder() {
        var f = findTagged(FolderItem, "figma-shared");
        if (!f) { f = app.project.items.addFolder("Shared (Figma)"); f.comment = "figma-shared"; }
        if (f.parentFolder !== rootFolder()) f.parentFolder = rootFolder();
        return f;
    }
    // Projects from older versions: one top-level folder per send. Move everything Framelift made into
    // the Framelift folder; image-only folders (from adding layers to a comp) merge into "Added to comps".
    function tidyLegacyFolders() {
        var proj = app.project, root = proj.rootFolder, legacy = [], i;
        for (i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof FolderItem && it.parentFolder === root && /^figma-(folder:|shared$)/.test(it.comment || "")) legacy.push(it);
        }
        if (!legacy.length) return;
        var fl = rootFolder();
        each(legacy, function (f) {
            var hasComp = false, kids = [];
            for (var j = 1; j <= proj.numItems; j++) { var k = proj.item(j); if (k.parentFolder === f) { kids.push(k); if (k instanceof CompItem && /^figma-comp:/.test(k.comment || "")) hasComp = true; } }
            if (hasComp || f.comment === "figma-shared") { f.parentFolder = fl; return; }
            // no comp: just an Assets folder with images / precomps → into "Added to comps"
            var dest = addedFolder();
            each(kids, function (k) {
                if (k instanceof FolderItem) {
                    var inner = []; for (var m = 1; m <= proj.numItems; m++) if (proj.item(m).parentFolder === k) inner.push(proj.item(m));
                    each(inner, function (x) { x.parentFolder = dest; });
                    if (!k.numItems) k.remove(); else k.parentFolder = dest;
                } else k.parentFolder = dest;
            });
            if (!f.numItems) f.remove(); else f.parentFolder = fl;
        });
    }
    // a Framelift comp's "Assets" folder (sits next to it in its frame folder)
    function assetsOf(comp, create) {
        var ff = comp.parentFolder;
        if (!(ff instanceof FolderItem) || !/^figma-folder:/.test(ff.comment || "")) return null;
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem && it.parentFolder === ff && /^figma-assets:/.test(it.comment || "")) return it;
        }
        if (!create) return null;
        var b = app.project.items.addFolder("Assets"); b.comment = "figma-assets:" + String(comp.comment || "").replace(/^figma-comp:/, ""); b.parentFolder = ff;
        return b;
    }
    // layers added to a comp that Framelift didn't make: their images / precomps go here
    function addedFolder() {
        var f = findTagged(FolderItem, "figma-added");
        if (!f) { f = app.project.items.addFolder("Added to comps"); f.comment = "figma-added"; }
        if (f.parentFolder !== rootFolder()) f.parentFolder = rootFolder();
        return f;
    }
    // two different frames both called "Content Container" → "Content Container", "Content Container (2)"
    function uniqueCompName(name, self) {
        var base = safeName(name), taken = {};
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it !== self && it instanceof CompItem && /^figma-comp:/.test(it.comment || "")) taken[it.name] = true;
        }
        if (!taken[base]) return base;
        for (var n = 2; ; n++) if (!taken[base + " (" + n + ")"]) return base + " (" + n + ")";
    }
    function findTagged(type, tag) {
        for (var i = 1; i <= app.project.numItems; i++) { var it = app.project.item(i); if (it instanceof type && it.comment === tag) return it; }
        return null;
    }
    function findComp(tag) {
        for (var i = 1; i <= app.project.numItems; i++) { var it = app.project.item(i); if (it instanceof CompItem && it.comment === tag) return it; }
        return null;
    }
    function isImported(l) { var c = ""; try { c = l.comment; } catch (e) { } return /^figma(-ref)?:/.test(c); }
    // layer comment: "figma:<node id> ~<structural path> @in:<selection>" (path / @in only when known)
    function figmaTag(node) { return "figma:" + node.id + (node.pk !== undefined && node.pk !== null ? " ~" + node.pk : ""); }
    function tagInfo(l) {
        var c = ""; try { c = l.comment || ""; } catch (e) { }
        var m = c.match(/^(figma(?:-ref)?:\S+)(?: ~(.*?))?(?: @in:(\S+))?$/);
        return m ? { id: m[1], pk: m[2], inn: m[3] } : null;
    }
    // Keys that identify an imported layer across re-sends: by structural path (survives renamed / re-worded
    // layers and translated copies of a frame), falling back to node id + name (comps from before 1.12).
    function layerKeys(layers) {
        var seen = {}, out = [];
        each(layers, function (l) {
            var t = tagInfo(l), ks = [];
            if (t) {
                if (t.pk !== undefined) { var b = t.pk + "@" + (t.inn || ""); seen[b] = (seen[b] || 0) + 1; ks.push("p:" + b + "#" + seen[b]); }
                ks.push("i:" + t.id + "@" + (t.inn || "") + "|" + l.name);
            }
            out.push(ks);
        });
        return out;
    }
    function mapByKeys(layers, keys) { var m = {}; for (var i = 0; i < layers.length; i++) each(keys[i], function (k) { if (!m[k]) m[k] = layers[i]; }); return m; }
    function findByKeys(m, ks) { for (var i = 0; i < (ks || []).length; i++) if (m[ks[i]]) return m[ks[i]]; return null; }
    function hasAnim(snap, comp) { return snap.recs.length || snap.timing.start !== 0 || snap.timing.inP !== 0 || Math.abs(snap.timing.outP - comp.duration) > 1e-3; }
    // put saved animation back on the rebuilt layers (each snapshot used once)
    function restoreAll(layers, snaps) {
        var keys = layerKeys(layers), kept = 0;
        for (var i = 0; i < layers.length; i++) {
            var sn = findByKeys(snaps, keys[i]);
            if (sn && !sn.used) { sn.used = true; restoreAnim(layers[i], sn); kept++; }
        }
        return kept;
    }
    function snapAll(layers, comp) {
        var keys = layerKeys(layers), snaps = {};
        for (var i = 0; i < layers.length; i++) {
            var sn = snapshotAnim(layers[i]);
            if (hasAnim(sn, comp)) each(keys[i], function (k) { if (!snaps[k]) snaps[k] = sn; });
        }
        return snaps;
    }
    var ANIM_PROPS = ["ADBE Anchor Point", "ADBE Position", "ADBE Position_0", "ADBE Position_1", "ADBE Scale", "ADBE Rotate Z", "ADBE Opacity"];
    function snapshotAnim(l) {
        var t = tr(l), recs = [], sepPos = false;
        try { sepPos = t.property("ADBE Position").dimensionsSeparated; } catch (e) { }
        for (var i = 0; i < ANIM_PROPS.length; i++) {
            var p = t.property(ANIM_PROPS[i]); if (!p) continue;
            var expr = ""; try { if (p.expressionEnabled) expr = p.expression; } catch (e) { }
            if (!p.numKeys && !expr) continue;
            var rec = { name: ANIM_PROPS[i], expr: expr, keys: [] };
            for (var k = 1; k <= p.numKeys; k++) {
                var key = { t: p.keyTime(k), v: p.keyValue(k), ii: p.keyInInterpolationType(k), oi: p.keyOutInterpolationType(k),
                    ie: p.keyInTemporalEase(k), oe: p.keyOutTemporalEase(k) };
                try { if (p.isSpatial) { key.ist = p.keyInSpatialTangent(k); key.ost = p.keyOutSpatialTangent(k); } } catch (e) { }
                rec.keys.push(key);
            }
            recs.push(rec);
        }
        var timing = { start: l.startTime, inP: l.inPoint, outP: l.outPoint };
        return { recs: recs, sepPos: sepPos, timing: timing };
    }
    function restoreAnim(l, snap) {
        var t = tr(l);
        try { l.startTime = snap.timing.start; l.inPoint = snap.timing.inP; l.outPoint = snap.timing.outP; } catch (e) { }
        if (snap.sepPos) try { t.property("ADBE Position").dimensionsSeparated = true; } catch (e) { }
        for (var i = 0; i < snap.recs.length; i++) {
            var rec = snap.recs[i], p = t.property(rec.name); if (!p) continue;
            try {
                for (var k = 0; k < rec.keys.length; k++) p.setValueAtTime(rec.keys[k].t, rec.keys[k].v);
                for (k = 0; k < rec.keys.length; k++) {
                    var key = rec.keys[k], idx = p.nearestKeyIndex(key.t);
                    try { p.setTemporalEaseAtKey(idx, key.ie, key.oe); } catch (e) { }
                    try { p.setInterpolationTypeAtKey(idx, key.ii, key.oi); } catch (e) { }
                    if (key.ist) try { p.setSpatialTangentsAtKey(idx, key.ist, key.ost); } catch (e) { }
                }
                if (rec.expr) p.expression = rec.expr;
            } catch (e) { }
        }
    }
    // Removes the previous import from a comp. Keeps your own layers, remembers animation on imported ones.
    function clearImported(ctx, comp) {
        var userLayers = [], userParents = [], kill = [], sources = [], i;
        for (i = 1; i <= comp.numLayers; i++) {
            var l = comp.layer(i);
            if (isImported(l) && addedFrom(l) === null) {
                kill.push(l);
                if (l.source && (l.source instanceof CompItem || l.source instanceof FootageItem) && !l.nullLayer) sources.push(l.source);
            } else userLayers.push(l);
        }
        var anim = snapAll(kill, comp), killKeys = layerKeys(kill);
        each(userLayers, function (u) {
            var pk = null;
            if (u.parent) for (var j = 0; j < kill.length; j++) if (kill[j] === u.parent) pk = killKeys[j];
            userParents.push(pk);
        });
        for (i = 0; i < kill.length; i++) { try { kill[i].locked = false; } catch (e) { } }
        for (i = 0; i < kill.length; i++) { try { kill[i].remove(); } catch (e) { warn(ctx, null, "couldn't remove old layer " + kill[i].name); } }
        each(sources, function (src) { removeIfUnused(src); });
        return { anim: anim, userLayers: userLayers, userParents: userParents };
    }
    function removeIfUnused(item) {
        try {
            if (item.usedIn && item.usedIn.length) return;
            if (item instanceof CompItem) {
                if (!/^figma-pre:/.test(item.comment)) return;
                var inner = [];
                for (var i = 1; i <= item.numLayers; i++) { var s = item.layer(i).source; if (s && !item.layer(i).nullLayer) inner.push(s); }
                item.remove();
                each(inner, function (s) { removeIfUnused(s); });
            } else if (item instanceof FootageItem && item.mainSource instanceof FileSource) item.remove();
        } catch (e) { }
    }
    function restoreAfterUpdate(ctx, comp, keep) {
        var fresh = [], i;
        for (i = 1; i <= comp.numLayers; i++) { var l = comp.layer(i); if (isImported(l) && addedFrom(l) === null) fresh.push(l); }
        var byKey = mapByKeys(fresh, layerKeys(fresh));
        var kept = restoreAll(fresh, keep.anim);
        // your own layers go back on top, in their original order, re-linked to their imported parents
        for (i = keep.userLayers.length - 1; i >= 0; i--) {
            var u = keep.userLayers[i];
            try { u.moveToBeginning(); } catch (e) { }
            var par = findByKeys(byKey, keep.userParents[i]);
            if (par) try { u.setParentWithJump(par); } catch (e) { }
        }
        if (kept) warn(ctx, null, "kept animation on " + kept + " layer(s) in “" + comp.name + "”");
    }

    // =====================================================================  live link (background tick)
    // AE may run scheduled tasks in a different script engine than this panel, so the tick re-loads
    // this script file on its first run and caches its entry point in that engine. The panel and
    // the tick talk only through app.settings, which every engine shares.
    var SCRIPT_URI = (function () { try { return new File($.fileName).absoluteURI; } catch (e) { return ""; } })();
    function sget(k, d) { try { return app.settings.haveSetting(SETTINGS_SECTION, k) ? app.settings.getSetting(SETTINGS_SECTION, k) : d; } catch (e) { return d; } }
    function sset(k, v) { try { app.settings.saveSetting(SETTINGS_SECTION, k, String(v)); } catch (e) { } }

    function scheduleTick() {
        var old = parseInt(sget("liveTask", ""), 10);
        if (!isNaN(old)) try { app.cancelTask(old); } catch (e) { }
        sset("liveErr", ""); sset("liveBeat", "0"); sset("liveServer", "starting…"); sset("liveWatch", "starting…");
        var code = 'try{if($.global.__figaeTickFn){$.global.__figaeTickFn();}else{$.global.__figaeTick=true;$.evalFile(new File("' + SCRIPT_URI + '"));}}' +
            'catch(e){app.settings.saveSetting("' + SETTINGS_SECTION + '","liveErr",e.toString()+" (line "+e.line+")");}';
        var id = app.scheduleTask(code, 500, true);
        sset("liveTask", id);
        return id;
    }
    function bgTick() {
        if (sget("live", "true") !== "true") return;
        sset("liveBeat", new Date().getTime());
        if ($.global.__figaeBusy) return;
        $.global.__figaeBusy = true;
        try {
            relayTick();
        } catch (err) {
            sset("liveErr", err.toString() + " (line " + err.line + ")");
        } finally {
            $.global.__figaeBusy = false;
        }
    }
    // ---- Windows: the same relay in PowerShell (built into Windows 10/11), started hidden via wscript.
    var RELAY_PS = "# Framelift relay for Windows (PowerShell 5.1+, built into Windows 10/11).\n# Started hidden by the After Effects panel. Receives exports from the Figma plugin on localhost and drops\n# them into a folder the panel watches; answers status / progress / result queries. Same protocol as the\n# macOS Perl relay. Quits when asked (relay.stop) or when After Effects has been gone for hours.\nparam([string]$dir)\n$VERSION = '__VERSION__'\n$enc = New-Object System.Text.UTF8Encoding($false)\n$log = Join-Path $dir 'relay.log'\nfunction Log([string]$m) { try { [IO.File]::AppendAllText($log, (Get-Date).ToString('s') + ' ' + $m + \"`r`n\", $enc) } catch { } }\nfunction WFile([string]$f, [byte[]]$b) {\n  [IO.File]::WriteAllBytes(\"$f.tmp\", $b)\n  if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force }\n  [IO.File]::Move(\"$f.tmp\", $f)\n}\nfunction RText([string]$f) { if (Test-Path -LiteralPath $f) { return [IO.File]::ReadAllText($f, $enc) } return $null }\nfunction HbAge { $f = Join-Path $dir 'heartbeat.json'; if (Test-Path -LiteralPath $f) { return ((Get-Date) - (Get-Item -LiteralPath $f).LastWriteTime).TotalSeconds } return 1e9 }\n\ntry { [IO.File]::WriteAllText($log, '', $enc) } catch { }\n$listener = $null; $port = 0\nforeach ($p in 7239..7243) {\n  try {\n    $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)\n    $l.Start(); $listener = $l; $port = $p; break\n  } catch { Log (\"port $p busy: \" + $_.Exception.Message) }\n}\nif (-not $listener) { Log 'no free port (7239-7243)'; exit 1 }\nWFile (Join-Path $dir 'relay.pid') ($enc.GetBytes([string]$PID))\nWFile (Join-Path $dir 'relay.port') ($enc.GetBytes([string]$port))\n$stopFile = Join-Path $dir 'relay.stop'\nif (Test-Path -LiteralPath $stopFile) { Remove-Item -LiteralPath $stopFile -Force }\nLog \"listening on 127.0.0.1:$port (pid $PID, PowerShell $($PSVersionTable.PSVersion))\"\n\n$cors = \"Access-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: *`r`nAccess-Control-Allow-Private-Network: true`r`n\"\n$reasons = @{ 200 = 'OK'; 204 = 'No Content'; 400 = 'Bad Request'; 404 = 'Not Found' }\nfunction Reply($s, [int]$code, [string]$body) {\n  $b = $enc.GetBytes($body)\n  $h = \"HTTP/1.1 $code \" + $reasons[$code] + \"`r`n\" + $cors + \"Content-Type: application/json; charset=utf-8`r`nContent-Length: \" + $b.Length + \"`r`nConnection: close`r`n`r`n\"\n  $hb = [Text.Encoding]::ASCII.GetBytes($h)\n  $s.Write($hb, 0, $hb.Length)\n  if ($b.Length) { $s.Write($b, 0, $b.Length) }\n  $s.Flush()\n}\n\n$aliveFile = Join-Path $dir 'relay.alive'\n$lastAlive = [DateTime]::MinValue\nwhile ($true) {\n  if (((Get-Date) - $lastAlive).TotalSeconds -ge 2) {\n    try { [IO.File]::WriteAllText($aliveFile, [string]$PID, $enc) } catch { }\n    $lastAlive = Get-Date\n    if (Test-Path -LiteralPath $stopFile) { Log 'stop requested'; break }\n    if ((HbAge) -gt 21600) { Log 'After Effects gone for 6 h - quitting'; break }\n  }\n  if (-not $listener.Pending()) { Start-Sleep -Milliseconds 40; continue }\n  $c = $listener.AcceptTcpClient()\n  try {\n    $c.ReceiveTimeout = 30000; $c.SendTimeout = 30000\n    $s = $c.GetStream()\n    # request line + headers (up to the blank line)\n    $hdr = New-Object System.IO.MemoryStream\n    while ($true) {\n      $x = $s.ReadByte(); if ($x -lt 0) { break }\n      $hdr.WriteByte([byte]$x)\n      $n = $hdr.Length\n      if ($n -ge 4) { $a = $hdr.GetBuffer(); if ($a[$n - 4] -eq 13 -and $a[$n - 3] -eq 10 -and $a[$n - 2] -eq 13 -and $a[$n - 1] -eq 10) { break } }\n      if ($n -gt 65536) { break }\n    }\n    $lines = [Text.Encoding]::ASCII.GetString($hdr.ToArray()) -split \"`r`n\"\n    $first = $lines[0] -split ' '\n    $m = $first[0]; $path = if ($first.Length -gt 1) { $first[1] } else { '/' }\n    $len = 0\n    foreach ($ln in $lines) { if ($ln -match '^(?i)content-length:\\s*(\\d+)') { $len = [int]$Matches[1] } }\n\n    if ($m -eq 'OPTIONS') { Reply $s 204 '' }\n    elseif ($path -like '/status*') {\n      $hb = RText (Join-Path $dir 'heartbeat.json'); $age = HbAge\n      if ($hb -ne $null -and $age -lt 300) {\n        $asleep = if ($age -gt 8) { 'true' } else { 'false' }\n        $hb = $hb -replace '\\}\\s*$', (',\"asleep\":' + $asleep + ',\"relay\":\"' + $VERSION + '\",\"port\":' + $port + '}')\n        Reply $s 200 $hb\n      } else { Reply $s 200 '{\"ok\":false,\"error\":\"After Effects panel not running\"}' }\n    }\n    elseif ($m -eq 'POST' -and $path -match '^/import(\\?(.*))?$') {\n      $q = [string]$Matches[2]\n      $buf = New-Object byte[] $len; $got = 0\n      while ($got -lt $len) { $r = $s.Read($buf, $got, $len - $got); if ($r -le 0) { break }; $got += $r }\n      if ($got -lt $len) { Reply $s 400 '{\"ok\":false,\"error\":\"upload incomplete\"}' }\n      else {\n        $id = [string][long]((Get-Date).ToUniversalTime() - (Get-Date '1970-01-01')).TotalSeconds + (Get-Random -Maximum 999999).ToString('000000')\n        WFile (Join-Path $dir \"$id.query\") ($enc.GetBytes($q))\n        WFile (Join-Path $dir \"$id.figae\") $buf          # tmp + rename: AE only ever sees complete files\n        Reply $s 200 ('{\"ok\":true,\"queued\":true,\"id\":\"' + $id + '\"}')\n      }\n    }\n    elseif ($path -match '^/result\\?id=(\\w+)') {\n      $id = $Matches[1]\n      $rf = Join-Path $dir \"$id.result.json\"; $pf = Join-Path $dir \"$id.progress.json\"\n      $r = RText $rf\n      if ($r -ne $null) {\n        Reply $s 200 $r\n        Remove-Item -LiteralPath $rf -Force -ErrorAction SilentlyContinue\n        Remove-Item -LiteralPath $pf -Force -ErrorAction SilentlyContinue\n      } else {\n        $pp = RText $pf\n        if ($pp -ne $null) { Reply $s 200 $pp } else { Reply $s 200 '{\"pending\":true,\"pct\":0,\"text\":\"Waiting for After Effects...\"}' }\n      }\n    }\n    else { Reply $s 404 '{\"ok\":false,\"error\":\"unknown endpoint\"}' }\n  } catch { Log ('request failed: ' + $_.Exception.Message) }\n  finally { try { $c.Close() } catch { } }\n}\ntry { $listener.Stop() } catch { }\nforeach ($f in @('relay.pid', 'relay.port', 'relay.alive')) { Remove-Item -LiteralPath (Join-Path $dir $f) -Force -ErrorAction SilentlyContinue }\n";   // filled in from relay.ps1 by build/make-installer.py
    // ---- macOS: Perl relay (ships with every Mac). AE's own script sockets can't listen on many
    // setups, so a tiny background relay receives Figma's upload on localhost and drops it in a
    // folder this tick watches; progress/results go back the same way. No clipboard, no dialogs.
    var RELAY_SRC = "#!/usr/bin/perl\n# Figma \u2192 After Effects relay. Started by the AE panel; receives exports from the Figma plugin on\n# localhost and drops them into a folder the panel watches. Answers progress/result queries.\nuse strict; use warnings;\nuse IO::Socket::INET;\nmy $dir = shift or die \"usage: relay.pl <dir>\\n\";\nmy $VERSION = '__VERSION__';\nmy ($srv, $port);\nfor my $p (7239 .. 7243) {\n  $srv = IO::Socket::INET->new(LocalAddr => '127.0.0.1', LocalPort => $p, Listen => 5, ReuseAddr => 1, Proto => 'tcp', Timeout => 30);\n  if ($srv) { $port = $p; last; }\n}\ndie \"no free port\\n\" unless $srv;\nsub wfile { my ($f, $d) = @_; open(my $h, '>:raw', \"$f.tmp\") or return; print $h $d; close $h; rename \"$f.tmp\", $f; }\nsub rfile { my $f = shift; open(my $h, '<:raw', $f) or return undef; local $/; my $d = <$h>; close $h; return $d; }\nwfile(\"$dir/relay.pid\", $$);\nwfile(\"$dir/relay.port\", $port);\nmy $cors = \"Access-Control-Allow-Origin: *\\r\\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\\r\\n\" .\n           \"Access-Control-Allow-Headers: *\\r\\nAccess-Control-Allow-Private-Network: true\\r\\n\";\nsub reply {\n  my ($c, $code, $body) = @_;\n  my %t = (200 => 'OK', 204 => 'No Content', 400 => 'Bad Request', 404 => 'Not Found');\n  print $c \"HTTP/1.1 $code \" . ($t{$code} || 'OK') . \"\\r\\n$cors\" .\n    \"Content-Type: application/json; charset=utf-8\\r\\nContent-Length: \" . length($body) . \"\\r\\nConnection: close\\r\\n\\r\\n$body\";\n}\nsub hb_age { my @s = stat(\"$dir/heartbeat.json\"); return @s ? time - $s[9] : 1e9; }\nwhile (1) {\n  my $c = $srv->accept;\n  if (!$c) { exit 0 if hb_age() > 6 * 3600; next; }   # AE gone for hours \u2192 quit\n  binmode $c;\n  eval {\n    local $SIG{ALRM} = sub { die \"timeout\\n\" }; alarm 120;\n    local $/ = \"\\n\";\n    my $req = <$c>; die \"empty\\n\" unless defined $req;\n    my ($m, $path) = $req =~ /^(\\w+)\\s+(\\S+)/;\n    my %h;\n    while (defined(my $l = <$c>)) { $l =~ s/\\r?\\n$//; last if $l eq ''; my ($k, $v) = split /:\\s*/, $l, 2; $h{lc $k} = $v if defined $v; }\n    if ($m eq 'OPTIONS') { reply($c, 204, ''); }\n    elsif ($path =~ m{^/status}) {\n      my $hb = rfile(\"$dir/heartbeat.json\");\n      my $age = hb_age();\n      if (defined $hb && $age < 300) { $hb =~ s/\\}\\s*$/,\"asleep\":${\\($age > 8 ? 'true' : 'false')},\"relay\":\"$VERSION\",\"port\":$port}/; reply($c, 200, $hb); }\n      else { reply($c, 200, '{\"ok\":false,\"error\":\"After Effects panel not running\"}'); }\n    }\n    elsif ($m eq 'POST' && $path =~ m{^/import(?:\\?(.*))?$}) {\n      my $q = $1 // ''; my $len = $h{'content-length'} // 0; my $buf = '';\n      while (length($buf) < $len) { my $n = read($c, $buf, $len - length($buf), length($buf)); last unless $n; }\n      if (length($buf) < $len) { reply($c, 400, '{\"ok\":false,\"error\":\"upload incomplete\"}'); }\n      else {\n        my $id = time() . sprintf('%06d', int(rand(1e6)));\n        wfile(\"$dir/$id.query\", $q);\n        wfile(\"$dir/$id.figae\", $buf);                  # atomic (tmp + rename) \u2013 AE picks it up\n        reply($c, 200, qq({\"ok\":true,\"queued\":true,\"id\":\"$id\"}));\n      }\n    }\n    elsif ($path =~ m{^/result\\?id=(\\w+)}) {\n      my $id = $1;\n      my $r = rfile(\"$dir/$id.result.json\");\n      if (defined $r) { reply($c, 200, $r); unlink \"$dir/$id.result.json\", \"$dir/$id.progress.json\"; }\n      else { my $p = rfile(\"$dir/$id.progress.json\"); reply($c, 200, defined $p ? $p : '{\"pending\":true,\"pct\":0,\"text\":\"Waiting for After Effects...\"}'); }\n    }\n    else { reply($c, 404, '{\"ok\":false,\"error\":\"unknown endpoint\"}'); }\n    alarm 0;\n  };\n  close $c;\n}\n";
    function sh(p) { return "'" + String(p).replace(/'/g, "'\\''") + "'"; } // shell-quote a path
    function relayDir() { return ensureFolder(Folder.userData.fsName + "/Framelift/relay"); }
    function writeJSON(path, obj) {
        try { var f = new File(path + ".tmp"); f.encoding = "UTF-8"; f.lineFeed = "Unix"; f.open("w"); f.write(toJSON(obj)); f.close(); var t = new File(path); if (t.exists) t.remove(); f.rename(t.name); } catch (e) { }
    }
    function readSmall(f) { try { f.encoding = "UTF-8"; f.open("r"); var t = f.read(); f.close(); return t; } catch (e) { return ""; } }
    function relayStart() {
        var dir = relayDir();
        // leftovers from sends Figma never collected (plugin closed mid-send)
        try { each(dir.getFiles(), function (f) { if (f instanceof File && /\.(progress|result)\.json$|\.query$/.test(f.displayName) && new Date().getTime() - f.modified.getTime() > 3600000) f.remove(); }); } catch (e) { }
        if (!IS_MAC) { relayStartWin(dir); return; }
        var pl = new File(dir.fsName + "/relay.pl"); pl.encoding = "UTF-8"; pl.lineFeed = "Unix"; pl.open("w"); pl.write(RELAY_SRC.replace("__VERSION__", VERSION)); pl.close();
        var st = new File(dir.fsName + "/start.sh"); st.encoding = "UTF-8"; st.lineFeed = "Unix"; st.open("w");
        st.write("D=" + sh(dir.fsName) + "\n/usr/bin/pkill -f \"perl .*/relay/relay[.]pl\" 2>/dev/null; sleep 0.4\n" +
            "rm -f \"$D/relay.port\"\nnohup /usr/bin/perl \"$D/relay.pl\" \"$D\" >\"$D/relay.log\" 2>&1 &\n");
        st.close();
        writeJSON(dir.fsName + "/heartbeat.json", heartbeat());
        system.callSystem("/bin/sh " + sh(st.fsName));
        if (!$.global.__figaeRelayFails) sset("liveServer", "starting relay…");
        $.global.__figaeRelayCheck = new Date().getTime();
    }
    function relayStartWin(dir) {
        var ps = new File(dir.fsName + "\\relay.ps1"); ps.encoding = "UTF-8"; ps.lineFeed = "Windows"; ps.open("w"); ps.write(RELAY_PS.replace("__VERSION__", VERSION)); ps.close();
        var pid = trim(readSmall(new File(dir.fsName + "\\relay.pid")));
        each(["relay.port", "relay.alive", "relay.stop"], function (n) { try { var f = new File(dir.fsName + "\\" + n); if (f.exists) f.remove(); } catch (e) { } });
        // VBScript launcher: runs PowerShell with no console window and returns immediately. It finds its own
        // folder, so the file stays plain ASCII (safe for user names like "André").
        var vbs = new File(dir.fsName + "\\start.vbs"); vbs.encoding = "UTF-8"; vbs.lineFeed = "Windows"; vbs.open("w");
        vbs.write(winLauncher(pid)); vbs.close();
        writeJSON(dir.fsName + "/heartbeat.json", heartbeat());
        // open it like a double-click (Unicode-safe, no console); fall back to wscript on the command line
        var ok = false; try { ok = vbs.execute(); } catch (e) { }
        if (!ok) system.callSystem('wscript.exe //nologo //B "' + vbs.fsName + '"');
        if (!$.global.__figaeRelayFails) sset("liveServer", "starting link…");
        $.global.__figaeRelayCheck = new Date().getTime() + 10000;   // PowerShell can take a few seconds the first time
    }
    function winLauncher(pid) {
        return 'Set fso = CreateObject("Scripting.FileSystemObject")\r\n' +
            'Set sh = CreateObject("WScript.Shell")\r\n' +
            'd = fso.GetParentFolderName(WScript.ScriptFullName)\r\n' +
            (/^\d+$/.test(pid) ? 'sh.Run "taskkill /F /FI ""PID eq ' + pid + '"" /FI ""IMAGENAME eq powershell.exe""", 0, True\r\n' : '') +
            'sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & d & "\\relay.ps1"" """ & d & """", 0, False\r\n';
    }
    function relayAlive(dir) {
        if (IS_MAC) {
            var pid = trim(readSmall(new File(dir.fsName + "/relay.pid")));
            return /^\d+$/.test(pid) && /alive/.test(system.callSystem("kill -0 " + pid + " 2>/dev/null && echo alive"));
        }
        // Windows: the relay touches relay.alive every 2 s (no shell calls – they'd flash a console window)
        var f = new File(dir.fsName + "\\relay.alive");
        try { return f.exists && new Date().getTime() - f.modified.getTime() < 10000; } catch (e) { return false; }
    }
    function relayStop() {
        var dir = relayDir(), pid = trim(readSmall(new File(dir.fsName + "/relay.pid")));
        if (!IS_MAC) { try { var sf = new File(dir.fsName + "\\relay.stop"); sf.open("w"); sf.write("stop"); sf.close(); } catch (e) { } }
        else if (/^\d+$/.test(pid)) system.callSystem("kill " + pid + " 2>/dev/null");
        var hb = new File(dir.fsName + "/heartbeat.json"); if (hb.exists) hb.remove();
    }
    function heartbeat() {
        var name = "Untitled project"; try { if (app.project && app.project.file) name = app.project.file.displayName; } catch (e) { }
        var hb = { ok: true, app: "After Effects " + app.version, version: VERSION, project: name };
        try { var a = activeComp(); if (a) { hb.activeComp = a.name; hb.activeSize = a.width + "×" + a.height; } } catch (e) { }
        return hb;
    }
    function relayTick() {
        var dir = relayDir(), now = new Date().getTime();
        if (now - ($.global.__figaeBeatT || 0) > 2000) { $.global.__figaeBeatT = now; writeJSON(dir.fsName + "/heartbeat.json", heartbeat()); }
        // is the relay alive? (checked every 20 s – restarts it if AE outlived it)
        if (now - ($.global.__figaeRelayCheck || 0) > ($.global.__figaeRelayFails ? 20000 : 5000)) {
            $.global.__figaeRelayCheck = now;
            var port = trim(readSmall(new File(dir.fsName + "/relay.port")));
            var alive = relayAlive(dir);
            if (!alive) {
                $.global.__figaeRelayFails = ($.global.__figaeRelayFails || 0) + 1;
                if ($.global.__figaeRelayFails > 1) {
                    var why = trim(readSmall(new File(dir.fsName + "/relay.log"))).split("\n")[0];
                    if (IS_MAC && !new File("/usr/bin/perl").exists) why = "Perl isn't installed on this Mac";
                    sset("liveServer", "link won't start" + (why ? " – " + why : "") + (IS_MAC ? "" : " (PowerShell may be blocked on this PC)") + " – use Save as file in Figma meanwhile");
                }
                relayStart();
            } else $.global.__figaeRelayFails = 0;
            if (alive) sset("liveServer", "direct link on localhost:" + port + " ✓");
        }
        // incoming uploads
        var files = dir.getFiles("*.figae");
        for (var i = 0; i < files.length; i++) {
            var f = files[i]; if (!(f instanceof File)) continue;
            var id = String(f.displayName).replace(/\.figae$/i, ""), qf = new File(dir.fsName + "/" + id + ".query");
            var q = parseQuery("?" + readSmall(qf)), name = q.name || "Figma";
            $.global.__figaeJob = dir.fsName + "/" + id;
            ui.live("Receiving “" + name + "” from Figma…");
            var opt = ui.read(); opt.update = q.mode !== "new"; opt.openComp = opt.openComp && !opt.update; opt.transient = true; opt.target = q.target || "new";
            var res = run(f, opt, true);
            var out;
            if (res.ctx) {
                var missing = [], warns = [], c = res.ctx;
                for (var k in c.missingFonts) missing.push(k);
                each(c.warnings, function (w) { warns.push({ node: w.node, msg: w.msg }); });   // Figma shows its own notes already
                out = { ok: true, comps: c.stats.comps, updated: c.stats.updated, layers: c.stats.layers, into: c.stats.into || "", placed: c.stats.placed || "", missingFonts: missing, warnings: warns, figma: String(c.scene.generator || ""), lines: c.lines };
                ui.live("Last: “" + name + "” " + (c.stats.into ? (c.stats.updated ? "updated in" : "added to") + " “" + c.stats.into + "”" : (c.stats.updated ? "updated" : "imported")) + " – " + c.stats.layers + " layers, " + timeStr());
            } else { out = { ok: false, error: res.error }; ui.live("⚠ " + res.error); }
            $.global.__figaeJob = null;
            writeJSON(dir.fsName + "/" + id + ".result.json", out);
            try { sset("lastResult", ("“" + name + "” (" + (q.target || "new") + ", " + (q.mode || "") + ") " + timeStr() + "\n" + toJSON(out)).substr(0, 6000)); } catch (e) { }
            try { qf.remove(); } catch (e) { }
            try { if (f.exists) f.remove(); } catch (e) { }
            return;
        }
    }
    // macOS App Nap pauses AE's idle loop while it's in the background (i.e. while you're in Figma),
    // which stalls the live link until AE is clicked. Disabling it for AE is a standard per-app setting.
    var IS_MAC = $.os.indexOf("Windows") < 0;
    function aeBundleId() {
        if (!IS_MAC) return "";
        try { return trim(system.callSystem('defaults read "' + Folder.appPackage.fsName + '/Contents/Info" CFBundleIdentifier 2>/dev/null')); } catch (e) { return ""; }
    }
    function appNapOn() {
        var id = aeBundleId(); if (!id) return false;
        try { return !/1/.test(system.callSystem("defaults read " + id + " NSAppSleepDisabled 2>/dev/null")); } catch (e) { return false; }
    }
    function offerAppNapFix(force) {
        if (!IS_MAC || sget("live", "true") !== "true" || !appNapOn()) return;
        if (!force && sget("napAsked", "") === "1") return;
        sset("napAsked", "1");
        if (!confirm("Live link: macOS pauses After Effects while you're working in Figma (App Nap), so sends only arrive when you click back into AE " +
            "and Figma falls back to a save dialog.\n\nTurn App Nap off for After Effects? (One-time setting, takes effect after restarting AE.)")) return;
        var id = aeBundleId();
        system.callSystem("defaults write " + id + " NSAppSleepDisabled -bool YES");
        alert(appNapOn() ? "Couldn't change the setting. In Terminal run:\ndefaults write " + id + " NSAppSleepDisabled -bool YES"
            : "Done. Quit and reopen After Effects once – after that Figma sends straight in, no dialog.");
    }
    // ---- progress window shown while a send from Figma is being built (background imports only)
    function progressLive(t) {
        if (/^Receiving/.test(t)) {
            progressClose();
            try {
                var w = new Window("palette", "Framelift " + VERSION.replace(/\.0$/, "") + "  ·  " + CREDIT, undefined, { closeButton: false });
                w.orientation = "column"; w.alignChildren = ["fill", "top"]; w.margins = 16; w.spacing = 8;
                var h = w.add("statictext", undefined, t.replace(/…$/, "")); h.graphics.font = ScriptUI.newFont(h.graphics.font.name, "BOLD", 12);
                var b = w.add("progressbar", undefined, 0, 100); b.preferredSize = [360, 8];
                var d = w.add("statictext", undefined, "Unpacking…"); d.preferredSize = [360, 18];
                w.show(); try { w.update(); } catch (e) { }
                $.global.__figaeProg = { w: w, b: b, d: d, h: h };
            } catch (e) { $.global.__figaeProg = null; }
        } else if ($.global.__figaeProg) {
            var P = $.global.__figaeProg;
            try { P.b.value = 100; P.h.text = /^⚠/.test(t) ? "Import failed" : "✓ Done"; P.d.text = t.replace(/^● /, ""); P.w.update(); } catch (e) { }
            try { app.scheduleTask("try{$.global.__figaeProg.w.close();}catch(e){}$.global.__figaeProg=null;", /^⚠/.test(t) ? 6000 : 1800, false); } catch (e) { progressClose(); }
        }
    }
    function progressStatus(t, pct) {
        if ($.global.__figaeJob) writeJSON($.global.__figaeJob + ".progress.json", { pending: true, pct: Math.round(pct === undefined ? 50 : pct), text: t });
        var P = $.global.__figaeProg; if (!P) return;
        try { P.d.text = t; if (pct !== undefined) P.b.value = pct; P.w.update(); } catch (e) { }
    }
    function progressClose() { try { if ($.global.__figaeProg) $.global.__figaeProg.w.close(); } catch (e) { } $.global.__figaeProg = null; }

    // ---- updates: the team's shared folder holds unzipped release packages ("Framelift 1.15 Mac/…")
    function versionOf(jsx) {
        try { jsx.encoding = "UTF-8"; jsx.open("r"); var t = jsx.read(6000); jsx.close(); var m = t.match(/var VERSION = "([^"]+)"/); return m ? m[1] : null; } catch (e) { return null; }
    }
    function newerThan(a, b) { return parseFloat(a) > parseFloat(b) + 1e-9; }
    function findPackages(root) {
        var found = [];
        (function scan(dir, depth) {
            var inst = new File(dir.fsName + "/Install Framelift.jsx"), jsx = new File(dir.fsName + "/Manual install/Framelift.jsx");
            if (inst.exists && jsx.exists) { var v = versionOf(jsx); if (v) found.push({ v: v, dir: dir, installer: inst }); return; }
            if (depth >= 2) return;
            var subs = []; try { subs = dir.getFiles(function (f) { return f instanceof Folder; }); } catch (e) { }
            each(subs, function (d) { scan(d, depth + 1); });
        })(root, 0);
        return found;
    }
    // ---- updates over the internet: a small JSON (version, notes, Mac + Windows zip links) on Box
    var UPDATE_URL = "https://raw.githubusercontent.com/robbiebunting177/framelift-windows-test/main/updates/framelift-latest.json";   // filled in from build/update-links.json by build/make-installer.py
    function httpGet(url, outFile, secs) {
        // a normal Box share link (…box.com/s/<id>) → its direct download (…box.com/shared/static/<id>)
        url = String(url).replace(/(box\.com)\/s\/([A-Za-z0-9]+)/, "$1/shared/static/$2");
        var q = '"' + url.replace(/"/g, "") + '"';
        var cmd = (IS_MAC ? "/usr/bin/curl" : "curl.exe") + " -sL --fail -m " + (secs || 6) + (outFile ? ' -o "' + outFile.fsName + '"' : "") + " " + q;
        return system.callSystem(cmd);
    }
    function checkOnline(url, interactive) {
        var info = null;
        try { info = parseJSON(trim(httpGet(url, null, 6))); } catch (e) { info = null; }
        if (!info || !info.version) {
            if (interactive) alert("Framelift couldn't read the update info.\n\nCheck you're online, and that framelift-latest.json on Box is shared with “People with the link”.");
            return;
        }
        if (!newerThan(info.version, VERSION)) { if (interactive) alert("Framelift " + VERSION + " is up to date."); return; }
        if (!interactive && sget("updSkip", "") === info.version) return;
        var zipUrl = IS_MAC ? info.mac : info.windows;
        if (!zipUrl) { if (interactive) alert("Framelift " + info.version + " is out, but there's no " + (IS_MAC ? "Mac" : "Windows") + " download for it yet."); return; }
        var news = info.notes ? "\n\nWhat's new:\n" + String(info.notes).substr(0, 900) : "";
        if (!confirm("Framelift " + info.version + " is available (you have " + VERSION + ")." + news + "\n\nDownload and install it now?")) { sset("updSkip", info.version); return; }
        sset("updSkip", "");
        var dir = new Folder(Folder.temp.fsName + "/Framelift/update " + info.version);
        try { removeFolder(dir); } catch (e) { }
        ensureFolder(dir.fsName);
        var zip = new File(dir.fsName + "/framelift.zip");
        httpGet(zipUrl, zip, 180);
        if (!zip.exists || zip.length < 20000) { alert("Framelift: the download didn't work (" + (zip.exists ? zip.length + " bytes" : "no file") + ").\n\nTry again later, or download it from Box by hand."); return; }
        if (IS_MAC) system.callSystem('/usr/bin/ditto -x -k "' + zip.fsName + '" "' + dir.fsName + '"');
        else system.callSystem('tar -xf "' + zip.fsName + '" -C "' + dir.fsName + '"');
        var inst = null;
        (function find(d, depth) {
            if (inst || depth > 3) return;
            var f = new File(d.fsName + "/Install Framelift.jsx"); if (f.exists) { inst = f; return; }
            each(d.getFiles(function (x) { return x instanceof Folder; }), function (x) { find(x, depth + 1); });
        })(dir, 0);
        if (!inst) { alert("Framelift: the download didn't contain an installer."); return; }
        $.evalFile(inst);   // the installer does the rest and says to restart After Effects
    }
    function checkUpdates(interactive) {
        var url = sget("updateUrl", "") || UPDATE_URL;
        if (url) { checkOnline(url, interactive); return; }
        var path = sget("updateFolder", ""), root = path ? new Folder(path) : null;
        if (!root || !root.exists) { if (interactive) alert("Framelift: the shared folder isn't available" + (path ? ":\n" + path : "") + ".\n\nAlt-click “Check for updates” to choose it."); return; }
        var best = null, plat = IS_MAC ? /mac/i : /win/i;
        each(findPackages(root), function (p) {
            if (!best || newerThan(p.v, best.v) || (!newerThan(best.v, p.v) && plat.test(decodeURI(p.dir.name)) && !plat.test(decodeURI(best.dir.name)))) best = p;
        });
        if (!best || !newerThan(best.v, VERSION)) { if (interactive) alert("Framelift " + VERSION + " is up to date." + (best ? "" : "\n\n(No Framelift packages found in " + root.fsName + ")")); return; }
        if (!interactive && sget("updSkip", "") === best.v) return;
        var news = "";
        try { var cl = new File(best.dir.fsName + "/Changelog.txt"); cl.encoding = "UTF-8"; cl.open("r"); var txt = cl.read().replace(/\r/g, ""); cl.close();
            var m = txt.match(/\n(\d[^\n]*\n-+\n[\s\S]*?)(\n\d[^\n]*\n-+\n|$)/); if (m) news = "\n\nWhat's new:\n" + m[1].replace(/\r/g, "").substr(0, 900); } catch (e) { }
        if (!confirm("Framelift " + best.v + " is available (you have " + VERSION + ")." + news + "\n\nInstall it now?")) { sset("updSkip", best.v); return; }
        sset("updSkip", "");
        $.evalFile(best.installer);   // the installer does everything and says to restart After Effects
    }
    function copyText(t) {
        var f = new File(Folder.temp.fsName + "/framelift-diagnostics.txt");
        f.encoding = "UTF-8"; f.lineFeed = "Unix"; f.open("w"); f.write(t); f.close();
        if (IS_MAC) system.callSystem("/usr/bin/pbcopy < " + sh(f.fsName));
        else system.callSystem('powershell.exe -NoProfile -WindowStyle Hidden -Command "Get-Content -Raw -Encoding UTF8 -LiteralPath \'' + f.fsName + '\' | Set-Clipboard"');
    }
    function diagnostics(o) {
        var L = [];
        L.push("Framelift " + VERSION + " (build " + BUILD + ") diagnostics · " + new Date().toString());
        try { L.push("Panel file: " + File($.fileName).fsName); } catch (e) { }
        L.push("After Effects " + app.version + " · " + $.os + " · build " + (app.buildNumber || "?"));
        try { L.push(IS_MAC ? "macOS " + trim(system.callSystem("sw_vers -productVersion")) + " · " + trim(system.callSystem("uname -m")) : trim(system.callSystem("cmd /c ver"))); } catch (e) { }
        L.push("Project: " + (app.project && app.project.file ? app.project.file.fsName : "unsaved"));
        var a = null; try { a = app.project.activeItem; } catch (e) { }
        L.push("Active item: " + (a ? a.name + (a instanceof CompItem ? " (comp " + a.width + "×" + a.height + ", " + a.frameRate + " fps, tag " + (a.comment || "–") + ")" : "") : "none"));
        var scr = "?"; try { scr = app.preferences.getPrefAsLong("Main Pref Section v2", "Pref_SCRIPTING_FILE_NETWORK_SECURITY"); } catch (e) { }
        L.push("Scripting file/network access: " + scr);
        L.push("Panel settings: " + toJSON(o));
        L.push("", "— Live link —", liveStatusText());
        if (true) {
            var dir = relayDir();
            L.push("Relay folder: " + dir.fsName);
            try { var fl = []; each(dir.getFiles(), function (f) { fl.push(f.displayName); }); L.push("Files (" + fl.length + "): " + fl.slice(0, 20).join(", ")); } catch (e) { }
            if (IS_MAC) L.push("Perl: " + (new File("/usr/bin/perl").exists ? "yes" : "MISSING"));
            var pid = trim(readSmall(new File(dir.fsName + "/relay.pid")));
            try { L.push("Relay process " + pid + ": " + (relayAlive(dir) ? "running" : "not running")); } catch (e) { }
            try { L.push("Port " + (trim(readSmall(new File(dir.fsName + "/relay.port"))) || "7239") + ": " + trim(system.callSystem((IS_MAC ? "/usr/bin/curl" : "curl.exe") + " -s -m 2 http://localhost:" + (trim(readSmall(new File(dir.fsName + "/relay.port"))) || "7239") + "/status")).substr(0, 300)); } catch (e) { }
            var log = trim(readSmall(new File(dir.fsName + "/relay.log")));
            if (log) L.push("relay.log:", log.split("\n").slice(-15).join("\n"));
        }
        L.push("", "— Last send —", sget("lastResult", "(none yet)"));
        return L.join("\n");
    }
    function liveStatusText() {
        if (sget("live", "true") !== "true") return "Off – Figma can't send while this is unticked.";
        var beat = parseFloat(sget("liveBeat", "0")), age = (new Date().getTime() - beat) / 1000, lines = [];
        lines.push(beat > 0 && age < 5 ? "● Running – press “Send to After Effects” in Figma." : (beat > 0 ? "○ Background task stopped " + Math.round(age) + "s ago" : "○ Starting… press Status in a second"));
        lines.push("Link: " + sget("liveServer", "–"));
        if (IS_MAC) lines.push("App Nap: " + (appNapOn() ? "ON – live link pauses while AE is in the background (press Status to fix)" : "off ✓"));
        var last = sget("liveLast", ""); if (last) lines.push(last);
        var err = sget("liveErr", ""); if (err) lines.push("Error: " + err);
        return lines.join("\n");
    }
    function removeFolder(f) {
        try {
            var kids = f.getFiles();
            for (var i = 0; i < kids.length; i++) { if (kids[i] instanceof Folder) removeFolder(kids[i]); else kids[i].remove(); }
            f.remove();
        } catch (e) { }
    }
    function liveFolder() {
        var base = (app.project && app.project.file) ? app.project.file.parent.fsName + "/Figma assets" : Folder.myDocuments.fsName + "/Framelift";
        return ensureFolder(base);
    }
    function parseQuery(url) {
        var o = {}, i = url.indexOf("?"); if (i < 0) return o;
        var parts = url.substr(i + 1).split("&");
        for (var k = 0; k < parts.length; k++) { var kv = parts[k].split("="); try { o[decodeURIComponent(kv[0])] = decodeURIComponent((kv[1] || "").replace(/\+/g, " ")); } catch (e) { } }
        return o;
    }
    function safeFile(s) { return String(s).replace(/[\\\/:*?"<>|]+/g, "_").substr(0, 80); }
    function pad2(n) { return (n < 10 ? "0" : "") + n; }
    function stamp() { var d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds()); }
    function timeStr() { var d = new Date(); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); }
    function utf8(s) {
        var out = [];
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i);
            if (c >= 0xD800 && c <= 0xDBFF && i + 1 < s.length) { c = 0x10000 + ((c - 0xD800) << 10) + (s.charCodeAt(++i) - 0xDC00); }
            if (c < 0x80) out.push(String.fromCharCode(c));
            else if (c < 0x800) out.push(String.fromCharCode(0xC0 | (c >> 6), 0x80 | (c & 63)));
            else if (c < 0x10000) out.push(String.fromCharCode(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)));
            else out.push(String.fromCharCode(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)));
        }
        return out.join("");
    }
    function toJSON(v) {
        if (v === null || v === undefined) return "null";
        if (typeof v === "number") return isFinite(v) ? String(v) : "null";
        if (typeof v === "boolean") return v ? "true" : "false";
        if (typeof v === "string") return '"' + v.replace(/[\\"\u0000-\u001f]/g, function (ch) {
            var m = { '"': '\\"', "\\": "\\\\", "\n": "\\n", "\r": "\\r", "\t": "\\t" }[ch];
            return m || "\\u" + ("000" + ch.charCodeAt(0).toString(16)).slice(-4);
        }) + '"';
        if (isArr(v)) { var a = []; for (var i = 0; i < v.length; i++) a.push(toJSON(v[i])); return "[" + a.join(",") + "]"; }
        var o = []; for (var k in v) o.push(toJSON(k) + ":" + toJSON(v[k])); return "{" + o.join(",") + "}";
    }

    // =====================================================================  generic placement
    function tr(layer) { return layer.property("ADBE Transform Group"); }
    function centre(ctx, w, h) { return ctx.opt.anchorCenter ? [w / 2, h / 2] : [0, 0]; }
    // layer-space = node-local + o.   cont.o: offset of the container's own layer space.
    function place(ctx, layer, Mnode, cont, c, o) {
        var R = mul(inv(cont.M), Mnode);
        var d = decompose(R);
        var p = ap(R, c[0], c[1]);
        var t = tr(layer);
        t.property("ADBE Anchor Point").setValue([c[0] + o[0], c[1] + o[1]]);
        t.property("ADBE Position").setValue([cont.o[0] + p[0], cont.o[1] + p[1]]);
        if (Math.abs(d.rot) > 1e-4) t.property("ADBE Rotate Z").setValue(d.rot);
        if (Math.abs(d.sx - 1) > 1e-6 || Math.abs(d.sy - 1) > 1e-6) t.property("ADBE Scale").setValue([d.sx * 100, d.sy * 100]);
        if (cont.parent) layer.setParentWithJump(cont.parent);
    }
    var BLEND = { DARKEN: "DARKEN", MULTIPLY: "MULTIPLY", LINEAR_BURN: "LINEAR_BURN", COLOR_BURN: "COLOR_BURN", LIGHTEN: "LIGHTEN",
        SCREEN: "SCREEN", LINEAR_DODGE: "LINEAR_DODGE", COLOR_DODGE: "COLOR_DODGE", OVERLAY: "OVERLAY", SOFT_LIGHT: "SOFT_LIGHT",
        HARD_LIGHT: "HARD_LIGHT", DIFFERENCE: "DIFFERENCE", EXCLUSION: "EXCLUSION", HUE: "HUE", SATURATION: "SATURATION",
        COLOR: "COLOR", LUMINOSITY: "LUMINOSITY" };
    // Label scheme (AE default label colours) – one glance tells you what a layer is.
    var LABEL = { text: 2, shape: 8, image: 7, frame: 10, mask: 4, raster: 11, helper: 0, reference: 1 };
    function tag(layer, role) {
        try { layer.label = LABEL[role]; } catch (e) { }
        if (role === "helper") try { layer.shy = true; } catch (e) { }
    }
    function roleOf(layer, node) {
        try { if (layer.source instanceof FootageItem) return "image"; if (layer.source instanceof CompItem) return "frame"; } catch (e) { }
        return node.kind === "text" ? "text" : "shape";
    }
    var BLUR_K = 1.136364 / 0.490196; // Figma blur radius → AE Gaussian blurriness (measured, bjango.com)
    function finishLayer(ctx, layer, node, hidden, opacity, own) {
        layer.name = safeName(layer.name || node.name);
        try { layer.comment = figmaTag(node); } catch (e) { }
        if (own !== false) {
            if (opacity < 0.9999) tr(layer).property("ADBE Opacity").setValue(clamp(opacity * 100, 0, 100));
            if (BLEND[node.blend]) try { layer.blendingMode = BlendingMode[BLEND[node.blend]]; } catch (e) { }
        } else if (opacity < 0.9999) tr(layer).property("ADBE Opacity").setValue(clamp(opacity * 100, 0, 100));
        if (hidden || node.visible === false) { layer.enabled = false; try { layer.shy = true; } catch (e) { } }
        if (node.locked) ctx.lockLater.push(layer);
        tag(layer, node.kind === "raster" ? "raster" : roleOf(layer, node));
    }

    // =====================================================================  dispatch
    function buildNode(ctx, comp, node, cont, hidden, forcePrecomp) {
        tick(ctx, node);
        if (node.kind === "container") return buildContainer(ctx, comp, node, cont, hidden, forcePrecomp);
        if ((forcePrecomp && needsWrap(ctx, node)) || (node.tags && node.tags.precomp)) return buildPrecomp(ctx, comp, node, cont, hidden, true);
        if (node.kind === "text") return buildText(ctx, comp, node, cont, hidden, true);
        if (node.kind === "raster") return buildRaster(ctx, comp, node, cont, hidden, true);
        return buildShapeNode(ctx, comp, node, cont, hidden, true);
    }
    // A leaf that will become more than one AE layer must be wrapped to act as a single matte.
    function needsWrap(ctx, node) {
        if (node.kind !== "shape") return false;
        var ps = (node.fills || []).concat(node.strokes || []);
        for (var i = 0; i < ps.length; i++) { if (ps[i].type === "image") return true; if (ps[i].type !== "solid" && !ctx.gradOK) return true; }
        var d = 0; each(node.effects, function (e) { if (e.type === "dropShadow" || e.type === "innerShadow" || e.type === "backgroundBlur") d++; });
        return d > 1;
    }
    function containerNeedsPrecomp(ctx, node, forced) {
        if (forced || node.mask) return true;
        if (node.tags && node.tags.precomp) return true;
        if (node.tags && node.tags.flat) return false;
        if (node.opacity < 0.9999) return true;
        if (node.shadowImg) return true;
        if (node.blend !== "NORMAL" && node.blend !== "PASS_THROUGH") return true;
        for (var i = 0; i < (node.effects || []).length; i++) if (node.effects[i].type !== "unsupported") return true;
        if (node.clip && node.isFrame && ctx.opt.precompClipped && node.clipNeeded !== false) return true;   // only when clipping hides something
        return false;
    }
    // A "graphic" = a group/frame made only of vectors/images (no text) – logos, icons, SVG imports.
    // It comes in as ONE precomp with flat contents instead of a pile of nulls and paths.
    function isGraphic(node) {
        if (node.kind !== "container" || (node.tags && node.tags.flat)) return false;
        var leaves = 0, ok = true;
        (function walk(n) { each(n.children, function (c) { if (!ok) return; if (c.kind === "container") walk(c); else if (c.kind === "text") ok = false; else leaves++; }); })(node);
        return ok && leaves >= 2;
    }
    function buildContainer(ctx, comp, node, cont, hidden, forced) {
        if (ctx.opt.graphics !== false && !ctx.inGraphic && isGraphic(node)) return buildPrecomp(ctx, comp, node, cont, hidden, false, true);
        if (containerNeedsPrecomp(ctx, node, forced)) return buildPrecomp(ctx, comp, node, cont, hidden, false);
        if (node.clip && node.isFrame && !ctx.opt.precompClipped && hasOverflow(node)) warn(ctx, node, "clipping not applied (precomp option off)");
        each(node.effects, function (e) { if (e.type === "unsupported") warn(ctx, node, e.name.toLowerCase() + " effect has no AE equivalent – skipped"); });
        var hid = hidden || node.visible === false;
        // A parent is only worth a layer when it groups 2+ things.
        if (ctx.opt.nulls && !ctx.inGraphic && (node.children || []).length >= 2) {
            var parentLayer = null, pre = [], bgBuilt = false;
            if (node.bg && node.bg.fills && node.bg.fills.length && !node.bgRaster && !hasImage(node.bg.fills)) {
                // the frame's own background becomes the parent – no extra null
                var fres = buildShapeNode(ctx, comp, bgNode(node, "", { geom: node.bg.geom, fills: node.bg.fills, strokes: [] }), cont, hid, false);
                if (fres.layers.length === 1) { parentLayer = fres.layers[0]; tag(parentLayer, "frame"); }
                pre = fres.layers; bgBuilt = true;
            }
            if (!parentLayer) {
                parentLayer = comp.layers.addNull(comp.duration);
                parentLayer.name = safeName(node.name);
                place(ctx, parentLayer, node.m, cont, centre(ctx, node.w, node.h), [0, 0]);
                try { parentLayer.comment = figmaTag(node); } catch (e) { }
                tag(parentLayer, "frame");
                pre = pre.concat([parentLayer]);
            }
            var inner = { M: node.m, o: [0, 0], parent: parentLayer };
            var res = buildContainerContents(ctx, comp, node, inner, hid, bgBuilt);
            return { layers: pre.concat(res.layers), main: parentLayer };
        }
        return buildContainerContents(ctx, comp, node, cont, hid);
    }
    function hasOverflow(node) { var rb = node.rb; return rb && (rb[0] < -0.5 || rb[1] < -0.5 || rb[0] + rb[2] > node.w + 0.5 || rb[1] + rb[3] > node.h + 0.5); }

    function hasImage(paints) { for (var i = 0; i < (paints || []).length; i++) if (paints[i].type === "image") return true; return false; }
    function buildContainerContents(ctx, comp, node, cont, hidden, bgDone) {
        var layers = [];
        // frame background: fills underneath children …
        if (node.bgRaster) { var r = buildRaster(ctx, comp, node.bgRaster, cont, hidden, false); layers = layers.concat(r.layers); }
        else if (!bgDone && node.bg && node.bg.fills && node.bg.fills.length) {
            var fnode = bgNode(node, " · background", { geom: node.bg.geom, fills: node.bg.fills, strokes: [] });
            layers = layers.concat(buildShapeNode(ctx, comp, fnode, cont, hidden, false).layers);
        }
        layers = layers.concat(buildChildren(ctx, comp, node.children || [], cont, hidden));
        // … strokes on top of children, as Figma draws them.
        if (!node.bgRaster && node.bg && node.bg.strokes && node.bg.strokes.length) {
            var snode = bgNode(node, " · stroke", { geom: node.bg.geom, fills: [], strokes: node.bg.strokes, stroke: node.bg.stroke, outline: node.bg.outline });
            layers = layers.concat(buildShapeNode(ctx, comp, snode, cont, hidden, false).layers);
        }
        return { layers: layers, main: layers[0] };
    }
    function bgNode(node, suffix, extra) {
        var n = { id: node.id, pk: node.pk, name: node.name + suffix, m: node.m, w: node.w, h: node.h, opacity: 1, blend: "NORMAL", visible: true, effects: [], kind: "shape" };
        for (var k in extra) n[k] = extra[k];
        return n;
    }

    // children bottom → top; Figma masks clip every sibling above them.
    function buildChildren(ctx, comp, children, cont, hidden) {
        var all = [], matte = null, matteType = null, matteNode = null;
        for (var i = 0; i < children.length; i++) {
            var ch = children[i];
            if (ch.mask) {
                var mres = buildNode(ctx, comp, ch, cont, hidden, true);
                matte = mres.main; matteNode = ch;
                if (matte) { tag(matte, "mask"); if (!/mask/i.test(ch.name)) try { matte.name = safeName(ch.name) + " · mask"; } catch (e) { } }
                matteType = ch.mask === "LUMINANCE" ? TrackMatteType.LUMA : TrackMatteType.ALPHA;
                all = all.concat(mres.layers);
                continue;
            }
            var res = buildNode(ctx, comp, ch, cont, hidden, !!matte);
            if (matte) each(res.layers, function (l) { if (!(l instanceof AVLayer) || l.nullLayer) return; applyMatte(ctx, l, matte, matteType, ch); });
            all = all.concat(res.layers);
        }
        if (matte) try { if (typeof matte.setTrackMatte === "function") matte.enabled = false; } catch (e) { }
        return all;
    }
    function applyMatte(ctx, layer, matte, type, node) {
        if (layer === matte) return;
        try {
            if (typeof layer.setTrackMatte === "function") { layer.setTrackMatte(matte, type); return; }
        } catch (e) { }
        // pre-2023: classic matte must sit directly above – duplicate the matte for every target.
        try {
            var d = matte.duplicate(); d.enabled = true; d.moveBefore(layer); layer.trackMatteType = type; matte.enabled = false;
        } catch (e2) { warn(ctx, node, "could not apply mask: " + e2.message); }
    }

    // =====================================================================  precomps
    // how far blurs / shadows of the layers INSIDE a node reach past their own edges (px)
    function innerSpill(node) {
        var m = 0;
        (function walk(n, self) {
            if (!self) each(n.effects, function (e) {
                if (e.type === "layerBlur") m = Math.max(m, e.r * BLUR_K * 1.6);
                else if (e.type === "dropShadow") m = Math.max(m, e.blur * 1.6 + Math.max(Math.abs(e.x), Math.abs(e.y)) + Math.max(0, e.spread || 0));
            });
            if (n.kind === "container" && n.clip && !self) return;    // a clipping frame keeps its own spill inside
            each(n.children, function (c) { walk(c, false); });
        })(node, true);
        return m;
    }
    function buildPrecomp(ctx, comp, node, cont, hidden, leafWrap, graphic) {
        var rb = (node.kind === "container" && node.clip) ? [0, 0, node.w, node.h] : (node.rb || [0, 0, node.w, node.h]);
        // blur / shadow on something inside spreads past its edges → give the precomp room, or AE cuts it off hard
        if (!(node.kind === "container" && node.clip)) {
            var sp = Math.ceil(innerSpill(node));
            if (sp > 0) rb = [rb[0] - sp, rb[1] - sp, rb[2] + 2 * sp, rb[3] + 2 * sp];
        }
        var ox = -Math.floor(rb[0]), oy = -Math.floor(rb[1]);
        var W = compDim(rb[2] + (rb[0] + ox)), H = compDim(rb[3] + (rb[1] + oy));
        // identical content (component instances, repeated logos) → build once, reuse the precomp
        var shareKey = (!leafWrap && node.sig) ? "figma-pre:sig:" + node.sig + (graphic || ctx.inGraphic ? ":g" : "") : null;
        var pc = shareKey ? (ctx.sigComps[shareKey] || findTagged(CompItem, shareKey)) : null, reused = !!pc;
        if (reused) {
            ctx.stats.reused++;
            if (pc.parentFolder !== ctx.folders.bin) { pc.parentFolder = sharedFolder(); try { pc.name = safeName(node.name); } catch (e) { } }   // used by several frames
        } else {
            pc = app.project.items.addComp(safeName(node.name + (ctx.frameName ? " · " + ctx.frameName : "")), W, H, 1, comp.duration, comp.frameRate);
            pc.parentFolder = ctx.folders.bin;
            pc.comment = shareKey || "figma-pre:" + node.id;
            try { pc.hideShyLayers = true; } catch (e) { }
            if (shareKey) ctx.sigComps[shareKey] = pc;
        }
        var o = [ox, oy];
        var inner = { M: node.m, o: o, parent: null };
        var pre = [];
        // background blur needs the backdrop of the *outer* comp → built outside.
        each(node.effects, function (e) { if (e.type === "backgroundBlur") pre.push(buildBackgroundBlur(ctx, comp, node, cont, e, hidden)); });

        if (reused) { /* contents already built */ }
        else if (leafWrap) {
            var leaf = {}; for (var k in node) leaf[k] = node[k];
            leaf.effects = []; leaf.shadowImg = null; leaf.opacity = 1; leaf.blend = "NORMAL"; leaf.mask = null; leaf.visible = true;
            if (leaf.kind === "text") buildText(ctx, pc, leaf, inner, false, false);
            else if (leaf.kind === "raster") buildRaster(ctx, pc, leaf, inner, false, false);
            else buildShapeNode(ctx, pc, leaf, inner, false, false);
        } else {
            if (graphic) ctx.inGraphic = (ctx.inGraphic || 0) + 1;
            try { buildContainerContents(ctx, pc, node, inner, false); }
            finally { if (graphic) ctx.inGraphic--; }
        }
        var l = comp.layers.add(pc);
        place(ctx, l, node.m, cont, centre(ctx, node.w, node.h), o);
        l.name = safeName(node.name);
        finishLayer(ctx, l, node, hidden, node.opacity, true);
        if (node.kind === "container" && node.clip && node.radius && (node.radius[0] || node.radius[1] || node.radius[2] || node.radius[3])) {
            addMask(l, roundedRect(o[0], o[1], node.w, node.h, node.radius), MaskMode.ADD);
        }
        if (!leafWrap) try { l.collapseTransformation = false; } catch (e) { }
        var dupes = applyEffects(ctx, comp, node, l, [l]);
        var shadow = addExactShadow(ctx, comp, node, cont, l, hidden);
        return { layers: pre.concat(shadow).concat(dupes).concat([l]), main: l };
    }

    // =====================================================================  shapes
    function contentsOf(layer) { return layer.property("ADBE Root Vectors Group"); }
    function addGroup(parentContents, name) {
        var g = parentContents.addProperty("ADBE Vector Group"); g.name = name;
        return g;
    }
    function shapeFrom(p, M) {
        var s = new Shape(), v = [], it = [], ot = [];
        for (var i = 0; i < p.v.length; i++) {
            if (M) { v.push(ap(M, p.v[i][0], p.v[i][1])); it.push(apLin(M, p.i[i][0], p.i[i][1])); ot.push(apLin(M, p.o[i][0], p.o[i][1])); }
            else { v.push([p.v[i][0], p.v[i][1]]); it.push([p.i[i][0], p.i[i][1]]); ot.push([p.o[i][0], p.o[i][1]]); }
        }
        s.vertices = v; s.inTangents = it; s.outTangents = ot; s.closed = !!p.c;
        return s;
    }
    function roundedRect(x, y, w, h, r) {
        var m = Math.min(w, h) / 2, rr = [], i;
        for (i = 0; i < 4; i++) rr[i] = clamp(num(r ? r[i] : 0, 0), 0, m);
        var V = [], I = [], O = [], k = KAPPA;
        function pt(px, py, ix, iy, ox, oy) { V.push([px, py]); I.push([ix, iy]); O.push([ox, oy]); }
        if (rr[0]) { pt(x, y + rr[0], 0, 0, 0, -k * rr[0]); pt(x + rr[0], y, -k * rr[0], 0, 0, 0); } else pt(x, y, 0, 0, 0, 0);
        if (rr[1]) { pt(x + w - rr[1], y, 0, 0, k * rr[1], 0); pt(x + w, y + rr[1], 0, -k * rr[1], 0, 0); } else pt(x + w, y, 0, 0, 0, 0);
        if (rr[2]) { pt(x + w, y + h - rr[2], 0, 0, 0, k * rr[2]); pt(x + w - rr[2], y + h, k * rr[2], 0, 0, 0); } else pt(x + w, y + h, 0, 0, 0, 0);
        if (rr[3]) { pt(x + rr[3], y + h, 0, 0, -k * rr[3], 0); pt(x, y + h - rr[3], 0, k * rr[3], 0, 0); } else pt(x, y + h, 0, 0, 0, 0);
        return { v: V, i: I, o: O, c: true };
    }
    function ellipsePath(x, y, w, h) {
        var rx = w / 2, ry = h / 2, cx = x + rx, cy = y + ry, k = KAPPA;
        return { v: [[cx, y], [x + w, cy], [cx, y + h], [x, cy]],
            i: [[-k * rx, 0], [0, -k * ry], [k * rx, 0], [0, k * ry]],
            o: [[k * rx, 0], [0, k * ry], [-k * rx, 0], [0, -k * ry]], c: true };
    }
    function geomPaths(geom, forFill) {
        if (geom.kind === "rect") return [roundedRect(0, 0, geom.w, geom.h, geom.r)];
        if (geom.kind === "ellipse") return [ellipsePath(0, 0, geom.w, geom.h)];
        return (forFill && geom.fillPaths) ? geom.fillPaths : (geom.paths || []);
    }
    function uniformR(r) { return !r || (r[0] === r[1] && r[1] === r[2] && r[2] === r[3]); }

    // inset d (>0 shrinks) is used to emulate Figma inside/outside stroke alignment.
    function addGeometry(vecs, geom, forFill, inset) {
        inset = inset || 0;
        if (geom.kind === "rect") {
            var w = Math.max(0, geom.w - 2 * inset), h = Math.max(0, geom.h - 2 * inset);
            if (uniformR(geom.r)) {
                var rc = vecs.addProperty("ADBE Vector Shape - Rect");
                rc.property("ADBE Vector Rect Size").setValue([w, h]);
                rc.property("ADBE Vector Rect Position").setValue([geom.w / 2, geom.h / 2]);
                var rad = Math.max(0, num(geom.r ? geom.r[0] : 0, 0) - inset);
                if (rad > 0) rc.property("ADBE Vector Rect Roundness").setValue(rad);
            } else {
                var rr = []; for (var i = 0; i < 4; i++) rr.push(Math.max(0, geom.r[i] - inset));
                vecs.addProperty("ADBE Vector Shape - Group").property("ADBE Vector Shape").setValue(shapeFrom(roundedRect(inset, inset, w, h, rr)));
            }
            return;
        }
        if (geom.kind === "ellipse") {
            var el = vecs.addProperty("ADBE Vector Shape - Ellipse");
            el.property("ADBE Vector Ellipse Size").setValue([Math.max(0, geom.w - 2 * inset), Math.max(0, geom.h - 2 * inset)]);
            el.property("ADBE Vector Ellipse Position").setValue([geom.w / 2, geom.h / 2]);
            return;
        }
        var paths = (forFill && geom.fillPaths) ? geom.fillPaths : geom.paths;
        var anyClosed = false;
        each(paths, function (p) {
            if (!p.v || !p.v.length) return;
            if (p.c) anyClosed = true;
            var sp = vecs.addProperty("ADBE Vector Shape - Group");
            sp.property("ADBE Vector Shape").setValue(shapeFrom(p));
        });
        if (inset && anyClosed) {
            var off = vecs.addProperty("ADBE Vector Filter - Offset");
            off.property("ADBE Vector Offset Amount").setValue(-inset);
            try { off.property("ADBE Vector Offset Line Join").setValue(1); } catch (e) { }
        }
    }
    function c4(c) { return [c[0], c[1], c[2], 1]; }
    function setFillRule(fill, rule) { try { fill.property("ADBE Vector Fill Rule").setValue(rule === "EVENODD" ? 2 : 1); } catch (e) { } }

    function addSolidFill(vecs, paint, rule) {
        var f = vecs.addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue(c4(paint.color));
        f.property("ADBE Vector Fill Opacity").setValue(paint.opacity * 100);
        setFillRule(f, rule);
        return f;
    }
    function gradColors(stops) {
        var a = [], i;
        for (i = 0; i < stops.length; i++) a.push(stops[i].p, stops[i].c[0], stops[i].c[1], stops[i].c[2]);
        for (i = 0; i < stops.length; i++) a.push(stops[i].p, stops[i].c[3]);
        return a;
    }
    function setGradient(g, paint) {
        g.property("ADBE Vector Grad Type").setValue(paint.type === "radial" ? 2 : 1);
        g.property("ADBE Vector Grad Start Pt").setValue(paint.start);
        g.property("ADBE Vector Grad End Pt").setValue(paint.end);
        g.property("ADBE Vector Grad Colors").setValue(gradColors(paint.stops));
    }
    function applyStrokeParams(s, st, w) {
        s.property("ADBE Vector Stroke Width").setValue(w);
        var cap = { NONE: 1, ROUND: 2, SQUARE: 3 }[st.cap] || 1, join = { MITER: 1, ROUND: 2, BEVEL: 3 }[st.join] || 1;
        try { s.property("ADBE Vector Stroke Line Cap").setValue(cap); } catch (e) { }
        try { s.property("ADBE Vector Stroke Line Join").setValue(join); } catch (e) { }
        try { s.property("ADBE Vector Stroke Miter Limit").setValue(clamp(st.miter || 4, 1, 100)); } catch (e) { }
        if (st.dash && st.dash.length) {
            var d = st.dash.length % 2 ? st.dash.concat(st.dash) : st.dash;
            try {
                var ds = s.property("ADBE Vector Stroke Dashes");
                for (var i = 0; i < d.length && i < 6; i += 2) {
                    var n = i / 2 + 1;
                    ds.addProperty("ADBE Vector Stroke Dash " + n).setValue(d[i]);
                    ds.addProperty("ADBE Vector Stroke Gap " + n).setValue(d[i + 1]);
                }
            } catch (e) { }
        }
    }

    function newShapeLayer(ctx, comp, node, cont, name) {
        var l = comp.layers.addShape();
        l.name = safeName(name);
        place(ctx, l, node.m, cont, centre(ctx, node.w, node.h), [0, 0]);
        return l;
    }

    function buildShapeNode(ctx, comp, node, cont, hidden, own) {
        var layers = [], pre = [], extraOp = [], mattes = [];
        var geom = node.geom || { kind: "paths", paths: [] };
        var rule = geom.rule || "NONZERO";
        if (own) each(node.effects, function (e) { if (e.type === "backgroundBlur") pre.push(buildBackgroundBlur(ctx, comp, node, cont, e, hidden)); });

        var bucket = null, groupCount = 0;
        function bucketLayer(suffix) {
            if (!bucket) { bucket = newShapeLayer(ctx, comp, node, cont, node.name + (layers.length ? suffix : "")); layers.push(bucket); groupCount = 0; }
            return bucket;
        }
        function topGroup(layer, name) {
            var g = addGroup(contentsOf(layer), name);
            groupCount++;
            return g;
        }
        function moveTop(layer) { var c = contentsOf(layer); if (c.numProperties > 1) c.property(c.numProperties).moveTo(1); }

        // ---- fills (bottom → top). A fill with its own blend mode (e.g. a Multiply gradient overlay) gets a
        //      layer to itself, with that blend mode on the layer – so it blends with everything underneath, as in Figma.
        var extraBlend = [];
        each(node.fills, function (p, i) {
            var pb = p.blend && p.blend !== "NORMAL" && p.blend !== "PASS_THROUGH" ? p.blend : null, n0 = layers.length;
            if (pb) bucket = null;
            fillOne(p, i);
            if (pb) { if (layers.length > n0) extraBlend[layers.length - 1] = pb; bucket = null; }
        });
        function fillOne(p, i) {
            if (p.type === "image") { bucket = null; var il = buildImageLayer(ctx, comp, node, cont, p, styleShadows(node) ? null : mattes); layers.push(il); extraOp[layers.length - 1] = p.opacity; return; }
            if (p.type === "solid") {
                var L = bucketLayer(" · fill"), g = topGroup(L, "Fill " + (i + 1)), v = g.property("ADBE Vectors Group");
                addGeometry(v, geom, true, 0); addSolidFill(v, p, rule); moveTop(L); return;
            }
            if (!ctx.gradOK && nativeAlphaRamp(p)) {
                // two-stop gradient that fades to transparent → native & editable: Gradient Ramp for the colours,
                // a luma track matte (a grey Gradient Ramp) for the transparency
                bucket = null;
                var R2 = newShapeLayer(ctx, comp, node, cont, node.name + " · gradient");
                var vr2 = topGroup(R2, "Gradient " + (i + 1)).property("ADBE Vectors Group");
                addGeometry(vr2, geom, true, 0); addSolidFill(vr2, { color: [1, 1, 1], opacity: 1 }, rule);
                var pts = rampPoints(p), c0 = p.stops[0].c, c1 = p.stops[1].c;
                setRamp(R2, p.type, pts, [c0[0], c0[1], c0[2]], [c1[0], c1[1], c1[2]]);
                var M2 = newShapeLayer(ctx, comp, node, cont, node.name + " · gradient transparency");
                var vm2 = topGroup(M2, "Transparency").property("ADBE Vectors Group");
                addGeometry(vm2, geom, true, 0); addSolidFill(vm2, { color: [1, 1, 1], opacity: 1 }, rule);
                setRamp(M2, p.type, pts, [c0[3], c0[3], c0[3]], [c1[3], c1[3], c1[3]]);
                M2.moveBefore(R2);
                try { M2.comment = figmaTag(node); } catch (e) { }
                tag(M2, "mask");
                var newMatte = false;
                try { if (typeof R2.setTrackMatte === "function") { R2.setTrackMatte(M2, TrackMatteType.LUMA); newMatte = true; } } catch (e) { }
                if (newMatte) M2.enabled = false; else R2.trackMatteType = TrackMatteType.LUMA;
                layers.push(R2); extraOp[layers.length - 1] = p.opacity; mattes.push(M2);
                return;
            }
            if ((p.type === "linear" || p.type === "radial") && p.render && (!ctx.gradOK || p.exactOnly)) {
                // exact Figma-rendered fill, clipped by the native shape
                bucket = null;
                var gl = buildImageLayer(ctx, comp, node, cont, { type: "image", file: p.render.file, iw: p.render.iw, ih: p.render.ih, m: p.render.m, opacity: p.opacity, fit: "RENDER" });
                gl.name = safeName(node.name + " · gradient");
                layers.push(gl); extraOp[layers.length - 1] = p.opacity; return;
            }
            if (p.type === "linear" || p.type === "radial") {
                if (ctx.gradOK) {
                    var L2 = bucketLayer(" · fill"), g2 = topGroup(L2, "Gradient " + (i + 1)), v2 = g2.property("ADBE Vectors Group");
                    addGeometry(v2, geom, true, 0);
                    var gf = v2.addProperty("ADBE Vector Graphic - G-Fill"); setGradient(gf, p);
                    gf.property("ADBE Vector Fill Opacity").setValue(p.opacity * 100); setFillRule(gf, rule);
                    moveTop(L2);
                } else {
                    bucket = null;
                    var R = newShapeLayer(ctx, comp, node, cont, node.name + " · gradient");
                    var vr = topGroup(R, "Gradient " + (i + 1)).property("ADBE Vectors Group");
                    addGeometry(vr, geom, true, 0); addSolidFill(vr, { color: [1, 1, 1], opacity: p.opacity }, rule);
                    addRamp(ctx, R, p, node, [0, 0]); layers.push(R);
                }
            }
        }

        // ---- strokes (above fills)
        var st = node.stroke;
        if (node.strokes && node.strokes.length && (st || node.outline)) {
            each(node.strokes, function (p, i) {
                if (p.type === "image") { warn(ctx, node, "image stroke not supported – skipped"); return; }
                var useRamp = p.type !== "solid" && !ctx.gradOK;
                var L;
                if (useRamp) { bucket = null; L = newShapeLayer(ctx, comp, node, cont, node.name + " · stroke"); }
                else L = bucketLayer(" · stroke");
                var v = topGroup(L, "Stroke " + (i + 1)).property("ADBE Vectors Group");
                if (node.outline) {
                    // stroke converted to a filled outline in Figma: exact for any alignment / dash / cap.
                    each(node.outline.paths, function (q) { v.addProperty("ADBE Vector Shape - Group").property("ADBE Vector Shape").setValue(shapeFrom(q)); });
                    if (p.type === "solid" || useRamp) addSolidFill(v, useRamp ? { color: [1, 1, 1], opacity: p.opacity } : p, node.outline.rule);
                    else { var gfo = v.addProperty("ADBE Vector Graphic - G-Fill"); setGradient(gfo, p); gfo.property("ADBE Vector Fill Opacity").setValue(p.opacity * 100); }
                } else {
                    var open = geom.kind === "paths" && hasOpen(geom.paths);
                    var align = open ? "CENTER" : st.align;
                    var inset = align === "INSIDE" ? st.w / 2 : (align === "OUTSIDE" ? -st.w / 2 : 0);
                    addGeometry(v, geom, false, inset);
                    var s;
                    if (p.type === "solid" || useRamp) {
                        s = v.addProperty("ADBE Vector Graphic - Stroke");
                        s.property("ADBE Vector Stroke Color").setValue(useRamp ? [1, 1, 1, 1] : c4(p.color));
                    } else { s = v.addProperty("ADBE Vector Graphic - G-Stroke"); setGradient(s, p); }
                    s.property("ADBE Vector Stroke Opacity").setValue(p.opacity * 100);
                    applyStrokeParams(s, st, st.w);
                }
                moveTop(L);
                if (useRamp) { addRamp(ctx, L, p, node, [0, 0]); layers.push(L); }
            });
        }
        if (!layers.length) bucketLayer(""); // empty shape (e.g. invisible mask with no paint) still needs a layer
        if (node.mask && layers.length === 1 && !(node.fills && node.fills.length)) {
            // a mask with no fill would be fully transparent in AE – give it an opaque fill.
            var mv = topGroup(layers[0], "Mask fill").property("ADBE Vectors Group");
            addGeometry(mv, geom, true, 0); addSolidFill(mv, { color: [1, 1, 1], opacity: 1 }, rule);
        }
        var opacity = own ? node.opacity : 1;
        each(layers, function (l, i) { finishLayer(ctx, l, node, hidden, opacity * (extraOp[i] === undefined ? 1 : extraOp[i]), own); });
        each(layers, function (l, i) {
            if (!extraBlend[i] || !BLEND[extraBlend[i]]) return;
            if (own && node.blend && node.blend !== "NORMAL" && node.blend !== "PASS_THROUGH" && node.blend !== extraBlend[i]) { warn(ctx, node, "fill blend mode " + extraBlend[i] + " and layer blend mode " + node.blend + " – AE can't combine them; used the fill's"); }
            try { l.blendingMode = BlendingMode[BLEND[extraBlend[i]]]; } catch (e) { }
        });
        var dupes = own ? applyEffects(ctx, comp, node, layers[0], layers) : [];
        var shadow = own ? addExactShadow(ctx, comp, node, cont, layers[0], hidden) : [];
        return { layers: pre.concat(shadow).concat(dupes).concat(layers).concat(mattes), main: layers[0] };
    }
    // layer-style shadows would be clipped by a track matte → keep a mask on those images
    function styleShadows(node) { for (var i = 0; i < (node.effects || []).length; i++) if (/Shadow$/.test(node.effects[i].type)) return true; return false; }
    function hasOpen(paths) { for (var i = 0; i < (paths || []).length; i++) if (!paths[i].c) return true; return false; }

    // a two-stop linear (or circular radial from the centre) gradient with transparency can be rebuilt natively
    function nativeAlphaRamp(p) {
        if (!(p.type === "linear" || p.type === "radial") || p.exactOnly || !p.stops || p.stops.length !== 2) return false;
        var a = p.stops[0].c[3], b = p.stops[1].c[3];
        if (a >= 0.999 && b >= 0.999) return false;              // opaque: the normal ramp path
        if (p.type === "radial") {
            if (p.stops[0].p > 0.001 || !p.edge2) return false;   // AE's radial ramp always starts at the centre
            var r1 = Math.sqrt(Math.pow(p.end[0] - p.start[0], 2) + Math.pow(p.end[1] - p.start[1], 2));
            var r2 = Math.sqrt(Math.pow(p.edge2[0] - p.start[0], 2) + Math.pow(p.edge2[1] - p.start[1], 2));
            if (Math.abs(r1 - r2) > Math.max(1, r1 * 0.02)) return false;   // elliptical → keep Figma's exact render
        }
        return true;
    }
    // ramp start/end where the two stops actually sit (stops needn't be at 0% and 100%)
    function rampPoints(p) {
        var s0 = p.stops[0].p, s1 = p.stops[1].p, dx = p.end[0] - p.start[0], dy = p.end[1] - p.start[1];
        if (p.type === "radial") return [p.start, [p.start[0] + dx * s1, p.start[1] + dy * s1]];
        return [[p.start[0] + dx * s0, p.start[1] + dy * s0], [p.start[0] + dx * s1, p.start[1] + dy * s1]];
    }
    function setRamp(layer, type, pts, ca, cb) {
        var fx = layer.property("ADBE Effect Parade").addProperty("ADBE Ramp");
        fx.property(1).setValue(pts[0]); fx.property(2).setValue([ca[0], ca[1], ca[2], 1]);
        fx.property(3).setValue(pts[1]); fx.property(4).setValue([cb[0], cb[1], cb[2], 1]);
        fx.property(5).setValue(type === "radial" ? 2 : 1);
        return fx;
    }
    function addRamp(ctx, layer, p, node, o) {
        var fx = layer.property("ADBE Effect Parade").addProperty("ADBE Ramp");
        var a = p.stops[0].c, b = p.stops[p.stops.length - 1].c;
        fx.property(1).setValue([p.start[0] + o[0], p.start[1] + o[1]]);
        fx.property(2).setValue([a[0], a[1], a[2], 1]);
        fx.property(3).setValue([p.end[0] + o[0], p.end[1] + o[1]]);
        fx.property(4).setValue([b[0], b[1], b[2], 1]);
        fx.property(5).setValue(p.type === "radial" ? 2 : 1);
        if (p.stops.length > 2) warn(ctx, node, p.stops.length + "-stop gradient reduced to 2 stops (your AE can't script gradient colours)");
        if (a[3] < 0.999 || b[3] < 0.999) warn(ctx, node, "gradient stop transparency not reproduced");
    }

    // =====================================================================  images & rasters
    function footage(ctx, rel) {
        if (ctx.footage[rel]) return ctx.footage[rel];
        // the same picture is already in the project (earlier send, another frame) → use that one
        var key = ctx.scene.imageKeys ? ctx.scene.imageKeys[rel] : null, tagK = key ? "figma-img:" + key : null;
        if (tagK) for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            try { if (it instanceof FootageItem && it.comment === tagK && it.file && it.file.exists && !it.footageMissing) { ctx.footage[rel] = it; return it; } } catch (e) { }
        }
        var base = String(rel).replace(/^images\//, "");
        var f = new File((ctx.fileDir[base] || ctx.assets.fsName) + "/" + base);
        if (!f.exists) throw new Error("Missing asset " + rel);
        var io = new ImportOptions(f);
        var item = app.project.importFile(io);
        item.parentFolder = ctx.folders.bin;
        if (tagK) try { item.comment = tagK; } catch (e) { }
        ctx.footage[rel] = item;
        return item;
    }
    // Image fills: the full, uncropped image + the shape above it as an alpha track matte
    // (move/scale the photo inside the frame, or animate the frame, independently).
    function buildImageLayer(ctx, comp, node, cont, p, mattesOut) {
        var l = comp.layers.add(footage(ctx, p.file), comp.duration);
        l.name = safeName(node.name);
        var Mimg = mul(node.m, p.m);
        place(ctx, l, Mimg, cont, centre(ctx, p.iw, p.ih), [0, 0]);
        var geom = node.geom || { kind: "rect", w: node.w, h: node.h };
        if (!coversImage(node, p)) {
            if (p.fit === "RENDER" || !mattesOut) {
                // exact gradient renders: a plain mask is enough (nothing to reposition)
                var toImg = inv(p.m), first = true;
                each(geomPaths(geom, true), function (q) { addMask(l, q, first ? MaskMode.ADD : MaskMode.DIFFERENCE, toImg); first = false; });
            } else {
                var mt = newShapeLayer(ctx, comp, node, cont, node.name + " · matte");
                var v = addGroup(contentsOf(mt), "Shape").property("ADBE Vectors Group");
                addGeometry(v, geom, true, 0); addSolidFill(v, { color: [1, 1, 1], opacity: 1 }, geom.rule);
                mt.moveBefore(l);
                try { mt.comment = figmaTag(node); } catch (e) { }
                tag(mt, "mask");
                var useNew = false;
                try { if (typeof l.setTrackMatte === "function") { l.setTrackMatte(mt, TrackMatteType.ALPHA); useNew = true; } } catch (e) { }
                if (useNew) mt.enabled = false; else l.trackMatteType = TrackMatteType.ALPHA; // classic: matte sits directly above
                mattesOut.push(mt);
            }
        }
        return l;
    }
    // FILL images on a sharp rectangle exactly cover the shape → no mask needed
    function coversImage(node, p) {
        var g = node.geom; if (!g || g.kind !== "rect" || (g.r && (g.r[0] || g.r[1] || g.r[2] || g.r[3]))) return false;
        if (p.fit !== "FILL") return false;
        var a = ap(p.m, 0, 0), b = ap(p.m, p.iw, p.ih);
        return Math.abs(a[0]) < 0.01 && Math.abs(a[1]) < 0.01 && Math.abs(b[0] - node.w) < 0.01 && Math.abs(b[1] - node.h) < 0.01;
    }
    function addMask(layer, path, mode, M) {
        var m = layer.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
        m.property("ADBE Mask Shape").setValue(shapeFrom(path, M));
        m.maskMode = mode;
        return m;
    }
    function buildRaster(ctx, comp, node, cont, hidden, own) {
        var l = comp.layers.add(footage(ctx, node.file), comp.duration);
        l.name = safeName(node.name);
        place(ctx, l, node.m, cont, centre(ctx, node.w, node.h), [0, 0]);
        finishLayer(ctx, l, node, hidden, own ? node.opacity : 1, own);
        return { layers: [l], main: l };
    }

    // =====================================================================  text
    var JUST = { LEFT: "LEFT_JUSTIFY", CENTER: "CENTER_JUSTIFY", RIGHT: "RIGHT_JUSTIFY", JUSTIFIED: "FULL_JUSTIFY_LASTLINE_LEFT" };
    function normStyle(s) {
        s = String(s || "").toLowerCase().replace(/[\s_\-]+/g, "");
        s = s.replace(/^(regular|normal|roman|book|plain)$/, "regular").replace(/oblique/g, "italic");
        if (s === "") s = "regular";
        return s;
    }
    function resolveFont(ctx, font, node) {
        var key = font.family + "|" + font.style;
        if (ctx.fontCache[key] !== undefined) return ctx.fontCache[key];
        var ps = null;
        try {
            if (app.fonts) {
                var arr = app.fonts.getFontsByFamilyNameAndStyleName ? app.fonts.getFontsByFamilyNameAndStyleName(font.family, font.style) : [];
                if (arr && arr.length) ps = arr[0].postScriptName;
                if (!ps && app.fonts.allFonts) {
                    var want = normStyle(font.style), fam = String(font.family).toLowerCase(), all = app.fonts.allFonts;
                    for (var i = 0; i < all.length && !ps; i++) {
                        var group = all[i];
                        for (var j = 0; j < group.length; j++) {
                            var f = group[j];
                            if (String(f.familyName).toLowerCase() === fam && normStyle(f.styleName) === want) { ps = f.postScriptName; break; }
                        }
                    }
                }
            }
        } catch (e) { }
        if (!ps) {
            var st = String(font.style).replace(/\s+/g, "");
            ps = String(font.family).replace(/\s+/g, "") + (normStyle(font.style) === "regular" ? "-Regular" : "-" + st);
            ctx.fontCache[key + "|guess"] = true;
        }
        ctx.fontCache[key] = ps;
        return ps;
    }
    function checkFont(ctx, td, ps, font) {
        var ok = true;
        try { if (td.font !== ps) ok = false; } catch (e) { }
        try { if (td.fontObject && td.fontObject.isSubstitute) ok = false; } catch (e) { }
        // AE 24+: a font we had to guess (not found in app.fonts) is missing too
        try { if (app.fonts && ctx.fontCache[font.family + "|" + font.style + "|guess"]) ok = false; } catch (e) { }
        if (!ok) ctx.missingFonts[font.family + " " + font.style] = true;
        return ok;
    }

    function buildText(ctx, comp, node, cont, hidden, own) {
        var t = node.text, segs = t.segs || [];
        var s0 = segs.length ? segs[0] : { size: 12, color: [0, 0, 0], fa: 1, tracking: 0, lh: 14.4, font: { family: "Arial", style: "Regular" } };
        var pointText = t.autoResize === "WIDTH_AND_HEIGHT";
        var align = t.alignH || "LEFT";
        var chars = t.chars.length ? t.chars : " ";
        // All caps: type the capitals in as well (same length, so every style index still lines up). AE's caps
        // setting is also switched on below, but it can't be relied on from a script in every AE version.
        each(segs, function (sg) {
            if (sg.caps !== "all" || sg.e <= sg.s) return;
            var up = chars.substring(sg.s, sg.e).toUpperCase();
            if (up.length === sg.e - sg.s) chars = chars.substring(0, sg.s) + up + chars.substring(sg.e);
        });
        var layer, pad = 1, boxLeft = 0;
        // Figma's own line wraps → soft returns at the same spaces (same length, so every style index still fits).
        // AE rounds spacing a little differently, so a line that only just fits could otherwise wrap one word off.
        // A little slack in the box stops AE adding a wrap of its own on top.
        if (!pointText && align !== "JUSTIFIED" && t.wraps && t.wraps.length) {
            var ca = chars.split(""), nw = 0;
            for (var wi = 0; wi < t.wraps.length; wi++) { var wx = t.wraps[wi]; if (ca[wx] === " ") { ca[wx] = "\u0003"; nw++; } }
            if (nw) { chars = ca.join(""); pad = Math.max(2, Math.min(40, node.w * 0.04)); }
        }
        if (!pointText && t.chars.length > 20) ctx.lines.push(String(node.name).substr(0, 30) + ": " + (t.wrapInfo || "no info from Figma") + (t.wraps && t.wraps.length ? " -> " + (chars.split("\u0003").length - 1) + " soft returns" : ""));
        if (pointText) layer = comp.layers.addText(chars);
        else {
            var bw = node.w + (align === "JUSTIFIED" ? 0 : pad * (align === "CENTER" ? 2 : 1));
            boxLeft = (align === "RIGHT" || align === "CENTER") ? -pad : 0;
            if (align === "JUSTIFIED") boxLeft = 0;
            var bh = Math.max(node.h, s0.size) * 1.5 + (s0.lh || s0.size) * 2;
            layer = comp.layers.addBoxText([Math.max(1, bw), Math.max(1, bh)], chars);
        }
        layer.name = safeName(node.name);
        var prop = layer.property("ADBE Text Properties").property("ADBE Text Document");
        var td = prop.value;
        try { td.resetCharStyle(); } catch (e) { }
        try { td.resetParagraphStyle(); } catch (e) { }
        td.text = chars;
        var ps0 = resolveFont(ctx, s0.font, node);
        td.font = ps0;
        var size = clamp(s0.size, 0.1, 1296);
        if (s0.size > 1296) warn(ctx, node, "font size clamped to AE max 1296px");
        td.fontSize = size;
        td.applyFill = s0.visibleFill !== false;
        try { td.fillColor = s0.color; } catch (e) { }
        td.tracking = Math.round(s0.tracking);
        try { td.autoLeading = false; td.leading = s0.lh; } catch (e) { }
        try { td.justification = ParagraphJustification[JUST[align] || "LEFT_JUSTIFY"]; } catch (e) { }
        if (!setCaps(td, s0.caps) && s0.caps && s0.caps !== "all") warn(ctx, node, "small caps need After Effects 2024 or newer");
        if (s0.vpos && segs.length === 1) setVPos(ctx, td, s0, node, s0.size);   // mixed text: per character below, never the whole layer
        try { if (t.paraSpacing) td.spaceAfter = t.paraSpacing; } catch (e) { }
        try { if (t.paraIndent) td.firstLineIndent = t.paraIndent; } catch (e) { }
        try { td.everyLineComposer = false; } catch (e) { }
        try { td.autoHyphenate = false; } catch (e) { }
        if (t.stroke) {
            td.applyStroke = true; td.strokeColor = t.stroke.color;
            td.strokeWidth = t.stroke.align === "CENTER" ? t.stroke.w : t.stroke.w * 2;
            td.strokeOverFill = t.stroke.align !== "OUTSIDE";
        } else td.applyStroke = false;
        prop.setValue(td);
        var fontsOK = checkFont(ctx, prop.value, ps0, s0.font);
        var anyCaps = false; each(segs, function (sg) { if (sg.caps) anyCaps = true; });
        if (anyCaps) { var rb = "?"; try { rb = String(prop.value.fontCapsOption); } catch (e) { rb = "n/a"; } try { rb += "/allCaps=" + prop.value.allCaps; } catch (e) { } ctx.lines.push(String(node.name).substr(0, 30) + ": caps " + s0.caps + " -> AE reads " + rb); }

        // per-character styling (AE 24.3+). Older AE: first style wins.
        var mixed = segs.length > 1;
        if (mixed) {
            td = prop.value;
            if (typeof td.characterRange === "function") {
                for (var i = 0; i < segs.length; i++) {
                    var sg = segs[i]; if (sg.e <= sg.s) continue;
                    try {
                        var cr = td.characterRange(sg.s, sg.e);
                        var psx = resolveFont(ctx, sg.font, node);
                        if (ctx.fontCache[sg.font.family + "|" + sg.font.style + "|guess"] && app.fonts) { fontsOK = false; ctx.missingFonts[sg.font.family + " " + sg.font.style] = true; }
                        try { cr.font = psx; } catch (e) { }
                        try { cr.fontSize = clamp(sg.size, 0.1, 1296); } catch (e) { }
                        try { cr.applyFill = sg.visibleFill !== false; cr.fillColor = sg.color; } catch (e) { }
                        try { cr.tracking = Math.round(sg.tracking); } catch (e) { }
                        try { cr.autoLeading = false; cr.leading = sg.lh; } catch (e) { }
                        if (!setCaps(cr, sg.caps) && sg.caps && sg.caps !== "all") warn(ctx, node, "small caps need After Effects 2024 or newer");
                        setVPos(ctx, cr, sg, node, clamp(sg.size, 0.1, 1296));
                    } catch (e) { }
                }
                prop.setValue(td);
            } else warn(ctx, node, "mixed text styles need AE 24.3+ – first style applied to whole layer");
        }

        // ---- lists: hanging indent per list paragraph, as Figma lays it out (AE 24.3+)
        if (t.paras && t.paras.length) {
            td = prop.value;
            if (typeof td.paragraphRange === "function") {
                var listOK = true;
                for (var lp = 0; lp < t.paras.length; lp++) {
                    var P = t.paras[lp], pIdx = 0;
                    for (var q = 0; q < P.s; q++) if (chars.charAt(q) === "\r") pIdx++;
                    try {
                        var pr = td.paragraphRange(pIdx, pIdx + 1);
                        pr.startIndent = P.tx;                      // wrapped lines start where Figma's text does
                        pr.firstLineIndent = P.bx - P.tx;           // marker hangs out to the left
                        if (Math.abs(P.gap) > 0.2) { var sp = td.characterRange(P.s + P.ml - 1, P.s + P.ml); sp.tracking = Math.round((sp.tracking || 0) + P.gap / size * 1000); }
                    } catch (e) { listOK = false; }
                }
                prop.setValue(td);
                if (!listOK) warn(ctx, node, "list indents couldn't be set exactly");
            } else warn(ctx, node, "bullet/number list indents need After Effects 2024 (24.3) or newer");
        }

        // ---- position: align AE's first baseline with Figma's measured baseline.
        td = prop.value;
        var bl = null; try { bl = td.baselineLocs; } catch (e) { }
        var nLines = 1, blY = 0;
        if (bl && bl.length >= 4) { nLines = Math.floor(bl.length / 4); blY = bl[1]; }
        else {
            var rect = layer.sourceRectAtTime(0, false);
            blY = pointText ? 0 : rect.top + s0.size * 0.8;
            nLines = Math.max(1, Math.round(rect.height / Math.max(1, s0.lh)));
        }
        var contentH = nLines * (s0.lh || t.lineGap) + countBreaks(chars) * (t.paraSpacing || 0);
        var vOff = 0;
        if (!pointText && t.alignV === "CENTER") vOff = (node.h - contentH) / 2;
        if (!pointText && t.alignV === "BOTTOM") vOff = node.h - contentH;
        var figBaseline = vOff + t.baseline;
        var ox;
        if (pointText) ox = -({ LEFT: 0, CENTER: node.w / 2, RIGHT: node.w, JUSTIFIED: 0 }[align] || 0);
        else { var bp = [0, 0]; try { bp = td.boxTextPos; } catch (e) { bp = [-node.w / 2, 0]; } ox = bp[0] - boxLeft; }
        var o = [ox, blY - figBaseline];
        // Preferred: line up AE's rendered glyph bounds with Figma's (exact, independent of font metrics).
        // Only trusted when both renders are clearly the same glyphs (same size ink box).
        if (t.ink) {
            var r = null; try { r = layer.sourceRectAtTime(0, false); } catch (e) { }
            var tolW = Math.max(2, t.ink[2] * 0.06), tolH = Math.max(2, t.ink[3] * 0.06);
            if (r && r.width > 0 && Math.abs(r.width - t.ink[2]) <= tolW && Math.abs(r.height - t.ink[3]) <= tolH) {
                o = [r.left + (r.width - t.ink[2]) / 2 - t.ink[0], r.top + (r.height - t.ink[3]) / 2 - t.ink[1]];
                // paragraphs in a fixed-width box: the box edge is exact; glyph-matching drifts a few px on long,
                // wrapped or bulleted text. Keep the glyph match for the vertical only.
                if (!pointText && (nLines > 2 || (t.paras && t.paras.length))) o[0] = ox;
            } else {
                warn(ctx, node, "text renders differently in AE (" + (r ? Math.round(r.width) + "×" + Math.round(r.height) : "?") + " vs Figma " +
                    Math.round(t.ink[2]) + "×" + Math.round(t.ink[3]) + " px – font substituted or wrapped differently?) – placed by baseline");
            }
        }
        place(ctx, layer, node.m, cont, centre(ctx, node.w, node.h), o);

        // uniform fill alpha → layer opacity (AE text fill has no alpha)
        var fa = s0.fa; for (var k = 1; k < segs.length; k++) if (Math.abs(segs[k].fa - fa) > 0.01) { fa = 1; warn(ctx, node, "per-character fill opacity not supported"); break; }
        finishLayer(ctx, layer, node, hidden, (own ? node.opacity : 1) * fa, own);

        if (t.gradient && (t.gradient.type === "linear" || t.gradient.type === "radial")) addRamp(ctx, layer, t.gradient, node, o);
        var extra = [];
        var deco = s0.deco; for (var q = 1; q < segs.length; q++) if (segs[q].deco !== deco) deco = null;
        if (deco && bl && bl.length >= 4) extra.push(buildDecoration(ctx, comp, layer, node, bl, s0, deco, hidden));
        else if (s0.deco) warn(ctx, node, "text decoration only on part of the text – skipped");

        var dupes = own ? applyEffects(ctx, comp, node, layer, [layer]) : [];
        var shadow = own ? addExactShadow(ctx, comp, node, cont, layer, hidden) : [];
        // font missing → show Figma's exact render on top; the live text stays underneath (switched off)
        if (!fontsOK && t.img) {
            var il = comp.layers.add(footage(ctx, t.img.file), comp.duration);
            place(ctx, il, mul(node.m, t.img.m), cont, [t.img.iw / 2, t.img.ih / 2], [0, 0]);
            il.name = safeName(node.name + " · Figma render (font missing)");
            il.moveBefore(layer);
            try { il.parent = layer; } catch (e) { }
            if (own && node.opacity < 0.9999) tr(il).property("ADBE Opacity").setValue(node.opacity * 100);
            if (hidden || node.visible === false) il.enabled = false;
            try { il.comment = figmaTag(node); } catch (e) { }
            tag(il, "raster");
            layer.enabled = false;
            each(extra, function (x) { x.enabled = false; });
            warn(ctx, node, "font missing – showing Figma's render; the editable text layer is underneath (switched off)");
            extra.push(il);
        }
        return { layers: shadow.concat(dupes).concat([layer]).concat(extra), main: layer };
    }
    // Figma superscript / subscript → AE superscript / subscript (AE 24+)
    // Superscript / subscript. Figma sends either the font's real ¹²³ characters (no styling needed here) or the
    // exact size + raise it draws them with (vscale, vshift px, + = up) → set as font size + baseline shift.
    // AE's fontBaselineOption is only a last resort: in real AE it put superscripts below the baseline.
    // Figma text case → AE caps. allCaps / smallCaps are read-only in AE scripting – fontCapsOption (AE 24+) is
    // the one that can be set. Returns false when this AE can't.
    function setCaps(target, caps) {
        if (typeof FontCapsOption === "undefined") return false;
        var F = FontCapsOption;
        var v = caps === "all" ? F.FONT_ALL_CAPS : caps === "small" ? F.FONT_SMALL_CAPS : caps === "allsmall" ? F.FONT_ALL_SMALL_CAPS : F.FONT_NORMAL_CAPS;
        try { target.fontCapsOption = v; return true; } catch (e) { return false; }
    }
    function setVPos(ctx, target, sg, node, size) {
        var vpos = sg.vpos, B0 = (typeof FontBaselineOption !== "undefined") ? FontBaselineOption : null;
        // clear any super/subscript flag AE carries on these characters first (real AE drew them low without this)
        if ((vpos || sg.subst) && B0) try { target.fontBaselineOption = B0.FONT_NORMAL_BASELINE; } catch (e8) { }
        if (!vpos) return;   // normal text is never touched
        var scale = sg.vscale || 0.58, shift = sg.vscale ? (sg.vshift || 0) : (vpos === "super" ? size * 0.33 : -size * 0.15), step = "fontSize";
        try {
            target.fontSize = clamp(size * scale, 0.1, 1296);
            step = "baselineShift"; target.baselineShift = shift;
            return;
        } catch (e) { try { target.fontSize = size; } catch (e1) { } }
        var B = (typeof FontBaselineOption !== "undefined") ? FontBaselineOption : null;
        var v = !B ? undefined : (shift >= 0 ? (B.FONT_FAUXED_SUPERSCRIPT || B.FONT_FAKED_SUPERSCRIPT) : (B.FONT_FAUXED_SUBSCRIPT || B.FONT_FAKED_SUBSCRIPT));
        try { if (v === undefined) throw new Error("no FontBaselineOption"); target.fontBaselineOption = v; }
        catch (e2) { warn(ctx, node, "couldn't set superscript/subscript – " + e2.message); }
    }
    function countBreaks(s) { var n = 0; for (var i = 0; i < s.length; i++) if (s.charAt(i) === "\r") n++; return n; }
    function buildDecoration(ctx, comp, textLayer, node, bl, s0, deco, hidden) {
        var l = comp.layers.addShape();
        l.name = safeName(node.name + (deco === "UNDERLINE" ? " · underline" : " · strikethrough"));
        var thick = Math.max(1, s0.size * 0.07), dy = deco === "UNDERLINE" ? s0.size * 0.12 : -s0.size * 0.28;
        var v = addGroup(contentsOf(l), "Lines").property("ADBE Vectors Group");
        for (var i = 0; i + 3 < bl.length; i += 4) {
            var x0 = bl[i], y0 = bl[i + 1] + dy, x1 = bl[i + 2];
            if (x1 - x0 < 0.5) continue;
            var r = v.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue([x1 - x0, thick]);
            r.property("ADBE Vector Rect Position").setValue([(x0 + x1) / 2, y0 + thick / 2]);
        }
        addSolidFill(v, { color: s0.color, opacity: 1 }, "NONZERO");
        tr(l).property("ADBE Anchor Point").setValue([0, 0]); tr(l).property("ADBE Position").setValue([0, 0]);
        l.setParentWithJump(textLayer);
        l.moveBefore(textLayer);
        try { l.comment = figmaTag(node); } catch (e) { }
        finishLayer(ctx, l, node, hidden, node.opacity * (s0.fa || 1), true);
        tag(l, "helper");
        return l;
    }

    // =====================================================================  effects
    function buildBackgroundBlur(ctx, comp, node, cont, e, hidden) {
        var l = comp.layers.addShape();
        l.name = safeName(node.name + " · background blur");
        place(ctx, l, node.m, cont, centre(ctx, node.w, node.h), [0, 0]);
        var geom = node.geom || (node.bg && node.bg.geom) || { kind: "rect", w: node.w, h: node.h, r: node.radius || [0, 0, 0, 0] };
        var v = addGroup(contentsOf(l), "Area").property("ADBE Vectors Group");
        addGeometry(v, geom, true, 0); addSolidFill(v, { color: [1, 1, 1], opacity: 1 }, geom.rule);
        l.adjustmentLayer = true;
        try { l.comment = figmaTag(node); } catch (er0) { }
        var fx = l.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
        fx.property(1).setValue(e.r * BLUR_K);
        try { fx.property(3).setValue(1); } catch (er) { } // repeat edge pixels
        tag(l, "helper");
        if (hidden || node.visible === false) l.enabled = false;
        return l;
    }
    // Exact drop shadow (rendered by Figma): image layer right under the node, parented to it so it follows.
    function addExactShadow(ctx, comp, node, cont, main, hidden) {
        if (!node.shadowImg || !main) return [];
        var si = node.shadowImg;
        var l = comp.layers.add(footage(ctx, si.file), comp.duration);
        place(ctx, l, si.m, cont, [si.w / 2, si.h / 2], [0, 0]);
        l.name = safeName(node.name + " · shadow");
        l.moveAfter(main);
        try { l.parent = main; } catch (e) { }
        if (node.opacity < 0.9999) tr(l).property("ADBE Opacity").setValue(node.opacity * 100);
        if (hidden || node.visible === false) l.enabled = false;
        try { l.comment = figmaTag(node); } catch (e) { }
        tag(l, "helper");
        return [l];
    }
    // layer blur → effect now; shadows → queued as layer styles (need the comp open in a viewer).
    function applyEffects(ctx, comp, node, main, layers) {
        var drops = [], inners = [], dupes = [];
        each(node.effects, function (e) {
            if (e.type === "layerBlur") each(layers, function (l) {
                var fx = l.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
                fx.property(1).setValue(e.r * BLUR_K);
                // Repeat Edge Pixels OFF (newer AE switches it on by default) – otherwise the blur stops dead at the
                // shape's edge and a soft Figma blur comes in as a hard-edged box
                try { fx.property("ADBE Gaussian Blur 2-0003").setValue(0); } catch (er) { try { fx.property(3).setValue(0); } catch (er2) { } }
            });
            else if (e.type === "dropShadow") drops.push(e);
            else if (e.type === "innerShadow") inners.push(e);
            else if (e.type === "unsupported") warn(ctx, node, e.name.toLowerCase() + " effect has no AE equivalent – skipped");
        });
        if (!main) return dupes;
        // AE allows one drop + one inner shadow style per layer → extra shadows ride on "shadow carrier" duplicates.
        for (var i = 0; i < drops.length; i++) {
            if (i === 0) { ctx.styleJobs.push({ comp: comp, layer: main, e: drops[i], node: node, soft: ctx.opt.shadowSize }); continue; }
            var d = main.duplicate(); d.name = safeName(node.name + " · shadow " + (i + 1)); d.moveAfter(main); try { d.comment = figmaTag(node); } catch (e) { } tag(d, "helper");
            ctx.styleJobs.push({ comp: comp, layer: d, e: drops[i], node: node, carrier: true, soft: ctx.opt.shadowSize }); dupes.push(d);
        }
        for (var j = 0; j < inners.length; j++) {
            if (j === 0) { ctx.styleJobs.push({ comp: comp, layer: main, e: inners[j], node: node, soft: ctx.opt.shadowSize }); continue; }
            var d2 = main.duplicate(); d2.name = safeName(node.name + " · inner shadow " + (j + 1)); d2.moveBefore(main); try { d2.comment = figmaTag(node); } catch (e) { } tag(d2, "helper");
            ctx.styleJobs.push({ comp: comp, layer: d2, e: inners[j], node: node, carrier: true, soft: ctx.opt.shadowSize }); dupes.push(d2);
        }
        return dupes;
    }

    var STYLE_CMD = { dropShadow: [9000, "Drop Shadow"], innerShadow: [9001, "Inner Shadow"] };
    function styleGroup(layer, kind) {
        try { var g = layer.property("ADBE Layer Styles").property(kind + "/enabled"); return g; } catch (e) { return null; }
    }
    function addLayerStyle(layer, kind) {
        var g = styleGroup(layer, kind);
        if (g && g.enabled && layer.property("ADBE Layer Styles").enabled) return g;
        app.executeCommand(STYLE_CMD[kind][0]);
        g = styleGroup(layer, kind);
        if (g && g.enabled && layer.property("ADBE Layer Styles").enabled) return g;
        return null;
    }
    function setP(g, name, v) { try { g.property(name).setValue(v); return true; } catch (e) { return false; } }

    function applyStyleJobs(ctx) {
        if (!ctx.styleJobs.length) return;
        var byComp = [], i;
        for (i = 0; i < ctx.styleJobs.length; i++) {
            var j = ctx.styleJobs[i], found = null;
            for (var k = 0; k < byComp.length; k++) if (byComp[k].comp === j.comp) found = byComp[k];
            if (!found) { found = { comp: j.comp, jobs: [] }; byComp.push(found); }
            found.jobs.push(j);
        }
        for (i = 0; i < byComp.length; i++) {
            var comp = byComp[i].comp, useStyles = ctx.opt.styles;
            if (useStyles) { comp.openInViewer(); }
            for (var n = 0; n < byComp[i].jobs.length; n++) {
                var job = byComp[i].jobs[n], done = false;
                if (useStyles) {
                    var sel = comp.selectedLayers; for (var s = 0; s < sel.length; s++) sel[s].selected = false;
                    var wasLocked = job.layer.locked; job.layer.locked = false;
                    job.layer.selected = true;
                    try { done = applyStyle(job, addLayerStyle(job.layer, job.e.type)); } catch (e) { done = false; }
                    if (job.negSpread) warn(ctx, job.node, "negative shadow spread has no AE equivalent – ignored");
                    job.layer.selected = false;
                }
                if (!done) done = applyShadowEffect(ctx, job);
                if (!done) warn(ctx, job.node, job.e.type + " could not be created");
            }
        }
    }
    function applyStyle(job, g) {
        if (!g) return false;
        var e = job.e, k = job.e.type;
        var dist = Math.sqrt(e.x * e.x + e.y * e.y);
        var ang = dist > 1e-6 ? deg(Math.atan2(e.y, -e.x)) : 90;
        var soft = (job.soft || 100) / 100;
        var spread = Math.max(0, e.spread), size = e.blur * soft + spread;
        // Figma shadows are Normal-blended. AE's default (Multiply) is identical for black shadows, so only
        // switch the mode when the colour actually needs it.
        var dark = e.color[0] < 0.02 && e.color[1] < 0.02 && e.color[2] < 0.02;
        if (!dark) setP(g, k + "/mode2", 1);
        setP(g, k + "/color", [e.color[0], e.color[1], e.color[2], 1]);
        setP(g, k + "/opacity", e.a * 100);
        setP(g, k + "/useGlobalAngle", 0);
        setP(g, k + "/localLightingAngle", ang);
        setP(g, k + "/distance", dist);
        setP(g, k + "/chokeMatte", size > 0 ? spread / size * 100 : 0);
        setP(g, k + "/blur", size);
        setP(g, k + "/noise", 0);
        if (k === "dropShadow") setP(g, "dropShadow/layerConceals", e.behind ? 0 : 1);
        setP(g, k + "/useGlobalAngle", 0);                // set again – some AE builds reset it when angle is written
        if (e.spread < 0) job.negSpread = true;
        if (job.carrier) setFillOpacityZero(job.layer);
        return true;
    }
    function findByMatch(group, re, depth) {
        if (!group || depth > 3) return null;
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            if (re.test(p.matchName)) return p;
            if (p.propertyType !== PropertyType.PROPERTY) { var r = findByMatch(p, re, depth + 1); if (r) return r; }
        }
        return null;
    }
    function setFillOpacityZero(layer) {
        var p = findByMatch(layer.property("ADBE Layer Styles"), /Fill.?Opac/i, 0);
        if (p) try { p.setValue(0); return; } catch (e) { }
        // fallback: hide carrier content, keep shadow via effect "shadow only"
    }
    function applyShadowEffect(ctx, job) {
        if (job.e.type !== "dropShadow") return false;
        try {
            var e = job.e, fx = job.layer.property("ADBE Effect Parade").addProperty("ADBE Drop Shadow");
            var dist = Math.sqrt(e.x * e.x + e.y * e.y);
            fx.property(1).setValue([e.color[0], e.color[1], e.color[2], 1]);
            var op = fx.property(2); op.setValue((op.hasMax && op.maxValue > 100 ? 255 : 100) * e.a);
            fx.property(3).setValue(dist > 1e-6 ? deg(Math.atan2(e.x, -e.y)) : 180);
            fx.property(4).setValue(dist);
            fx.property(5).setValue(e.blur * (job.soft || 100) / 100);
            if (job.carrier) fx.property(6).setValue(1);
            if (e.spread > 0) warn(ctx, job.node, "shadow spread needs layer styles – ignored");
            return true;
        } catch (er) { return false; }
    }
    // ---- entry point: panel UI, or the background live-link tick
    if ($.global.__figaeTick) {
        $.global.__figaeTick = false;
        ui = { status: progressStatus, read: function () { return loadOpt(); }, live: function (t) { sset("liveLast", t); progressLive(t); } };
        $.global.__figaeTickFn = bgTick;
        bgTick();
    } else {
        ui = buildUI(thisObj);
    }
})(this);
